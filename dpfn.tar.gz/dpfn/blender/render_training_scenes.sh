#! /bin/bash

for i in {40..60}
do
    echo Scene $i
    frames=( 0 49 89 129 )
    for j in ${frames[@]}
    do
        echo Frame $j
        /home/wiewel/bin/blender-2.79-linux-glibc219-x86_64/blender FluidTransparentRender.blend --background --python RenderFluid.py -- -i "//../predictions/TrainingScene_$i/obj/" -o "//Renders/TrainingScene_$i/Render_" -sf $j -ef $j -x 512 -y 360 --gpu --type reference
        #./build/manta scenes/dpfn_trainingdata.py --name liquid_reference_Bench$i -w 50 -s 150 --project naive_static_pressure -i 0 -pt naive_static_pressure -ord --seed 1 --benchmark $i
        #./build/manta scenes/scenes/generate_obj_scene.py -i ../predictions/liquid_reference_Bench$i/uni/ -o ../predictions/liquid_reference_Bench$i/obj/
    done
done
