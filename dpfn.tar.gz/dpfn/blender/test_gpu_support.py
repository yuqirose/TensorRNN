import bpy

# How to call:
#   blender --background [scene.blend] --python test_gpu_support.py
#   'scene.blend' is optional


if bpy.app.version < (2, 78, 0):
    sysp = bpy.context.user_preferences.system
    devt = sysp.compute_device_type
    dev = sysp.compute_device

    # get list of possible values of enum, see http://blender.stackexchange.com/a/2268/599
    devt_list = sysp.bl_rna.properties['compute_device_type'].enum_items.keys()
    dev_list = sysp.bl_rna.properties['compute_device'].enum_items.keys()

    # pretty print
    lines=[
    ("Property", "Value", "Possible Values"),
    ("Device Type:", devt, str(devt_list)),
    ("Device:", dev, str(dev_list)),
    ]
    print("\nGPU compute configuration:")
    for l in lines:
        print("{0:<20} {1:<20} {2:<50}".format(*l))

    # Expected Output:
    #   GPU compute configuration:
    #   Property             Value                Possible Values
    #   Device Type:         NONE                 ['NONE']
    #   Device:              CPU                  ['CPU']
else:
    # Device Types
    devt_list = []
    for devt_list_entry in bpy.context.user_preferences.addons['cycles'].preferences.get_device_types(0):
        devt_list += [devt_list_entry[0]]
    devt = bpy.context.user_preferences.addons['cycles'].preferences.compute_device_type

    # Devices
    dev_list = []
    cuda_dev_list, opencl_dev_list = bpy.context.user_preferences.addons['cycles'].preferences.get_devices()

    for dev_entry in cuda_dev_list:
        dev_list += [dev_entry.name]

    dev = []
    for device in bpy.context.user_preferences.addons['cycles'].preferences.devices:
        if device.use == True:
            dev += [device.name]
    if not dev:
        dev += ["CPU"]

    # Selected Abstraction Device (CPU or GPU)
    dev_scn = bpy.context.scene.cycles.device
    dev_scn_list = ["CPU", "GPU"]

    # pretty print
    lines=[
    ("Property", "Value", "Possible Values"),
    ("Device Type:", str(devt), str(devt_list)),
    ("Device:", str(dev), str(dev_list)),
    ("Scene Device:", str(dev_scn), str(dev_scn_list)),
    ]
    print("\nGPU compute configuration:")
    for l in lines:
        print("{0:<20} {1:<40} {2:<50}".format(*l))

    # Expected Output:
    #   GPU compute configuration:
    #   Property             Value                Possible Values
    #   Device Type:         NONE                 ['NONE']
    #   Device:              CPU                  ['CPU']