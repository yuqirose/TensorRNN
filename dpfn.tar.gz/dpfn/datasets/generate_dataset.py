#!/usr/bin/python3

from __future__ import print_function
from subprocess import call, check_output
import argparse
import shutil
import glob
import numpy as np
import scipy as sp
import re

import os, sys, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir+"/src/")
from dataset.datasets import DataBlock
from dataset import uniio

parser = argparse.ArgumentParser()
parser.add_argument("-m", "--manta", type=str, default="../mantaflow/build/Release/manta", help="path to manta binary")
parser.add_argument("--scene", type=str, default="../mantaflow/scenes/dpfn_dataset.py", help="path to scene to be used in each manta execution. you should probably not change this if you don't know what you are doing")
parser.add_argument('-t', "--type", default='water', const='water', nargs='?', choices=['water', 'smoke'], help='simulation type (default: %(default)s)')
parser.add_argument("-s", "--steps_per_scene", type=int, default=250, help="number of steps per scene")
parser.add_argument("-n", "--num_scenes", type=int, default=20, help="number of scenes in to execute")
parser.add_argument("-w", "--warmup_steps", type=int, default=75, help="number of steps to process without saving to disk")
parser.add_argument("-o", "--output_path", type=str, default="./dpfn_dataset/", help="location of the generated .npz")
parser.add_argument("--no_pressure_static", action="store_true")
parser.add_argument("--no_pressure_dynamic", action="store_true")
parser.add_argument("--no_velocity", action="store_true")
parser.add_argument("--no_levelset", action="store_true")
parser.add_argument("-g", "--gui", action="store_true")
parser.add_argument("--seed", type=int, default=1337, help="The seed with which the manta scene is randomized")
parser.add_argument("--generate_multiple", type=int, default=1, help="Generate multiple datasets with given settings but increasing seed.")
parser.add_argument("--dont_merge_ghost_fluid", action="store_true")
parser.add_argument("--load_from_uni", action="store_true", help="don't simulate with mantaflow, just load unis and convert to npz")
parser.add_argument("--skip_steps", type=int, default=1, help="number of steps between write outs")
parser.add_argument("--obstacles", action="store_true", help="add obstacles to the scene")
args = parser.parse_args()

# get git revision of mantaflow submodule
git_revision = check_output(["git", "submodule", "status", "../mantaflow"], universal_newlines=True)
git_revision = git_revision.strip().split() # e.g. ['0aebbd93c2d62dea7143176de917203741b79715', '../mantaflow', '(heads/master)']

version = git_revision[0][:8] # first eight chars are unique for small projects < 30k commits
if version[0] is "+":
    print("\nWARNING: generating dataset with manta revision {} that is not pushed yet and only accessible locally\n".format(version))
elif len(version) < 8:
    print("\nWARNING: version query of mantaflow submodule failed. Result: {}\n".format(version))

if args.generate_multiple < 1:
    parser.error("Minimum value of \"generate_multiple\" is 1")

if args.generate_multiple > 1 and args.load_from_uni:
    parser.error("It is not allowed to use \"generate_multiple\" and \"load_from_uni\" at the same time")

def main():
    # starting seed, gets increased generate_multiple times
    current_seed = args.seed

    # execute simulation with manta
    if not args.load_from_uni:
        # executable path
        manta_path = args.manta
        if os.path.isfile(manta_path) == False and os.name == 'nt':
            manta_path += ".exe"
        manta_path = os.path.abspath(manta_path)
        if not os.path.isfile(manta_path): 
            print("No mantaflow binary found at {}".format(manta_path))

        # fields to store
        stored_fields =  [] if args.no_pressure_static else ["--pressure_static"]
        stored_fields += [] if args.no_pressure_dynamic else ["--pressure_dynamic"]
        stored_fields += [] if args.no_velocity else ["--velocity"]
        stored_fields += [] if args.no_levelset else ["--levelset"]

        # additional settings
        additional_settings = ["-g"] if args.gui else []
        additional_settings += [] if args.dont_merge_ghost_fluid else ["--merge_ghost_fluid"]
        additional_settings += ["--obstacles"] if args.obstacles else []

        for i in range(args.generate_multiple):
            current_seed = args.seed + i
            manta_args = [manta_path, args.scene, "-t", str(args.type), "-n", str(args.num_scenes), "-s", str(args.steps_per_scene), "-w", str(args.warmup_steps), "--seed", str(current_seed),  "-o", args.output_path, "--skip_steps", str(args.skip_steps)] +stored_fields +additional_settings
            #print("Call: "+ " ".join(manta_args)) # debug info
            call(manta_args)
            serialize_fields(args, version, current_seed)
    else:
        serialize_fields(args, version, current_seed)


def __load_from_uni( dir, field_size = None, file_range = None):
    fields = []
    print('Reading data in ' + dir)
    # gather file list of all files with ending .uni in dir
    dirlist = glob.glob(dir+"*.uni")

    # natural sort the array
    convert = lambda text: int(text) if text.isdigit() else text
    dirlist.sort(key=lambda k: [ convert(c) for c in re.split('([0-9]+)', k) ] )
    # only load specified range of files
    if( file_range is not None):
        dirlist = dirlist[file_range[0]:file_range[1]]

    # load every file remaining in list
    for index, filename in enumerate(dirlist):
        # update outpu only occasionally 
        update_output = index % 50 == 0
        if(update_output):
            print("\rReading file {:06d} ".format(index), end=' ')
        # extract data from uni file (headers are ignored)
        field = uniio.readuni(filename)[1]
        # Remove the third dimension, so to gain a proper image
        if len(field[2]) != 1:
            field = field[...,np.newaxis]
        # resize field to specified size
        if field_size is not None:
            if update_output:
                print("converting from {}".format(list(field.shape)), end=' ')
            last_dim = int(field.shape[field.ndim - 1])
            resized_field = np.zeros((field_size[0], field_size[1], last_dim))
            for i in range(last_dim):
                resized_field[..., i] = sp.misc.imresize(arr=field[:,:,i], size=field_size, mode='F')
            field = resized_field
            if update_output:
                print("to {}".format(list(resized_field.shape)), end=' ')
        fields.append(field)
    print("\r                                                                                      ", end='\r')
    return np.array(fields)

def from_uni(path, scene_size, version, seed, resolution = None, file_range = None):
    """ create data block from .uni files """
    # load all uni files in directory to np array
    fields = __load_from_uni(dir=path, field_size = resolution, file_range = file_range)
    print('%d input files succesfully read from %s.' % (fields.shape[0], path))
    print("Dataset dimensions: {}".format(fields.shape))
    return DataBlock(data = fields, scene_size=scene_size, version=version, seed=seed)

def serialize_fields(args, version, seed):
    if args.no_pressure_static == False:
        block = from_uni(scene_size=args.steps_per_scene, version=version, seed=seed, path=args.output_path + "pressure_static/")
        block.serialize(file_path=args.output_path + "pressure_static_{}_{}_{}.npz".format(args.num_scenes, args.steps_per_scene, seed))
        print("Pressure Static:\n\tCreation Date: {}\n\tSeed: {}\n\tVersion: {}".format(block.creation_date, block.seed, block.version))
        del block
    shutil.rmtree(args.output_path + "pressure_static/")

    if args.no_pressure_dynamic == False:
        block = from_uni(scene_size=args.steps_per_scene, version=version, seed=seed, path=args.output_path + "pressure_dynamic/")
        block.serialize(file_path=args.output_path + "pressure_dynamic_{}_{}_{}.npz".format(args.num_scenes, args.steps_per_scene, seed))
        print("Pressure Dynamic:\n\tCreation Date: {}\n\tSeed: {}\n\tVersion: {}".format(block.creation_date, block.seed, block.version))
        del block
    shutil.rmtree(args.output_path + "pressure_dynamic/")

    if args.no_velocity == False:
        block = from_uni(scene_size=args.steps_per_scene, version=version, seed=seed, path=args.output_path + "velocity/")
        block.serialize(file_path=args.output_path + "velocity_{}_{}_{}.npz".format(args.num_scenes, args.steps_per_scene, seed))
        print("Velocity:\n\tCreation Date: {}\n\tSeed: {}\n\tVersion: {}".format(block.creation_date, block.seed, block.version))
        del block
    shutil.rmtree(args.output_path + "velocity/")

    if args.no_levelset == False:
        block = from_uni(scene_size=args.steps_per_scene, version=version, seed=seed, path=args.output_path + "levelset/")
        block.serialize(file_path=args.output_path + "levelset_{}_{}_{}.npz".format(args.num_scenes, args.steps_per_scene, seed))
        print("Levelset:\n\tCreation Date: {}\n\tSeed: {}\n\tVersion: {}".format(block.creation_date, block.seed, block.version))
        del block
    shutil.rmtree(args.output_path + "levelset/")

# execute the generation
if __name__ == "__main__":
    main()
