
## Generate training data

cd dpfn/mantaflow


# Linux
Low Res Dataset:
    ./build/manta scenes/dpfn_dataset.py --name liquid -n 100 -s 100 -w 50 --meshes --seed 1
Generates a dataset of 100 scenes (-n) with 100 time steps each (-s) and 50 pre-warming steps (-w) that are not saved to file.
Meshes are added randomly (like drops) when --meshes is used. 

High Res Dataset:
    ./build/manta scenes/dpfn_dataset.py --name liquid128 -n 100 -s 100 -w 50 --meshes --seed 1 -r 128

Write to different disk:
    ./build/manta scenes/dpfn_dataset.py --datasets_path /mnt/raid/xx/datasets --name liquid128 -n 500 -s 100 -w 50 --meshes --seed 1 -r 128



# Windows
    .\build\Release\manta scenes/dpfn_dataset.py --name liquid -n 100 -s 100 -w 50 --meshes --seed 1
    





## Predict scenes

.\build\Release\manta scenes/dpfn_prediction.py --name liquid --project liquid_25 -w 40 -i 5 --seed 1