!/bin/bash

INTERVAL=1000
STEPS=200

#for ((i = 0; i < 10; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec128_ref_$i -s $STEPS --project total_liquid128_25 --prediction_type naive --benchmark $i -hr -obd -ord -i 0; done
#for ((i = 6; i < 8; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec_vel_$i -s $STEPS --project vel_liquid_25 --prediction_type velocity --benchmark $i -obd -ord -i $INTERVAL; done
#for ((i = 0; i < 10; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec128_total_$i -s $STEPS --project total_liquid128_25 --prediction_type total_pressure --benchmark $i -hr -obd -ord -i $INTERVAL; done
for ((i = 4; i < 5; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec128_split_$i -s $STEPS --project split_liquid128_25 --prediction_type split_pressure --benchmark $i -hr -obd -ord -i $INTERVAL; done
#for ((i = 6; i < 8; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec_naive_$i -s $STEPS --project split_liquid_25 --prediction_type naive --benchmark $i -obd -ord -i $INTERVAL; done
#for ((i = 6; i < 8; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec_vae_$i -s $STEPS --project vae_split_liquid_25 --prediction_type split_pressure --benchmark $i -obd -ord -i $INTERVAL; done
#for ((i = 0; i < 10; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec_split_dynamic_$i -s $STEPS --project split_liquid_25 --prediction_type splitdyn_pressure --benchmark $i -obd -ord -i $INTERVAL; done
#for ((i = 0; i < 10; i++)); do build/Release/manta scenes/dpfn_encode_decode.py --name encdec_dynamic_$i -s $STEPS --project liquid_dynamic --prediction_type dynamic_pressure --benchmark $i -obd -ord -i $INTERVAL; done
