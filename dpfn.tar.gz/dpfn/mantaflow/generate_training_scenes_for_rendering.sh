#! /bin/bash
for i in {0..9}
do
    #./build/manta scenes/dpfn_prediction.py --name liquid_reference_Bench$i -w 50 -s 150 --project naive_static_pressure -i 0 -pt naive_static_pressure -ord --seed 1 --no_gui --benchmark $i
    ./build/manta scenes/scenes/generate_obj_scene.py --motion_blur 4 -i ../predictions/liquid_reference_Bench$i/uni/ -o ../predictions/liquid_reference_Bench$i/obj/
done

for i in {40..60}
do
    ./build/manta scenes/scenes/generate_obj_scene.py --motion_blur 4 -i ../predictions/TrainingScene_$i/uni/ -o ../predictions/TrainingScene_$i/obj/
done
