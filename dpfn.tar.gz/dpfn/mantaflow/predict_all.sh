#!/bin/bash

## Run all benchmark scenes
#==========================
INTERVAL=15
STEPS=250
WARMUP=50

# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_ref -s $STEPS --project total_liquid_25 --prediction_type total_pressure --benchmark $i -obd -ord -i 0 -w $WARMUP --no_gui; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_i5 -s $STEPS --project total_liquid_25 --prediction_type total_pressure --benchmark $i -obd -ord -i 5 -w $WARMUP --no_gui; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_i10 -s $STEPS --project total_liquid_25 --prediction_type total_pressure --benchmark $i -obd -ord -i 10 -w $WARMUP --no_gui; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_i15 -s $STEPS --project total_liquid_25 --prediction_type total_pressure --benchmark $i -obd -ord -i 15 -w $WARMUP --no_gui; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_i1000 -s $STEPS --project total_liquid_25 --prediction_type total_pressure --benchmark $i -obd -ord -i 1000 -w $WARMUP --no_gui; done

# # for ((i = 0; i < 1; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_split_$i -s $STEPS --project split_liquid_25 --prediction_type split_pressure --benchmark $i -obd -ord -i $INTERVAL; done
# # for ((i = 0; i < 1; i++)); do build/Release/manta scenes/dpfn_prediction.py --name predict_vae_$i -s $STEPS --project vae_split_liquid_25 --prediction_type split_pressure --benchmark $i -obd -ord -i $INTERVAL; done

# # Generate OBJ
# #=============
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/scenes/generate_obj_scene.py -i ../predictions/predict_ref_Bench$i/uni/ -o ../predictions/predict_ref_Bench$i/obj/; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/scenes/generate_obj_scene.py -i ../predictions/predict_i5_Bench$i/uni/ -o ../predictions/predict_i5_Bench$i/obj/; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/scenes/generate_obj_scene.py -i ../predictions/predict_i10_Bench$i/uni/ -o ../predictions/predict_i10_Bench$i/obj/; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/scenes/generate_obj_scene.py -i ../predictions/predict_i15_Bench$i/uni/ -o ../predictions/predict_i15_Bench$i/obj/; done
# for ((i = 4; i < 5; i++)); do build/Release/manta scenes/scenes/generate_obj_scene.py -i ../predictions/predict_i1000_Bench$i/uni/ -o ../predictions/predict_i1000_Bench$i/obj/; done



cd ../blender
# for ((i=4; i < 5; i++)); do blender FluidOpaqueRender.blend --background --python RenderFluid.py -- -i "../predictions/predict_ref_Bench$i/obj/" -o "/Users/mob/Desktop/CharSync/becher/opaque/256/interval_liquid64/ref_$i/Render_" -sf 0 -fs 1 -ef 299 -x 256 -y 256 --gpu --type reference; done
# for ((i=4; i < 5; i++)); do blender FluidOpaqueRender.blend --background --python RenderFluid.py -- -i "../predictions/predict_i5_Bench$i/obj/" -o "/Users/mob/Desktop/CharSync/becher/opaque/256/interval_liquid64/i5_$i/Render_" -sf 0 -fs 1 -ef 299 -x 256 -y 256 --gpu --type network --architecture total_pressure; done
for ((i=4; i < 5; i++)); do blender FluidOpaqueRender.blend --background --python RenderFluid.py -- -i "../predictions/predict_i10_Bench$i/obj/" -o "/Users/mob/Desktop/CharSync/becher/opaque/256/interval_liquid64/i10_$i/Render_" -sf 0 -fs 1 -ef 299 -x 256 -y 256 --gpu --type network --architecture total_pressure; done
for ((i=4; i < 5; i++)); do blender FluidOpaqueRender.blend --background --python RenderFluid.py -- -i "../predictions/predict_i15_Bench$i/obj/" -o "/Users/mob/Desktop/CharSync/becher/opaque/256/interval_liquid64/i15_$i/Render_" -sf 0 -fs 1 -ef 299 -x 256 -y 256 --gpu --type network --architecture total_pressure; done
for ((i=4; i < 5; i++)); do blender FluidOpaqueRender.blend --background --python RenderFluid.py -- -i "../predictions/predict_i1000_Bench$i/obj/" -o "/Users/mob/Desktop/CharSync/becher/opaque/256/interval_liquid64/i1000_$i/Render_" -sf 0 -fs 1 -ef 299 -x 256 -y 256 --gpu --type network --architecture total_pressure; done
