# Copyright (c) 2018 Moritz Becher and Steffen Wiewel

from __future__ import print_function

import pathlib
import numpy as np
import argparse
from random import randint, seed
import subprocess
import time
import json
from subprocess import call
import os

# Example Call
# python .\benchmark_projects.py --projects split_liquid_25 split_liquid_mixed_enc_timeconv_dec_25 split_liquid_timeconv_dec_25 split_liquid_timeconv_dec_25_MSE -s 50 -i 100
# python .\benchmark_projects.py --projects total_liquid_25 -s 50 -i 100

#----------------------------------------------------------------------------------

parser = argparse.ArgumentParser()
parser.add_argument("-md", "--manta_dir", type=str, default="../mantaflow/", help="path to manta main directory")
parser.add_argument("-mb", "--manta_bin", type=str, default="build/Release/manta", help="path to manta binary")
parser.add_argument("-pd", "--project_dir", type=str, default="../projects/", help="path to the project directory")

parser.add_argument("--projects", nargs='+', required=True, help="The names of the projects to load.")
parser.add_argument("--custom_names", nargs='+', help="Custom names to replace the project name with.")
parser.add_argument("-o", "--output", default="./", help="directory to which the output is written")
parser.add_argument("-s", "--simulation_steps", type=int, default=140, help="number of simulation steps for a scene. must be constant for all scenes")
parser.add_argument("-w", "--warmup_steps", type=int, default=50, help="number of steps to discard in the beginning of the scene")
parser.add_argument("-i", "--interval", nargs='+', type=int, default=[10], help="interval at which the pressure solve should occur. Default: every 2nd step")
parser.add_argument("--benchmarks", nargs='+', type=int, default=[0,1,2,3,4,5,6,7,8,9], help="Benchmarks to execute")
parser.add_argument("--predict_dynamic_only", action="store_true")
parser.add_argument("--no_gui", action="store_true")
parser.add_argument("--no_output", action="store_true")
parser.add_argument("--profile", action="store_true")

# Arguments
#----------------------------------------------------------------------------
args = parser.parse_args()

# executable path
manta_path = args.manta_dir + args.manta_bin
if os.path.isfile(manta_path) == False:
    manta_path += ".exe"
    assert os.path.isfile(manta_path), "No mantaflow binary found"
prediction_scene = args.manta_dir + "scenes/dpfn_prediction.py"
assert os.path.isfile(prediction_scene), "No prediction scene found"

use_custom_names = args.custom_names != None

# custom names check
if use_custom_names:
    assert len(args.custom_names) == len(args.projects), ("There need to be the same amount of custom names and projects.")

for i, project in enumerate(args.projects):
    print("Project '{}'".format(project))

    highres = False
    if project.find("liquid128") > -1 or project.find("smoke128") > -1:
        highres = True

    pred_type = "split_pressure"
    if project.startswith("split"):
        pred_type = "split_pressure"
    elif project.startswith("dynamic"):
        pred_type = "dynamic_pressure"
    elif project.startswith("total"):
        pred_type = "total_pressure"
    elif project.startswith("vel"):
        pred_type = "velocity"
    elif project.startswith("naive_dynamic_pressure"):
        pred_type = "naive_dynamic_pressure"
    elif project.startswith("naive_static_pressure"):
        pred_type = "naive_static_pressure"
    elif project.startswith("naive_velocity"):
        pred_type = "naive_velocity"

    output_dir = args.output
    output_dir += "interval_{}_highres/" if highres else "interval_{}/"

    for benchmark in args.benchmarks:
        print("\tBenchmark {}".format(benchmark))
        for interval in args.interval:
            scene_args = []
            if not args.no_output:
                scene_args += ["-ord"]
                scene_args += ["-obd"]
            scene_args += ["--seed", "1"]
            scene_args += ["-o", output_dir.format(interval)]

            scene_args += ["--name", str(args.custom_names[i])] if use_custom_names else []

            scene_args += ["-s", str(args.simulation_steps)]
            scene_args += ["-w", str(args.warmup_steps)]
            scene_args += ["-pt", str(pred_type)]
            scene_args += ["-i", str(interval)]
            scene_args += ["--highres"] if highres else []
            scene_args += ["--predict_dynamic_only"] if args.predict_dynamic_only and pred_type == "split_pressure" else []
            scene_args += ["--no_gui"] if args.no_gui else []
            scene_args += ["--profile"] if args.profile else []
            scene_args += ["--benchmark", str(benchmark)]
            scene_args += ["--project", str(project)]
            print(scene_args)
            call([manta_path, prediction_scene, *scene_args])
