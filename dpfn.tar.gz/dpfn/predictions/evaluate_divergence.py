# Copyright (c) 2018 Moritz Becher and Steffen Wiewel

from __future__ import print_function

import pathlib
import numpy as np
import argparse
from random import randint, seed
import subprocess
import time
import json
from subprocess import call
import os

# Example Call
# python .\evaluate_divergence.py --name liquid_base_comparison -r liquid_reference --projects split_liquid_25 total_liquid_25 vel_liquid_25 vae_split_liquid_25 -cd interval_1000/ 

#----------------------------------------------------------------------------------
def make_dir(directory):
    """ 
    check if directory exists, otherwise makedir
    
    (workaround for python2 incompatibility)
    """
    if not os.path.exists(directory):
        os.makedirs(directory)

#----------------------------------------------------------------------------
def plot(metric_list, legend_list, metric_name, title="", path="", first=0, height=1.0, differences=False, differences_name=""):
    from matplotlib import pyplot as plt
    import matplotlib.widgets as wgt
    from matplotlib.ticker import MaxNLocator

    fig, ax = plt.subplots(1,1,figsize=(8,int(height * 8.0)))
    if differences:
        ax_diff = ax.twinx()
    for i, metric in enumerate(metric_list):
        x = np.arange(first, first + len(metric))
        ax.plot(x, metric)
        if differences:
            diff = np.gradient(metric)
            ax_diff.plot(x, diff, linestyle='dotted')

    ax.grid()

    plt.title(title)
    ax.set_ylabel(metric_name)
    ax.set_xlabel(r"Time step $t$")
    ax.xaxis.set_major_locator(MaxNLocator(integer=True)) # force integer values on epoch axis
    ax.legend(legend_list, loc="upper left")
    if differences:
        ax_diff.set_ylabel(differences_name)
        diff_legend_list = [r"$\frac{d e_h}{d t}$   " + l for l in legend_list]
        ax_diff.legend(diff_legend_list, loc="lower right")
    if path:
        fig.savefig(path, bbox_inches='tight')


#----------------------------------------------------------------------------------

parser = argparse.ArgumentParser()
parser.add_argument("--name", type=str, required=True, help="Name of the comparison run")
parser.add_argument("-o", "--output", default="", help="directory to which the output is written. Default is the predictions directory.")

parser.add_argument("-r", "--reference", type=str, help="Name of the reference levelset")

parser.add_argument("-cd", "--change_dir", type=str, default="./", help="path to the directory the benchmarks reside")
parser.add_argument("--projects", nargs='+', required=True, help="The names of the projects to load.")
parser.add_argument("--custom_names", nargs='+', help="Custom names to replace the project name with.")
parser.add_argument("-s", "--suffix", type=str, default="_Bench{}", help="File Suffix")
parser.add_argument("--prefix", type=str, default="", help="The prefix of the comparison_ls directories. Used to remove it from the legend of the plots.")

parser.add_argument("-ms", "--max_steps", type=int, default=-1, help="number of simulation steps to work on after the warmup steps")
parser.add_argument("-w", "--warmup_steps", type=int, default=50, help="number of steps to discard in the beginning of the scene")
parser.add_argument("--benchmarks", nargs='+', type=int, default=[0,1,2,3,4,5,6,7,8,9], help="Benchmarks to execute")

parser.add_argument("--height", type=float, default=1.0, help="Ratio of height to width")
parser.add_argument("--differences", action="store_true", help="Plot derivatives with graph")
# Arguments
#----------------------------------------------------------------------------
args = parser.parse_args()
output_path = "."
if args.output:
    output_path = str(pathlib.Path(args.output).resolve())

output_path += "/" + args.change_dir + args.name + "/"

output_path += "divergence/"
make_dir(output_path)
print("Output path: {}".format(output_path))

with open(output_path + "arguments.json", 'w') as f:
    json.dump(vars(args), f, indent=4)

#----------------------------------------------------------------------------
predictions_dir = str(pathlib.Path(".").resolve()) + "/" + args.change_dir
reference_dir = str(pathlib.Path(".").resolve()) + "/" + args.reference
assert os.path.exists(predictions_dir), ("The specified predictions directory does not exist or could not be found")

# Gather Data
#----------------------------------------------------------------------------
# mae per frame of all projects

proj_count = len(args.projects)
if args.reference:
    proj_count += 1

mean_div = [None] * proj_count

for i, project in enumerate(args.projects):
    proj_dir = predictions_dir + project + args.suffix + "/"
    proj_mean_div = None
    for bench in args.benchmarks:
        bench_dir = proj_dir.format(bench)
        assert os.path.exists(bench_dir), ("The specified benchmark directory ({}) does not exist or could not be found".format(bench_dir))

        with open(bench_dir+"divergence_hist.json", 'r') as f:
            div_hist = json.load(f)
        div_hist = div_hist[args.warmup_steps:]
        if args.max_steps:
            div_hist = div_hist[:args.max_steps]

        if proj_mean_div is None:
            proj_mean_div = np.array(div_hist)
        else:
            proj_mean_div += np.array(div_hist)
    proj_mean_div /= len(args.benchmarks)

    mean_div[i] = np.array(proj_mean_div)

if args.reference:
    proj_mean_div = None
    for bench in args.benchmarks:
        bench_dir = (str(pathlib.Path(".").resolve()) + "/" + args.reference + args.suffix + "/").format(bench)
        assert os.path.exists(bench_dir), ("The specified reference directory ({}) does not exist or could not be found".format(bench_dir))

        with open(bench_dir+"divergence_hist.json", 'r') as f:
            div_hist = json.load(f)
        div_hist = div_hist[args.warmup_steps:]
        if args.max_steps:
            div_hist = div_hist[:args.max_steps]

        if proj_mean_div is None:
            proj_mean_div = np.array(div_hist)
        else:
            proj_mean_div += np.array(div_hist)
    proj_mean_div /= len(args.benchmarks)

    proj_mean_div = proj_mean_div[:len(mean_div[0])]
    mean_div[proj_count-1] = np.array(proj_mean_div)

# Plot Results
#----------------------------------------------------------------------------
legend = []
project_legends = args.projects
if args.reference:
    project_legends.append(args.reference)
if args.custom_names:
    project_legends = args.custom_names
for project in project_legends:
    legend.append(project.replace(args.prefix, "").replace("_", " ")) 

# plot
plot(mean_div, legend, "Mean Divergence", path=output_path+"mean_divergence.svg", height=args.height, first=args.warmup_steps)







