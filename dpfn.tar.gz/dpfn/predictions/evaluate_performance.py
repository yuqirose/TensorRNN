import os
import json
import numpy as np
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-d", "--dir", type=str, required=True)
parser.add_argument("-s", "--subfolder_name", type=str, required=True)
args = parser.parse_args()


directory = args.dir #"interval_0_highres/"
subfolder = "/"+args.subfolder_name # "split_liquid128_1000_25"

total_duration = 0
mean_step_duration_full_sim = 0.0
interval = 0
simulation_steps = 0
warmup_steps = 0
profile_history_timestep = None
mean_per_timestep_no_warmup = 0.0
mean_per_timestep_with_warmup = 0.0
profile_history_solve = None
mean_per_solve_no_warmup = 0.0
mean_per_solve_with_warmup = 0.0

counter = 0

r = []
for root, dirs, files in os.walk(directory):
    for name in files:
        if name == "profile.json":
            file_name = os.path.join(root, name)
            if subfolder not in file_name:
                continue
            print(file_name)

            counter += 1

            data = json.load(open(file_name))
            
            total_duration += data["total_duration"]
            mean_step_duration_full_sim += data["mean_step_duration_full_sim"]
            interval += data["interval"]
            simulation_steps += data["simulation_steps"]
            warmup_steps += data["warmup_steps"]

            mean_per_timestep_no_warmup += data["mean_per_timestep_no_warmup"]
            mean_per_timestep_with_warmup += data["mean_per_timestep_with_warmup"]

            mean_per_solve_no_warmup += data["mean_per_solve_no_warmup"]
            mean_per_solve_with_warmup += data["mean_per_solve_with_warmup"]

            if profile_history_timestep is None:
                profile_history_timestep = np.array(data["profile_history_timestep"])
            else:
                profile_history_timestep += np.array(data["profile_history_timestep"])

            if profile_history_solve is None:
                profile_history_solve = np.array(data["profile_history_solve"])
            else:
                profile_history_solve += np.array(data["profile_history_solve"])

assert counter == 10, ("not enough data")

total_duration /= counter
mean_step_duration_full_sim /= counter
warmup_steps /= counter
interval /= counter
simulation_steps /= counter

profile_history_timestep /= counter
mean_per_timestep_no_warmup /= counter
mean_per_timestep_with_warmup /= counter

profile_history_solve /= counter
mean_per_solve_no_warmup /= counter
mean_per_solve_with_warmup /= counter

profile_history_timestep = profile_history_timestep.tolist()
profile_history_solve = profile_history_solve.tolist()

data = {}
data["total_duration"] = total_duration
data["mean_step_duration_full_sim"] = mean_step_duration_full_sim
data["interval"] = interval
data["simulation_steps"] = simulation_steps
data["warmup_steps"] = warmup_steps
data["profile_history_timestep"] = profile_history_timestep
data["mean_per_timestep_no_warmup"] = mean_per_timestep_no_warmup
data["mean_per_timestep_with_warmup"] = mean_per_timestep_with_warmup
data["profile_history_solve"] = profile_history_solve
data["mean_per_solve_no_warmup"] = mean_per_solve_no_warmup
data["mean_per_solve_with_warmup"] = mean_per_solve_with_warmup

with open(directory + args.subfolder_name+"_total_profile.json", 'w') as f:
    json.dump(data, f, indent=4)















