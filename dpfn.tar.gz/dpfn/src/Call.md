
## Train and evaluate both networks

cd dpfn\src


# Train AE only

    python main.py --name liquid --dataset liquid --ae_epochs 40 --lstm_epochs 0


# Train AE and LSTM

    python main.py --name liquid --dataset liquid --ae_epochs 40 --lstm_epochs 20 --chunk_size 30


# Load AE and train LSTM

    python train_total.py --name liquid --dataset liquid --ae_load liquid --ae_test --lstm_epochs 20 [--chunk_size 20 OR --lstm_load_dataset]

In the preprocessing before training the lstm network, the lstm dataset is saved to disk.
This file can be reused by adding --lstm_load_dataset to the parameters. Loading will be much faster.



## Search for hyperparameters

cd dpfn\src

    python parameter_search.py --name liquid --dataset liquid_hypersearch --ae_load --lstm_load_dataset --lstm_epochs 20 --lstm_parameter learning_rate,random,float,[0.1,0.5],3 decoder_lstm_neurons,list,int,[0,1,2,3]
Lstm parameter is defined as: parameter name (class member name), range in which to randomly select parameter values, count of random samples, data type (int and float is supported for now)



## Server
    python main.py --name liquid --dataset mnt/liquid --ae_load --ae_test --lstm_epochs 20 [--chunk_size 20 OR --lstm_load_dataset]

Use the mnt directory for the dataset projects.




## Evaluation
    python train_total.py --name total_liquid_25 --dataset mnt/liquid --ae_load total_liquid_25 --ae_test --lstm_load --lstm_epochs 0 --lstm_evaluate --lstm_load_dataset