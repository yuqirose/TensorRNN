from upscale import VelocityDreamer
import logging
import shutil
import argparse
import datetime
import os
import time
import logging
import pathlib

import numpy as np
from keras import backend as K
import tensorflow as tf
from functools import partial
from pathlib import Path
from helpers.plot import Plotter
from helpers.losses import *


def print_metrics(x, y):
    print("MSE: {}".format(tf.reduce_sum(MSE()(x,y)).eval(session=K.get_session())))
    print("MAE: {}".format(tf.reduce_sum(MAE()(x,y)).eval(session=K.get_session())))
    div = Divergence()(y[np.newaxis,...], x[np.newaxis,...])
    print("Divergence True: {}".format(tf.reduce_sum(div).eval(session=K.get_session())))
    div = Divergence()(x[np.newaxis,...], y[np.newaxis,...])
    print("Divergence Pred: {}".format(tf.reduce_sum(div).eval(session=K.get_session())))  

#--------------------------------------------------------------------------------------------------------------------
# Parse arguments
parser = argparse.ArgumentParser()
# General
general = parser.add_argument_group("General")
general.add_argument("--ae_type", default="velocity", choices=['velocity', 'pressure', 'levelset', 'multi', 'total_pressure'], help="Fields to train the autoencoder on")

# Training
training = parser.add_argument_group("Training")
training.add_argument("--ae_epochs", type=int, default=0, help="Number of epochs to train the Autoencoder")
training.add_argument("--ae_pretrain_epochs", type=int, default=0, help="Number of epochs to pretrain the Autoencoder")
training.add_argument("--gan_epochs", type=int, default=0, help="Number of epochs to train the GAN")
training.add_argument("--disc_epochs", type=int, default=3, help="Number of epochs to pretrain the Discriminator. GAN epochs must be != 0 for discriminator training to take place")
training.add_argument("--batch_size", type=int, default=128, help="The batch size used in all training")
training.add_argument("--dataset_range", type=int, default=25000, help="Number of dataset samples per epoch")

# Dataset
dataset = parser.add_argument_group("Dataset")
dataset.add_argument("-d", "--dataset_path", default="mo/vus_dataset", help="Directory of the training data")
dataset.add_argument("--reload_data", dest='reload_data', action='store_true', default=False, help="Force reload data from unifiles instead of serialized scenes")
dataset.add_argument("-n", "--normalization_percentile", type=float, default=99.5,  help="The percentage [0,100] of data values that should fall below the normalization factor value")

# Checkpoints
checkpoints = parser.add_argument_group("Checkpoints")
checkpoints.add_argument("-c","--model_path", help="Path of the autoencoder checkpoint .h5 file")
checkpoints.add_argument("--discriminator_path", type=str, help="Load a pretrained discriminator from a .h5 file")
checkpoints.add_argument("-o","--output_path", default="mo/output/", help="Path where to put checkpoints of this run. Note that a timestamp will always be added at the end of the path to avoid unintended overwrite")

args = parser.parse_args()

#--------------------------------------------------------------------------------------------------------------------
# Create output directories
tmp_output_path = args.output_path + datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + "/"
os.makedirs(tmp_output_path, exist_ok=True)
if os.path.exists(args.output_path + "current"):
    os.remove(args.output_path + "current")
os.symlink(Path(tmp_output_path).resolve().as_posix(), args.output_path + "current",  target_is_directory=True)
output_path = tmp_output_path

#--------------------------------------------------------------------------------------------------------------------
# Setup the logger
logging.basicConfig(format='----------------------------------------------------------------------------\n%(message)s', filename=output_path + "training.log",level=logging.INFO)

#--------------------------------------------------------------------------------------------------------------------
# Create the model manager
vel_dreamer = VelocityDreamer()

try:
    # load data
    vel_dreamer.load_data(path=args.dataset_path, force_reload=args.reload_data, normalization_percentile=args.normalization_percentile)

    vel_dreamer.build_autoencoder(args.ae_type)

    if args.model_path:
        vel_dreamer.load_model(args.model_path)

    if args.ae_pretrain_epochs != 0:
        vel_dreamer.pretrain_ae(epochs=args.ae_pretrain_epochs, batch_size=args.batch_size, range=args.dataset_range)

    if args.ae_epochs != 0:
        vel_dreamer.train_ae(epochs=args.ae_epochs, batch_size=args.batch_size, range=args.dataset_range)

    if args.gan_epochs != 0:
        vel_dreamer.build_discriminator_model()
        vel_dreamer.pretrain_discriminator(epochs=args.disc_epochs)
        vel_dreamer.build_gan_model()
        vel_dreamer.train_gan(epochs=args.gan_epochs)

    vel_dreamer.save_model(output_path + "autoencoder.h5")
    #shutil.copy("upscale.py", vel_dreamer.output_path)

    plotter = Plotter()

    step = 1593

    if args.ae_type == 'velocity':
        xs = vel_dreamer.dataset.velocity[90000:100000:step]
        ls = vel_dreamer.dataset.levelset[90000:100000:step]
        ys = vel_dreamer.predict([xs, ls])
        for x, y in zip(xs, ys):
            # x = np.multiply(x, 25.0)
            # y = np.multiply(y, 25.0)
            plotter.plot_vector_field(x,y)
            print_metrics(x, y)
            
    elif args.ae_type == 'pressure':
        xs_static = vel_dreamer.dataset.static_pressure[90000:100000:step]
        xs_dynamic = vel_dreamer.dataset.dynamic_pressure[90000:100000:step]
        ys = vel_dreamer.autoencoder.predict_combined([xs_static, xs_dynamic], norm_factor_static = 30.0, norm_factor_dynamic=12.0)
        ys_static, ys_dynamic = vel_dreamer.autoencoder.predict([xs_static, xs_dynamic])
        xs = np.add(np.multiply(xs_static, 30.0), np.multiply(xs_dynamic, 12.0))
        for x, y in zip(xs, ys):
            plotter.plot_heatmap(x,y)
        for x, y in zip(xs, ys):
            se = (x - y) ** 2
            plotter.plot_single(se)
        # for x, y in zip(xs_static, ys_static):
        #     plotter.plot_heatmap(x,y)
        # for x, y in zip(xs_dynamic, ys_dynamic):
        #     plotter.plot_heatmap(x,y)

    elif args.ae_type == 'levelset':
        xs = vel_dreamer.dataset.levelset[90000:100000:step]
        ys = vel_dreamer.predict(xs)
        for x, y in zip(xs, ys):
            plotter.plot_heatmap(x, y)

    elif args.ae_type == 'multi':
        xs = [vel_dreamer.dataset.velocity[90000:100000:step], vel_dreamer.dataset.pressure[90000:100000:step], vel_dreamer.dataset.levelset[90000:100000:step]]
        ys = vel_dreamer.predict(xs)
        for x, y in zip(xs[1], ys):
            plotter.plot_heatmap(x,y)

    elif args.ae_type == 'total_pressure':
        xs = vel_dreamer.dataset.pressure[90000:100000:step]
        ys = vel_dreamer.predict(xs)
        for x, y in zip(xs, ys):
            plotter.plot_heatmap(x,y)
        for x, y in zip(xs, ys):
            se = np.abs(x - y)
            plotter.plot_single(se)

    plotter.save_figures(output_path)

    plotter.show(block=True)

except KeyboardInterrupt:
    print("User interrupt")