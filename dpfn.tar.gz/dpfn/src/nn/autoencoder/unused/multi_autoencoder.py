import keras
from keras.optimizers import Adam
from keras import objectives
from keras.layers import *
from keras.layers.pooling import AveragePooling2D, MaxPooling2D
from keras.models import Model
import logging
import keras.backend as K
import tensorflow as tf

#from helpers.upsampling import *
from helpers.stages import *
from helpers.helpers import *
from helpers.losses import *

def _sampling(args):
    z_mean, z_log_sigma = args
    epsilon = K.random_normal(shape=(K.shape(z_mean)[0], K.shape(z_mean)[1]), mean=0.0, std=0.3)
    return z_mean + K.exp(z_log_sigma) * epsilon

#=====================================================================================
class MultiAutoencoder(object):
    #---------------------------------------------------------------------------------
    def __init__(self, vel_shape, pres_shape, ls_shape):
        init = 'glorot_normal'
        self._trainable = True
        self.weight_decay = 1e-5
        self.learning_rate = 0.002 #3e-4

        # ENCODER ##################################################################################   
        velocity_input = Input(shape=vel_shape)
        pressure_input = Input(shape=pres_shape)
        levelset_input = Input(shape=ls_shape)

        
        encoder_stages = StagedModel()
        encoder_stages.start([velocity_input, pressure_input, levelset_input])
        
        x = merge([velocity_input, pressure_input, levelset_input], mode='concat', concat_axis=3)

        # Conv #
        x = Conv2D(32, 2, 2, subsample=(2, 2), border_mode='same', init=init)(x)
        #x = BatchNormalization(mode=1)(x)
        x = Activation('tanh')(x)
        #x = Dropout(0.2)(x)

        x = encoder_stages.stage(x)

        # Conv #
        x = Conv2D(64, 2, 2, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = encoder_stages.stage(x)
        
        # Conv #
        x = Conv2D(128, 2, 2, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = encoder_stages.stage(x)

        # Conv #
        x = Conv2D(256, 2, 2, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = encoder_stages.stage(x)

        # Conv #
        x = Conv2D(512, 2, 2, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = encoder_stages.stage(x)

        # Flatten #
        conv_shape = (int(x.shape[1]), int(x.shape[2]), int(x.shape[3]))
        self._intermediate_dim = 512 #int(x.shape[1] * x.shape[2] * x.shape[3])

        x = Flatten()(x)
        x = Dense(self._intermediate_dim)(x)
        x = BatchNormalization(mode=1)(x)
        x = LeakyReLU(0.3)(x)
        
        self._z_size = 128
        x = Dense(self._z_size)(x)
        x = BatchNormalization(mode=1)(x)
        x = LeakyReLU(0.3)(x)
        
        # Stage 4 END #
        encoder_stages.end(x)

        # the following will be added to the autoencoder only and can not be part of the stage models due to some weird keras issue
        z_mean_layer = Dense(output_dim=self._z_size, activation="relu", init=init)
        z_log_sigma_layer = Dense(output_dim=self._z_size, activation="relu", init=init)
        z_layer = Lambda(_sampling, output_shape=(self._z_size,))

        # DECODER ####################################################################################################
        decoder_input = Input(shape=(self._z_size,))
        
        # Stage 4 BEGIN #
        decoder_stages = StagedModel()
        decoder_stages.start(decoder_input)
        
        x = Dense(self._intermediate_dim)(decoder_input)
        x = BatchNormalization(mode=1)(x)
        x = LeakyReLU(0.3)(x)

        x = Dense(conv_shape[0] * conv_shape[1] * conv_shape[2])(x)
        x = BatchNormalization(mode=1)(x)
        x = LeakyReLU(0.3)(x)

        x = Reshape(target_shape=conv_shape)(x)
        
        x = decoder_stages.stage(x)

        # Deconv #
        x = Conv2DTranspose(256, 2, 2, strides=(2,2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = decoder_stages.stage(x)

        # Deconv #
        x = Conv2DTranspose(128, 2, 2, strides=(2,2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = decoder_stages.stage(x)

        # Deconv #
        x = Conv2DTranspose(64, 2, 2, strides=(2,2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = decoder_stages.stage(x)


        # Deconv #
        x = Conv2DTranspose(32, 2, 2, strides=(2,2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)

        x = decoder_stages.stage(x)

        # Deconv #
        # x = UpSampling2D(size=(2, 2))(x)
        # x = Conv2D(3, 4, 4, border_mode='same', init=init)(x)
        x = Conv2DTranspose(1, 2, 2, strides=(2,2), border_mode='same', init=init)(x)
        decoder_output = Activation('tanh')(x)
        
        # Stage 1 END #
        decoder_stages.end(decoder_output)

        self._decoder = decoder_stages.model #Model(input=decoder_input, output = decoder_output)
        self._decoder.name = "Decoder"

        # AUTOENCODER #########################################################################################
        optimizer = Adam(lr=self.learning_rate, decay=self.weight_decay, epsilon=1e-3)
        loss = MAE()
        
        # Build staged autoencoder
        self._stages = []

        # Stage 1
        stage_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        x = encoder_stages[0:1](stage_input)
        stage_output = decoder_stages[5:6](x)
        stage_model = Model(input=stage_input, output=stage_output)
        #make_layers_trainable(self._stages[0], False)
        stage_model.compile(loss=loss, optimizer=optimizer, metrics=['mae'])
        self._stages.append(stage_model)
        
        # Stage 2
        stage_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        x = encoder_stages[0:2](stage_input)
        stage_output = decoder_stages[4:6](x)
        stage_model = Model(input=stage_input, output=stage_output)
        #make_layers_trainable(self._stages[1], False)
        stage_model.compile(loss=loss, optimizer=optimizer, metrics=['mae'])
        self._stages.append(stage_model)

        # Stage 3
        stage_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        x = encoder_stages[0:3](stage_input)
        stage_output = decoder_stages[3:6](x)
        stage_model = Model(input=stage_input, output=stage_output)
        #make_layers_trainable(self._stages[1], False)
        stage_model.compile(loss=loss, optimizer=optimizer, metrics=['mae'])
        self._stages.append(stage_model)

        # Stage 4
        stage_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        x = encoder_stages[0:4](stage_input)
        stage_output = decoder_stages[2:6](x)
        stage_model = Model(input=stage_input, output=stage_output)
        #make_layers_trainable(self._stages[1], False)
        stage_model.compile(loss=loss, optimizer=optimizer, metrics=['mae'])
        self._stages.append(stage_model)

        # Stage 5
        stage_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        x = encoder_stages[0:5](stage_input)
        stage_output = decoder_stages[1:6](x)
        stage_model = Model(input=stage_input, output=stage_output)
        #make_layers_trainable(self._stages[1], False)
        stage_model.compile(loss=loss, optimizer=optimizer, metrics=['mae'])
        self._stages.append(stage_model)

        # Stage 6
        stage_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        x = encoder_stages[0:6](stage_input)
        stage_output = decoder_stages[0:6](x)
        stage_model = Model(input=stage_input, output=stage_output)
        #make_layers_trainable(self._stages[1], False)
        stage_model.compile(loss=loss, optimizer=optimizer, metrics=['mae'])
        self._stages.append(stage_model)


        # Autoencoder
        ae_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        h = encoder_stages[0:6](ae_input)
        
        z_mean = z_mean_layer(h)
        z_log_sigma = z_log_sigma_layer(h)
        z = z_layer([z_mean, z_log_sigma])
        #z = h

        ae_output = decoder_stages[0:6](z)
        self._vae = Model(input=ae_input, output=ae_output)
 
        self.vae_loss = VAELoss(z_mean=z_mean, z_log_var=z_log_sigma, loss=MAE(), kl_beta = 0.0)        
        self._vae.compile(loss=self.vae_loss, optimizer=Adam(), metrics=['mae'])
        self._vae.name = "Autoencoder"

        # Encoder
        enc_input = [Input(shape=vel_shape), Input(shape=pres_shape), Input(shape=ls_shape)]
        h = encoder_stages[0:6](enc_input)

        z_mean = z_mean_layer(h)
        z_log_sigma = z_log_sigma_layer(h)
        z = z_layer([z_mean, z_log_sigma])
        self._encoder = Model(enc_input, z)
        self._encoder.name = "Encoder" 

        # # Super Resolution
        # self._model = self._stages[0]

        print(self.get_summary())

    #---------------------------------------------------------------------------------
    def get_summary(self):
        return "{}\n{}".format("Autoencoder", self._vae.summary())

    #---------------------------------------------------------------------------------
    def pretrain(self, xs, ys, epochs = 10, batch_size=128):
        """ 
        Train the autoencoder in stages of increasing size 
        :param epochs: Number of epochs of training
        :param x: The dataset fed as input to the autoencoder
        :param y: The real dataset, by which the autoencoder will be measured
        """
        try:
            print("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>")
            print("Autoencoder pretraining")
            
            # Train the autoencoder stages
            for index, stage in enumerate(self._stages):
                print("\n--------------------------------------------------------------------------------")
                print("Stage {}\n".format(index + 1))
                
                hist = stage.fit(
                    x=xs,
                    y=ys,
                    batch_size=batch_size, 
                    nb_epoch=epochs)
                    #callbacks=[ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=3, min_lr=1e-5)])
                
                # Set the prediction model to the last trained model
                self._model = stage

        except KeyboardInterrupt:
            print("\n Interrupted by user")

    #---------------------------------------------------------------------------------
    def train(self, xs, ys, epochs = 10, batch_size=128):
        try:
            print("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>")
            print("Autoencoder training")
            
            hist = self._vae.fit(x=xs, y=ys, batch_size=batch_size, nb_epoch=epochs, callbacks=[self.vae_loss.vae_callback])
            self._model = self._vae

        except KeyboardInterrupt:
            print("\n Interrupted by user")

    #---------------------------------------------------------------------------------
    def load_model(self, path):
        print("Loading model from {}".format(path))
        self._vae.load_weights(path)
        self._model = self._vae

    #---------------------------------------------------------------------------------
    def save_model(self, path):
        print("Saving model to {}".format(path))
        self._model.save_weights(path)

    #---------------------------------------------------------------------------------
    def encode(self, x):
        z = self._encoder.predict(x)
        return z

    #---------------------------------------------------------------------------------
    def decode(self, z):
        y = self._decoder.predict(x=z)
        return y

    #---------------------------------------------------------------------------------
    def predict(self, x):
        """ predict from three dimensional numpy array"""
        return self._model.predict(x)

    #---------------------------------------------------------------------------------
    @property
    def model(self):
        return self._model

    #---------------------------------------------------------------------------------
    @property
    def encoder_trainable(self):
        return self._trainable_encoder

    #---------------------------------------------------------------------------------
    @encoder_trainable.setter
    def encoder_trainable(self, value):
        self._trainable = value
        make_layers_trainable(self._encoder, value)

    #---------------------------------------------------------------------------------
    @property
    def code_layer_size(self):
        return self._z_size
