import keras
from keras.layers import *
from keras.optimizers import *
from keras.layers.pooling import AveragePooling2D
from keras.models import Model
import keras.backend as K
# from keras.objectives import *

from shared.helpers import *
from shared.losses import *

#=====================================================================================
class SuperResolution(object):
    #---------------------------------------------------------------------------------
    def __init__(self, input_shape, factor=(2,2)):

        x = Input(input_shape)

        h = UpSampling2D(size=factor)(x)
        
        # Deconv #
        h = Convolution2D(64, 9, 9, border_mode='same', init=init)(h)
        h = BatchNormalization()(h)
        h = hidden_activation()(h)
        h = Dropout(0.2)(h)
        
        # Deconv #
        h = Convolution2D(32, 1, 1, border_mode='same', init=init)(h)
        h = BatchNormalization()(h)
        h = hidden_activation()(h)

        # Deconv #
        h = Convolution2D(1, 5, 5, border_mode='same', init=init)(h)
        y = inout_activation()(h)

        self._model = Model(x, y)
        optimizer = Adam()
        loss = MSE(50.0)
        self._model.compile(optimizer=optimizer, loss=loss, metrics='mse')
        self._model.name = "SuperResolution"

    #---------------------------------------------------------------------------------
    def train(self, xs, ys, epochs=10, batch_size=128):
        try:
            print("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>")
            print("SuperResolution training")

            hist = self._model.fit(x=xs, y=ys, batch_size=batch_size, nb_epoch=epochs)

        except KeyboardInterrupt:
            print("\n Interrupted by user")

    #---------------------------------------------------------------------------------
    def load_model(self, path):
        print("Loading model from {}".format(path))
        self._model.load_weights(path)

    #---------------------------------------------------------------------------------
    def save_model(self, path):
        print("Saving model to {}".format(path))
        self._model.save_weights(path)

    #---------------------------------------------------------------------------------
    def predict(self, x):
        """ predict from three dimensional numpy array"""
        x = x[np.newaxis, ...]
        #x = np.multiply(x, 1.0 / 100.0)
        output = self._model.predict_on_batch(x)
        #output = np.multiply(output, 100.0)
        return output[0,:,:,:]

    #---------------------------------------------------------------------------------
    @property
    def model(self):
        return self._model

    #---------------------------------------------------------------------------------
    @property
    def trainable(self):
        return self._trainable

    #---------------------------------------------------------------------------------
    @trainable.setter
    def trainable(self, value):
        self._trainable = value
        make_layers_trainable(self._model, value)