from upscale import VelocityDreamer
import logging
import shutil
import argparse
import datetime
import os
import time
import logging
import pathlib

import numpy as np
from keras import backend as K
import tensorflow as tf
from functools import partial
from pathlib import Path
from shared.plot import Plotter
from shared.losses import *


def print_metrics(x, y):
    print("MSE: {}".format(tf.reduce_sum(MSE()(x,y)).eval(session=K.get_session())))
    print("MAE: {}".format(tf.reduce_sum(MAE()(x,y)).eval(session=K.get_session())))
    div = Divergence()(y[np.newaxis,...], x[np.newaxis,...])
    print("Divergence True: {}".format(tf.reduce_sum(div).eval(session=K.get_session())))
    div = Divergence()(x[np.newaxis,...], y[np.newaxis,...])
    print("Divergence Pred: {}".format(tf.reduce_sum(div).eval(session=K.get_session())))  

#--------------------------------------------------------------------------------------------------------------------
# Parse arguments
parser = argparse.ArgumentParser()
# General
general = parser.add_argument_group("General")
general.add_argument("--ae_type", default="velocity", choices=['velocity', 'pressure', 'total_pressure'], nargs='+', help="Fields to train the autoencoder on")

# Dataset
dataset = parser.add_argument_group("Dataset")
dataset.add_argument("-d", "--dataset_path", default="mo/vus_dataset", help="Directory of the training data")
dataset.add_argument("--reload_data", dest='reload_data', action='store_true', default=False, help="Force reload data from unifiles instead of serialized scenes")

# Checkpoints
checkpoints = parser.add_argument_group("Checkpoints")
checkpoints.add_argument("-c","--models_path", default="mo/model/submission/", help="Path to the submission models")
checkpoints.add_argument("-o","--output_path", default="mo/output/tests/", help="Path where to put the test results")

args = parser.parse_args()

#--------------------------------------------------------------------------------------------------------------------
# Create output directories
output_path = args.output_path + datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + "/"
os.makedirs(output_path, exist_ok=True)

#--------------------------------------------------------------------------------------------------------------------
# Setup the logger
logging.basicConfig(format='----------------------------------------------------------------------------\n%(message)s', filename=output_path + "training.log",level=logging.INFO)

#--------------------------------------------------------------------------------------------------------------------
# Create the model manager
try:
    # load data
    vel_dreamer = VelocityDreamer()
    vel_dreamer.load_data(path=args.dataset_path, force_reload=args.reload_data)

    plotter = Plotter()
    step = 1593
    
    if "velocity" in args.ae_type:
        vel_dreamer.build_autoencoder("velocity")
        vel_dreamer.load_model(args.models_path + "velocity_ae.h5")
        vel_xs = vel_dreamer.dataset.velocity[90000:100000:step]
        ls = vel_dreamer.dataset.levelset[90000:100000:step]
        vel_ys = vel_dreamer.predict([vel_xs, ls])
        for x, y in zip(vel_xs, vel_ys):
            # x = np.multiply(x, 25.0)
            # y = np.multiply(y, 25.0)
            plotter.plot_vector_field(x,y)
            print_metrics(x, y)

    if "pressure" in args.ae_type:
        vel_dreamer.build_autoencoder("pressure")
        vel_dreamer.load_model(args.models_path + "pressure_ae.h5")
        xs_static = vel_dreamer.dataset.static_pressure[90000:100000:step]
        xs_dynamic = vel_dreamer.dataset.dynamic_pressure[90000:100000:step]
        pres_ys = vel_dreamer.autoencoder.predict_combined([xs_static, xs_dynamic], norm_factor_static = 30.0, norm_factor_dynamic=12.0)
        ys_static, ys_dynamic = vel_dreamer.autoencoder.predict([xs_static, xs_dynamic])
        pres_xs = np.add(np.multiply(xs_static, 30.0), np.multiply(xs_dynamic, 12.0))
        # for x, y in zip(pres_xs, pres_ys):
        #     plotter.plot_heatmap(x,y, title="Separate Pressure", vmin=0.0, vmax=30.0)
        # for x, y in zip(pres_xs, pres_ys):
        #     se = (x - y) ** 2
        #     plotter.plot_single(se, title="Separate Pressure", vmin=0.0, vmax=1.0)
    
    if "total_pressure" in args.ae_type:
        vel_dreamer.build_autoencoder("total_pressure")   
        vel_dreamer.load_model(args.models_path + "total_pressure_ae.h5")
        total_pres_xs = vel_dreamer.dataset.pressure[90000:100000:step]
        total_pres_ys = vel_dreamer.predict(total_pres_xs)
        total_pres_ys = np.multiply(total_pres_ys, 30.0)
        total_pres_xs = np.multiply(total_pres_xs, 30.0)
        # for x, y in zip(total_pres_xs, total_pres_ys):
        #     plotter.plot_heatmap(x,y, title="Total Pressure", vmin=0.0, vmax=30.0)
        # for x, y in zip(total_pres_xs, total_pres_ys):
        #     se = np.abs(x - y)
        #     plotter.plot_single(se, title="Total Pressure", vmin=0.0, vmax=1.0)
            

    if "total_pressure" in args.ae_type and "pressure" in args.ae_type:
        for x, y_t, y_s in zip(total_pres_xs, total_pres_ys, pres_ys):
            plotter.plot_scalar_fields({"Reference":x[:,:,0], "Total Pressure Prediction":y_t[:,:,0], "Separate Pressure Prediction":y_s[:,:,0]}, color_map='viridis', vmin=0.0, vmax=30.0)
        for x, y_t, y_s in zip(total_pres_xs, total_pres_ys, pres_ys):
            se_total = np.abs(x - y_t)
            se_static = np.abs(x - y_s)
            plotter.plot_scalar_fields({"Total Pressure Prediction":se_total[:,:,0], "Separate Pressure Prediction":se_static[:,:,0]}, vmin=0.0, vmax=1.0)
            

    plotter.save_figures(output_path)

    plotter.show(block=True)

except KeyboardInterrupt:
    print("User interrupt")