from upscale import VelocityDreamer
import argparse
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button
from mpl_toolkits.axes_grid1 import make_axes_locatable

#--------------------------------------------------------------------------------------------------------------------
# Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument("--model_path", help="the path to the VAE model")
args = parser.parse_args()

#--------------------------------------------------------------------------------------------------------------------
# Decode latent variables
vae = VelocityDreamer()
vae.build_autoencoder_model()
vae.load_model(args.model_path)
z_size = vae.autoencoder.code_layer_size
z = np.random.uniform(low=0.0, high=1.0, size=z_size)

def decode(z):
    z = z[np.newaxis, ...]
    return vae.decode(z)[0,:,:,0]

gen_img = decode(z)

#--------------------------------------------------------------------------------------------------------------------
# Create window
axis_color = 'lightgoldenrodyellow'
fig = plt.figure()

# Draw
ax = fig.add_subplot(111)
im = ax.imshow(gen_img, vmin=0, vmax=1, cmap='viridis', interpolation='nearest')
ax.set_title("Generated Field")
ax.set_xlim(0, 30)
ax.set_ylim(0, 30)
ax.get_xaxis().set_visible(False)
ax.get_yaxis().set_visible(False)
divider = make_axes_locatable(ax)
cax = divider.append_axes('right', size='5%', pad = 0.05)
fig.colorbar(im, cax=cax, orientation='vertical')
plt.show()