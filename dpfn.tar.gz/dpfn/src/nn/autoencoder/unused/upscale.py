import numpy as np
import os
import random

# import sys,inspect
# currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
# parentdir = os.path.dirname(currentdir)
# sys.path.insert(0,parentdir)

from ...dataset import datasets
from .unused.pressure_autoencoder import PressureAutoencoder
# from .velocity_autoencoder import VelocityAutoencoder
# from .multi_autoencoder import MultiAutoencoder
# from .levelset_autoencoder import LevelsetAutoencoder
from .total_pressure_autoencoder import TotalPressureAutoencoder

from ..gan.discriminator import Discriminator
from ..gan.generative_adviserial_network import GenerativeAdviserialNetwork

class VelocityDreamer(object):
    """ The class containing the different models used in the upscale task """

    #=================================================
    # Preparation
    #=================================================

    #--------------------------------------------
    # fetch the training and validation data
    def load_data(self, path, normalization_percentile = 99.5, force_reload = False):
        """
        Load and normalize the data using our custom dataset class. Data can afterwards be directly accessed via the dataset member.
        :param path: Path to the datasets
        :param normalization_percentile: The percentage [0,100] of data values that should fall below the normalization factor value
        :param force_reload: Reload data from uni files even if it already was serialized
        """
        serialized_data_path = path + "/serialized/"
        if os.path.exists(serialized_data_path) and not force_reload:
            self.dataset = datasets.DataSet()
            self.dataset.add_data_block("velocity", datasets.DataBlock.from_file(serialized_data_path + "velocity.npz"))
            self.dataset.add_data_block("pressure", datasets.DataBlock.from_file(serialized_data_path + "pressures.npz"))
            self.dataset.add_data_block("dynamic_pressure", datasets.DataBlock.from_file(serialized_data_path + "pressure_dynamic.npz"))
            self.dataset.add_data_block("static_pressure", datasets.DataBlock.from_file(serialized_data_path + "pressure_static.npz"))            
            self.dataset.add_data_block("levelset", datasets.DataBlock.from_file(serialized_data_path + "levelset.npz"))
        else:
            os.makedirs(serialized_data_path, exist_ok=True)
            self.dataset = datasets.DataSet()

            # velocities
            self.dataset.add_data_block("velocity", datasets.DataBlock.from_uni(path = path + "/velocities/"))
            self.dataset.velocity.serialize(serialized_data_path + "velocity.npz")
            
            # pressure
            self.dataset.add_data_block("pressure", datasets.DataBlock.from_uni(path = path + "/pressure/"))
            self.dataset.pressure.serialize(serialized_data_path + "pressures.npz")

            # dynamic pressure
            self.dataset.add_data_block("dynamic_pressure", datasets.DataBlock.from_uni(path = path + "/pressure_dynamic/"))
            self.dataset.dynamic_pressure.serialize(serialized_data_path + "pressure_dynamic.npz")
            
            # static pressure
            self.dataset.add_data_block("static_pressure", datasets.DataBlock.from_uni(path = path + "/pressure_static/"))
            self.dataset.static_pressure.serialize(serialized_data_path + "pressure_static.npz")

            # levelset
            self.dataset.add_data_block("levelset", datasets.DataBlock.from_uni(path = path + "/levelset/"))
            self.dataset.levelset.serialize(serialized_data_path + "levelset.npz")

        self.dataset.velocity.normalize(factor=3.0, percentile=99.99)
        self.dataset.dynamic_pressure.normalize(factor=12.0, percentile=99.0)
        self.dataset.static_pressure.normalize(factor=30.0, percentile=99.0)        
        self.dataset.pressure.normalize(factor=30.0, percentile=99.0)        
        self.dataset.levelset.normalize(max=True)

    #============================================
    # Definition
    #============================================
    def build_autoencoder(self, type_string):
        types = {   
            # "pressure": self.build_pressure_ae_model,
            # "velocity": self.build_velocity_ae_model,
            "total_pressure": self.build_total_pressure_ae_model,
            # "multi": self.build_multi_ae_model,
            # "levelset": self.build_levelset_ae_model,
        }
        builder_function = types[type_string]
        assert builder_function is not None, "Autoencoder type {} is not known".format(type_string) 
        builder_function()

    #--------------------------------------------
    # define the network model
    def build_multi_ae_model(self):
        """ 
        The Autoencoder is the main model. It is used to generate high resolution 
        fields from low resolution input and to extract latent variables from the input data. 
        """
        self._autoencoder = MultiAutoencoder(vel_shape=(64,64,3), pres_shape=(64,64,1), ls_shape=(64,64,1))

    #--------------------------------------------
    # define the network model
    def build_pressure_ae_model(self):
        """ 
        The Autoencoder is the main model. It is used to generate high resolution 
        fields from low resolution input and to extract latent variables from the input data. 
        """
        self._autoencoder = PressureAutoencoder(input_shape=(64,64,1))

    #--------------------------------------------
    # define the network model
    def build_pressure_static_dynamic_ae_model(self):
        """ 
        The Autoencoder is the main model. It is used to generate high resolution 
        fields from low resolution input and to extract latent variables from the input data. 
        """
        self._autoencoder = PressureAutoencoderStaticDynamic(input_shape=(64,64,1))

    #--------------------------------------------
    # define the network model
    def build_total_pressure_ae_model(self):
        """ 
        The Autoencoder is the main model. It is used to generate high resolution 
        fields from low resolution input and to extract latent variables from the input data. 
        """
        self._autoencoder = TotalPressureAutoencoder(input_shape=(64,64,1))

    #--------------------------------------------
    def build_levelset_ae_model(self):
        """ The autoencoder directly learning levelset reconstruction """
        self._autoencoder = LevelsetAutoencoder(input_shape=(64,64,1))

    #--------------------------------------------
    def build_velocity_ae_model(self):
        """ 
        The Autoencoder is the main model. It is used to generate high resolution 
        fields from low resolution input and to extract latent variables from the input data. 
        """
        self._autoencoder = VelocityAutoencoder(velocity_shape=(64,64,3), levelset_shape=(64,64,1))

    #-------------------------------------------- 
    def build_discriminator_model(self):
        """ 
        The Discriminator is trained to classify real and generated fake data. 
        It is used to improve generator performance 
        """
        self._discriminator = Discriminator(input_shape=self._autoencoder.model.output_shape)

    #--------------------------------------------
    def build_gan_model(self):
        """ 
        The GAN is used to improve generator preditions with a discriminator. 
        The discriminator must be pretrained to workaround some weird bug 
        """
        self._gan = GenerativeAdviserialNetwork(generator=self._autoencoder, discriminator=self._discriminator)

    #--------------------------------------------
    def load_model(self, model_directory):
        """ load models from a file if it fits """
        self._autoencoder.load_model(model_directory)

    #--------------------------------------------
    def save_model(self, model_directory):
        """ save the model to a .h5 file """
        self._autoencoder.save_model(model_directory)

    #--------------------------------------------
    @property
    def code_layer_size(self):
        return self._autoencoder.code_layer_size

    #============================================
    # Training
    #============================================

    #--------------------------------------------
    def pretrain_ae(self, epochs = 5, batch_size=128, range=25000):
        """ Train the autoencoder in stages of increasing size """
        if isinstance(self._autoencoder, VelocityAutoencoder):
            self._autoencoder.pretrain(xs=[self.dataset.velocity.data[:range], self.dataset.levelset.data[:range]], ys=self.dataset.velocity.data[:range], epochs=epochs)

        elif isinstance(self._autoencoder, PressureAutoencoder):
            self._autoencoder.pretrain(
                xs=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]], 
                ys=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]],
                epochs=epochs)

        # elif isinstance(self._autoencoder, PressureAutoencoderStaticDynamic):
        #     self._autoencoder.pretrain(
        #         xs=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]], 
        #         ys=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]], 
        #         epochs=epochs)

        elif isinstance(self._autoencoder, MultiAutoencoder):
            self._autoencoder.pretrain(xs=[self.dataset.velocity.data[:range], self.dataset.pressure.data[:range], self.dataset.levelset.data[:range]], ys=self.dataset.pressure.data[:range], epochs=epochs)

        elif isinstance(self._autoencoder, LevelsetAutoencoder):
            self._autoencoder.pretrain(xs=self.dataset.levelset.data[:range], ys=self.dataset.levelset.data[:range], epochs=epochs)
            
        elif isinstance(self._autoencoder, TotalPressureAutoencoder):
            self._autoencoder.pretrain(xs=self.dataset.pressure[:range], ys=self.dataset.pressure[:range], epochs=epochs, batch_size=batch_size)
    
    #--------------------------------------------
    def train_ae(self, epochs = 5, batch_size=128, range=25000):
        """ Train the generator with the standard l2 loss"""
        if isinstance(self._autoencoder, VelocityAutoencoder):
            self._autoencoder.train(xs=[self.dataset.velocity.data[:range], self.dataset.levelset.data[:range]], ys=self.dataset.velocity.data[:range], epochs=epochs)
        
        elif isinstance(self._autoencoder, PressureAutoencoder):
            self._autoencoder.train(
                xs=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]], 
                ys=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]],
                epochs=epochs)
        
        elif isinstance(self._autoencoder, PressureAutoencoderStaticDynamic):
            self._autoencoder.train(
                xs=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]], 
                ys=[self.dataset.static_pressure.data[:range],self.dataset.dynamic_pressure.data[:range]], 
                epochs=epochs)

        elif isinstance(self._autoencoder, MultiAutoencoder):
            self._autoencoder.train(xs=[self.dataset.velocity.data[:range], self.dataset.pressure.data[:range], self.dataset.levelset.data[:range]], ys=self.dataset.pressure.data[:range], epochs=epochs)

        elif isinstance(self._autoencoder, LevelsetAutoencoder):
            self._autoencoder.train(xs=self.dataset.levelset.data[:range], ys=self.dataset.levelset.data[:range], epochs=epochs)

        elif isinstance(self._autoencoder, TotalPressureAutoencoder):       
            self._autoencoder.train(xs=self.dataset.pressure[:range], ys=self.dataset.pressure[:range], epochs=epochs, batch_size=batch_size)

    #--------------------------------------------
    def pretrain_discriminator(self, epochs = 5):
        """Pretrain the discriminator with a l2 loss trained generator"""
        self._discriminator.train(xs=self.dataset.velocity.data, ys=self.dataset.velocity.data, generator=self._autoencoder, epochs=epochs)

    #--------------------------------------------
    def train_gan(self, epochs = 5):
        """ train the whole model. ideally generator and discriminator should be pretrained to achieve faster convergence """    
        self._gan.train(x=self.dataset.velocity.data, y=self.dataset.velocity.data, epochs=epochs)

    #============================================
    # Evaluation
    #============================================

    #--------------------------------------------
    def predict(self, x):
        """
        # Predict
        Predict a higher resolution velocity field based on the trained model.
        ## Arguments
        x: a (16, 16, 3) tensor containing the low resolution velocity field
        ## Returns
        A (64, 64, 3) with the predicted high resolution velocity field
        """
        return self._autoencoder.predict(x)

    # #--------------------------------------------
    # def predict_uni(self, path, lowres_filename):
    #     head, image = uniio.readuni(path + lowres_filename)
    #     # Remove the third dimension, so to gain a proper image
    #     image = np.squeeze(image, axis=(2,))
    #     image = image.astype(np.float32)
    #     #image = np.multiply(image, 1.0 / 100.0)
    #     prediction = self.predict(image)
    #     #prediction = np.multiply(prediction, 200.0)
    #     print(head)
    #     head['dimX'] = 64
    #     head['dimY'] = 64
    #     uniio.writeuni(path + "highres.uni", head, prediction)
    #     return path + "highres.uni"

    #--------------------------------------------
    def encode(self, x):
        """ Use the trained encoder to transform input into latent space """
        return self._autoencoder.encode(x)

    #--------------------------------------------
    def decode(self, z):
        """ Use the trained decoder to transform latent space variables to a prediction """
        return self._autoencoder.decode(z)

    #--------------------------------------------
    @property
    def autoencoder(self):
        return self._autoencoder
    
    #--------------------------------------------
    @property
    def discriminator(self):
        return self._discriminator

    #--------------------------------------------
    @property
    def generative_adviserial_network(self):
        return self._gan