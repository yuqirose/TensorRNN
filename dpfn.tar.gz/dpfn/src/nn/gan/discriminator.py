import keras
from keras.layers import *
from keras.optimizers import *
from keras.models import Model
from ..helpers import *
from ..losses import *
import logging

#=====================================================================================
class Discriminator(object):
    REAL = 0.0
    FAKE = 1.0

    #---------------------------------------------------------------------------------
    def __init__(self, input_shape):
        self._trainable = True
        self.input_shape = input_shape
        init = weight_init

        # DISCRIMINATOR #########################################################################################
        model_input = Input(shape=input_shape)
        
        # Conv #
        x = Conv2D(64, 5, 5, subsample=(2, 2), border_mode='same', init=init)(model_input)
        #x = BatchNormalization(mode=1)(x)
        x = inout_activation()(x)
        #x = Dropout(0.2)(x)

        # Conv #
        x = Conv2D(32, 5, 5, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)
        
        # Conv #
        x = Conv2D(16, 5, 5, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        # Conv #
        x = Conv2D(8, 5, 5, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        # Conv #
        x = Conv2D(4, 5, 5, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)
        
        # Conv #
        x = Conv2D(2, 5, 5, subsample=(2, 2), border_mode='same', init=init)(x)
        x = BatchNormalization(mode=1)(x)
        x = hidden_activation()(x)
        x = Dropout(0.2)(x)

        x = Flatten()(x)
        x = Dense(1)(x)
        model_output = Activation('sigmoid')(x)

        # Compile the discriminator model
        self._model = Model(input=model_input, output=model_output)
        self._model.compile(loss='binary_crossentropy', optimizer=Adam(lr=0.001, beta_1=0.5))

        print(self._model.summary())
        # Output model architecture
        #self._model.name = "Discriminator"
        #logging.info("Discriminator")
        #logging.info(self._model.summary())

    #---------------------------------------------------------------------------------
    def train(self, xs, ys, generator, epochs=10, batch_size = 128):
        """ 
        Train the discriminator with the generator's fake data and real data 
        :param epochs: Number of epochs to train
        :param x: The dataset fed into the generator to predict fake data
        :param y: The real data
        :param generator: The generator the discriminator is trained against
        """
        # predict fake data with generator and mix them with real ones
        print("Generating discriminator data...", end="\r")
        num_real = len(xs)
        num_fake = num_real
        images = ys
        labels = np.array([self.REAL] * num_real)
        images = np.append(images, generator.model.predict(x=xs, batch_size=batch_size), axis=0)
        labels = np.append(labels, np.array([self.FAKE] * num_fake), axis=0)
        print("Generating discriminator data [Done]")
 
        try:
            # Train the discriminator on the mixed dataset
            hist = self._model.fit(x=images, y=labels, batch_size=batch_size, nb_epoch=epochs)
        except KeyboardInterrupt:
            print("\n Interrupted by user")

    #---------------------------------------------------------------------------------
    def load_model(self, path):
        print("Loading pretrained discriminator from {}".format(path))
        self._model.load_weights(path)

    #---------------------------------------------------------------------------------
    def save_model(self, path):
        print("Saving model to {}".format(path))
        self._model.save_weights(path)

    #---------------------------------------------------------------------------------
    @property
    def model(self):
        return self._model

    #---------------------------------------------------------------------------------
    @property
    def trainable(self):
        return self._trainable

    #---------------------------------------------------------------------------------
    @trainable.setter
    def trainable(self, value):
        self._trainable = value
        make_layers_trainable(self._model, value)