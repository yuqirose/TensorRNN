import keras
from keras.optimizers import *
from keras.models import Model
from keras.layers import Input

import numpy as np
import logging

from ..helpers import *
from ..losses import *
from .discriminator import Discriminator as D

#=====================================================================================
class GenerativeAdviserialNetwork(object):
    #---------------------------------------------------------------------------------
    def __init__(self, generator, discriminator):
        assert generator is not None and discriminator is not None, ("Generator and Discriminator must be built before building the GAN")
        self._generator = generator
        self._discriminator = discriminator

        # Build the GAN by concatenating generator and discriminator
        model_input = Input(shape=generator.input_shape)
        x = self._generator.model(model_input)
        model_output = self._discriminator.model(x)
        self._model = Model(input = model_input, output=model_output)

        # Lock the discriminator's parameters in training -> only generator should learn from GAN loss
        self._discriminator.trainable = False

        # Compile the GAN model
        self._model.compile(loss = 'binary_crossentropy', optimizer = Adam(lr=0.001, beta_1=0.5))

        # Give the model a reasonable name to improve summary readability
        self._model.name = "GAN"

    #---------------------------------------------------------------------------------
    def get_summary():
        return "GAN\n{}".format(self._model.summary())  
    
    #---------------------------------------------------------------------------------
    def train(self, x, y, epochs=10, batch_size = 128):
        """ Train the GAN """
        try:
            print("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>")
            print("GAN training")
            
            for e in range(epochs):
                print("\n--------------------------------------------------------------------------------")
                print("Epoch {} of {}".format(e + 1, epochs))

                # generate fake images
                print("\nPredicting fake images")
                num_real = len(x)
                mixed_images = np.concatenate((self._generator.model.predict(x=x, batch_size=batch_size), y), axis=0)
                mixed_labels = np.concatenate((np.array([D.FAKE] * num_real), np.array([D.REAL] * num_real)), axis=0)

                # fit discriminator to distinguish fake images from real images
                print("\nTraining the discriminator")
                self._discriminator.model.fit(x=mixed_images, y=mixed_labels, batch_size=batch_size, nb_epoch = 1, shuffle=True)

                # fit the generator to fool the discriminator into thinking fake images are real
                print("\nTraining generator by discriminator")
                self._model.fit(x=x, y=np.array([D.REAL] * num_real), batch_size = batch_size, nb_epoch = 1)
        
        except KeyboardInterrupt:
            print("\n Interrupted by user")

    #---------------------------------------------------------------------------------
    def save_model(self, path):
        """ Save both generator and discriminator in the combined model """
        print("Saving model to {}".format(path))
        self._model.save_weights(path)

    #---------------------------------------------------------------------------------
    def load_model(self, path):
        """ Load both generator and discriminator """
        self._model.load_weights(path)
    
    #---------------------------------------------------------------------------------
    @property
    def model(self):
        return self._model