import numpy as np
from pathlib import Path
#from ..autoencoder.upscale import VelocityDreamer
from ..lstm.sequence_prediction import SequencePredictor
from ..lstm.sequence_prediction import Loss
from ..lstm.sequence_prediction import LossType

from math import floor
from enum import Enum

import os
import tensorflow as tf
import keras.backend.tensorflow_backend as KTF

#--------------------------------------------
def start_session(gpu_fraction=0.8):
    '''Setup seeds to be as deterministic as possible. cudNN is still not deterministic'''
    np.random.seed(1337)
    tf.set_random_seed(1337)

    '''Assume that you have 6GB of GPU memory and want to allocate gpu_fraction percent of it'''
    num_threads = os.environ.get('OMP_NUM_THREADS')
    gpu_options = tf.GPUOptions(allow_growth=True, per_process_gpu_memory_fraction=gpu_fraction)

    print("Found {} threads. Using {} of GPU memory per process.".format(num_threads, gpu_fraction))
    if num_threads:
        session = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, intra_op_parallelism_threads=num_threads))
    else:
        session = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

    KTF.set_session(session)

    SequencePredictorSettings.setup_sequence_predictor()

#--------------------------------------------
class AutoencoderType(Enum):
    pressure = 1
    velocity = 2
    levelset = 3
    total_pressure = 4

#--------------------------------------------
class SequencePredictorSettings(object):
    autoencoder_type = AutoencoderType.pressure

    @staticmethod
    def setup_sequence_predictor():
        if SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
            SequencePredictorSettings.time_steps = 16
            SequencePredictorSettings.out_time_steps = 3
            SequencePredictorSettings.hidden_lstm_neurons = 500
            SequencePredictorSettings.attention_neurons = 400
            SequencePredictorSettings.use_decoder = False
            SequencePredictorSettings.use_attention = True
            SequencePredictorSettings.use_bidirectional = True
            SequencePredictorSettings.lstm_activation = 'tanh'
            SequencePredictorSettings.lstm_loss = Loss(loss_type=LossType.mse, loss_ratio=1.0, loss_weight=1.0)
            SequencePredictorSettings.decoder_loss = Loss(loss_type=LossType.mse, loss_ratio=1.0, loss_weight=1.0)
        else:
            SequencePredictorSettings.time_steps = 16
            SequencePredictorSettings.out_time_steps = 3
            SequencePredictorSettings.hidden_lstm_neurons = 500
            SequencePredictorSettings.attention_neurons = 400
            SequencePredictorSettings.use_decoder = False
            SequencePredictorSettings.use_attention = False
            SequencePredictorSettings.use_bidirectional = False
            SequencePredictorSettings.lstm_activation = 'tanh'
            SequencePredictorSettings.lstm_loss = Loss(loss_type=LossType.mae, loss_ratio=1.0, loss_weight=1.0)
            SequencePredictorSettings.decoder_loss = Loss(loss_type=LossType.mae, loss_ratio=1.0, loss_weight=1.0)

        if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
            SequencePredictorSettings.model_timestamp = "2017-04-26-20-03-54"  # 100 epochs trained for "2017-04-21-01-13-08-no-vae" CAE
        elif SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
            SequencePredictorSettings.model_timestamp = "2017-04-24-21-51-31"
        elif SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
            SequencePredictorSettings.model_timestamp = "2017-04-24-15-38-09" # bwd, att, bidirSum, 500 neurons, 50 epochs
        else:
            SequencePredictorSettings.model_timestamp = None

#--------------------------------------------
def get_auto_encoder_checkpoint_date():
    date = ""
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
        date = "2017-04-21-01-13-08-no-vae"
    elif SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
        date = "2017-04-21-13-03-05"
    elif SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
        date = "2017-04-18-01-45-56"
    elif SequencePredictorSettings.autoencoder_type == AutoencoderType.levelset:
        date = "2017-04-01-11-42-52"
    else:
        raise NotImplementedError
    return date

#--------------------------------------------
def get_code_layer_normalize_factor():
    code_layer_normalize_factor = 1.0
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
        code_layer_normalize_factor = 30.0
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
        code_layer_normalize_factor = 30.0
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
        code_layer_normalize_factor = 1.5
    return code_layer_normalize_factor

#--------------------------------------------
def get_cae_normalize_factor():
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
        return (30.0, 12.0)
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
        return 30.0
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
        return 3.0
    return 1.0

# #--------------------------------------------
# def get_auto_encoder(main_directory):
#     print("\nVELOCITY DREAMER\n")
#     vel_dreamer = VelocityDreamer()

#     checkpoint_date = get_auto_encoder_checkpoint_date()

#     checkpoint_path = main_directory + "/models/"

#     if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
#         checkpoint_path += "pressure/" + checkpoint_date + "/autoencoder.h5"
#         vel_dreamer.build_pressure_ae_model()
#     elif SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
#         checkpoint_path += "pressure_total/" + checkpoint_date + "/autoencoder.h5"
#         vel_dreamer.build_total_pressure_ae_model()
#     elif SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
#         checkpoint_path += "velocity/" + checkpoint_date + "/autoencoder.h5"
#         vel_dreamer.build_velocity_ae_model()
#     elif SequencePredictorSettings.autoencoder_type == AutoencoderType.levelset:
#         checkpoint_path += "levelset/" + checkpoint_date + "/autoencoder.h5"
#         vel_dreamer.build_levelset_ae_model()
#     else:
#         raise NotImplementedError

#     if checkpoint_path:
#         vel_dreamer.load_model(model_directory=checkpoint_path)
#     else:
#         print("You, personally, failed. We wont train this network in this script!")
#     return vel_dreamer

#--------------------------------------------
def get_sequence_predictor(autoencoder, lstm_model_path, epochs, batch_size):
    autoencoder.autoencoder.decoder_trainable = False
    decoder_model = autoencoder.autoencoder._decoder

    print("\nSEQUENCE PREDICTOR\n")
    seq_pred = SequencePredictor(decoder_model=decoder_model)

    seq_pred.model_path = lstm_model_path
    seq_pred.data_dimension = autoencoder.code_layer_size
    seq_pred.batch_size = batch_size
    seq_pred.epochs = epochs

    seq_pred.stateful = False
    seq_pred.lstm_activation = SequencePredictorSettings.lstm_activation
    seq_pred.use_bidirectional = SequencePredictorSettings.use_bidirectional
    seq_pred.use_decoder = SequencePredictorSettings.use_decoder
    seq_pred.use_attention = SequencePredictorSettings.use_attention
    seq_pred.time_steps = SequencePredictorSettings.time_steps
    seq_pred.out_time_steps = SequencePredictorSettings.out_time_steps
    seq_pred.hidden_lstm_neurons = SequencePredictorSettings.hidden_lstm_neurons
    seq_pred.attention_neurons = SequencePredictorSettings.attention_neurons
    seq_pred.lstm_loss = SequencePredictorSettings.lstm_loss
    seq_pred.decoder_loss = SequencePredictorSettings.decoder_loss

    loaded = False
    if seq_pred.model_path and SequencePredictorSettings.model_timestamp:
        seq_pred.model_path = seq_pred.model_path + SequencePredictorSettings.model_timestamp + "/"
        seq_pred.load_model(seq_pred.model_path)
        loaded = True

    return seq_pred, loaded
