# LabLog

## 13.03
Bi-Direktionale LSTMs haben Probleme mit Pressure. Die Predictions fallen meist nach rechts ab und sind instabil.
Resultate vom 12.03 sind nicht wiederherstellbar. Vermutlich liegt es an den neuesten Änderungen am Autoencoder in Kombination mit dem alten LSTM Model.
Zwei hintereinander geschaltete LSTM mit go_backwards = False mit jeweils 400 Zellen funktionieren besser (2017-03-14-00-29-38).

## 14.03
Models:
- [2017-03-14-09-54-46]
        Zwei LSTM layer mit go_backwards = False und go_backwards = True (sequence und not sequence) ergeben ein anderes (schlechteres) Resultat als das gleiche Setup vom 12.03.
        Das Training erfolgte mit 28 Trainingsszenen.
- [2017-03-14-20-13-32]
        Training des gleichen Netzwerks mit 400 Szenen auf 10 Epochen.
        ____________________________________________________________________________________________________
        Layer (type)                     Output Shape          Param #     Connected to
        ====================================================================================================
        lstm_1 (LSTM)                    (None, 16, 400)       1102400     lstm_input_1[0][0]
        ____________________________________________________________________________________________________
        lstm_2 (LSTM)                    (None, 400)           1281600     lstm_1[0][0]
        ____________________________________________________________________________________________________
        dropout_8 (Dropout)              (None, 400)           0           lstm_2[0][0]
        ____________________________________________________________________________________________________
        dense_1 (Dense)                  (None, 288)           115488      dropout_8[0][0]
        ____________________________________________________________________________________________________
        activation_1 (Activation)        (None, 288)           0           dense_1[0][0]
        ====================================================================================================
        Total params: 2,499,488
        Trainable params: 2,499,488
        Non-trainable params: 0
        => mean_squared_error: 0.0064 - mean_absolute_error: 0.0555
        
        Die Resultate erreichen nicht die Qualität vom 12.03. Feine Details sind nicht sichtbar und das Netzwerk erzeugt nicht waagerechte Endkonfigurationen für die Pressure-Verteilung.
- [2017-03-14-22-14-07]
        Model erträumt keine Bewegung sondern versucht guten Status-Quo zu erzeugen. Nicht nutzbar. Training mit 400 Szenen auf 5 Epochen.
        ____________________________________________________________________________________________________
        Layer (type)                     Output Shape          Param #     Connected to
        ====================================================================================================
        lstm_1 (LSTM)                    (None, 16, 400)       1102400     lstm_input_1[0][0]
        ____________________________________________________________________________________________________
        dropout_8 (Dropout)              (None, 16, 400)       0           lstm_1[0][0]
        ____________________________________________________________________________________________________
        lstm_2 (LSTM)                    (None, 16, 400)       1281600     dropout_8[0][0]
        ____________________________________________________________________________________________________
        dropout_9 (Dropout)              (None, 16, 400)       0           lstm_2[0][0]
        ____________________________________________________________________________________________________
        lstm_3 (LSTM)                    (None, 400)           1281600     dropout_9[0][0]
        ____________________________________________________________________________________________________
        dropout_10 (Dropout)             (None, 400)           0           lstm_3[0][0]
        ____________________________________________________________________________________________________
        dense_1 (Dense)                  (None, 288)           115488      dropout_10[0][0]
        ____________________________________________________________________________________________________
        activation_1 (Activation)        (None, 288)           0           dense_1[0][0]
        ====================================================================================================
        Total params: 3,781,088
        Trainable params: 3,781,088
        Non-trainable params: 0
        => mean_squared_error: 0.0113 - mean_absolute_error: 0.0730
- [2017-03-14-22-53-27] bwd <-> [2017-03-14-22-59-06] fwd
        GRU Version: 
        ____________________________________________________________________________________________________
        Layer (type)                     Output Shape          Param #     Connected to
        ====================================================================================================
        gru_1 (GRU)                      (None, 16, 400)       826800      gru_input_1[0][0]
        ____________________________________________________________________________________________________
        dropout_8 (Dropout)              (None, 16, 400)       0           gru_1[0][0]
        ____________________________________________________________________________________________________
        gru_2 (GRU)                      (None, 400)           961200      dropout_8[0][0]
        ____________________________________________________________________________________________________
        dropout_9 (Dropout)              (None, 400)           0           gru_2[0][0]
        ____________________________________________________________________________________________________
        dense_1 (Dense)                  (None, 288)           115488      dropout_9[0][0]
        ____________________________________________________________________________________________________
        activation_1 (Activation)        (None, 288)           0           dense_1[0][0]
        ====================================================================================================
        Total params: 1,903,488
        Trainable params: 1,903,488
        Non-trainable params: 0
        => 2 Layer, 400 Zellen, (go_backwards oder forward), 32 szenen, 10 epochen -> erträumt immer Pressure-Abfall nach unten rechts. Nicht nutzbar.
        Unterschiedliches Verhalten bei FWD und BWD. FWD erscheint sinnvoller.
- [2017-03-14-23-05-47]
        Ebenfalls GRU wie oben jedoch auf MAE trainiert.
        Die Oberfläche ist näher am Original, jedoch ist die Unterteilung der Werte falsch -> Mix aus MAE uns MSE erscheint sinnvoll. Abwechselnd? Gleichzeitig?
- [2017-03-14-23-20-48]
        Kombinierte Loss-Function -> Ergebnisse erscheinen besser verteilt und folgen der Oberfläche -> GUT
        Der Aufbau des Netzes führt wieder zur schnellen Status-Quo-Findung. Bwd-Fwd-Mischung
        => Versuche nur FWD
- [2017-03-14-23-26-53]
        Fwd GRU mit kombiniertem Loss 0.5 <-> 0.5 -> Abfall in eine Richtung wieder sichtbar
        (mean_squared_error: 0.0214 - mean_absolute_error: 0.1059) 
        => 1. Versuche mit beiden Schichten als BWD, 2. Versuche mit stärkerer Gewichtung des MAE, um die Oberfläche stärker zu erhalten

## 15.03
- [2017-03-15-00-22-52]
        Bwd GRU -> Versucht Status-Quo zu erhalten, Abfluss in eine Richtung seltener als bei Fwd
        (mean_squared_error: 0.0188 - mean_absolute_error: 0.0987)
        => Stärkere Gewichtung auf MAE
- [2017-03-15-00-33-26]
        Bwd GRU mit 0.75 MAE und 0.25 MSE -> lernt sehr stark den Abfluss nach unten rechts
        (mean_squared_error: 0.0176 - mean_absolute_error: 0.0961)
        => Keine Idee woher dieses Lernverhalten stammt... :/
- [2017-03-15-10-56-19]
        Bi-Dir-LSTM (Bwd, Fwd) mit 2 Layern a 400 Zellen auf 2 Epochen mit 400 Szenen trainiert hat wieder deutlich bessere Ergebnisse.
        (mean_squared_error: 0.0195 - mean_absolute_error: 0.0969)
        => Gute Ergebnise bei Trainings mit 32 Szenen resultierten vermutlich aus Overfitting und waren Zufall
        => Real-Tests bei der Scene-Prediction ergeben immer noch das Bild einer Status-Quo-Suche mit stabilem Endresultat
        => Tests für alle Konfigurationen (Attention / GRU / Fwd / Bwd / Deep / ... ) müssen wiederholt werden.
        => Rückbau auf Sequential war nicht die Lösung der Probleme. Functional ist auf lange Sicht das bessere Model und ist für Attention notwendig.
- UPDATED TO NEW AUTOENCODER MODEL -> 15.03 11:56
        => Vermutlich resultierten das unerwartete Verhalten des LSTMs der letzten Tage aus einem nicht funktionierenden Overwrite der Trainingsdaten.
            Die genutzten Daten waren demzufolge mit dem veralteten auto-encoder enkodiert.
    -> ab hier wurden immer neue Daten aus dem DataSet generiert
- [2017-03-15-16-15-56]
        Bi-Dir-LSTM (Bwd, Fwd) mit 2 Layern a 400 Zellen auf 2 Epochen mit 64 Szenen trainiert mit neuem CAE verhält sich nun wieder sinnvoller, jedoch ist ein verzogener Rand zu beobachten, der nur aus dem neuen CAE kommen kann.
        => Training mit 10 Epochen um gute Vergleichswerte zu haben
- [2017-03-15-16-31-21]
        Bi-Dir-LSTM (Bwd, Fwd) mit 2 Layern a 400 Zellen auf 10 Epochen mit 64 Szenen trainiert. Die Ergebnisse sind nicht perfekt, jedoch deutlich (!) näher an der Simulation als alles zuvor.
        => Bwd only Training
- [2017-03-15-16-42-21]
        Bwd-Dual-LSTM mit 2 Layern a 400 Zellen auf 10 Epochen mit 64 Szenen trainiert. Deutlich schlechteres Ergebnisse als der Bi-Dir-Ansatz. Die Oberfläche sackt einfach ab und bewegt sich nicht weiter.
        => Fwd only Training
- [2017-03-15-16-50-21]
        Fwd-Dual-LSTM mit 2 Layern a 400 Zellen auf 10 Epochen mit 64 Szenen trainiert. Deutlich besser als mit Bwd. Die Real-Szenen haben immer noch einen Abfall nach unten rechts.
        => Single-Fwd LSTM
- [2017-03-15-17-01-48]
        Fwd-Single-LSTM mit 400 Zellen auf 10 Epochen mit 64 Szenen trainiert. Starkes oszilieren ist im Pressure-Field sichtbar. Die 'Traumleistung' ist jedoch deutlich höher als im Stacked-LSTM Ansatz.
        Single-LSTM ist scheinbar für Sequence Prediction (Many-to-One) am besten geeignet (für eine Datendimension von 1, bei Velo-Feldern war die Traumleistung bei Bwd-Fwd besser).
        Die Real-Szene sieht mit diesem Ansatz gut aus. Die Oszillation ist nicht so stark sichtbar wie erwartet. Die Oberfläche bleibt jedoch sehr unruhig und großflächige Wellen scheinen unmöglich.
        => Test mit Bwd-Single-LSTM
- [2017-03-15-17-12-10]
        Bwd-Single-LSTM mit 400 Zellen auf 10 Epochen mit 64 Szenen trainiert. Gegen Ende der Test-Simulationen des Pressure Fields zeigt sich selten ein wenig Oszillation. Manche Simulationen sind visuell sehr gut,
        andere sacken in sich zusammen. Im Real-Szenario ist das Ergebnis sehr gut. Es bildet sich immer noch ein leichtes Gefälle (nun nach links). Dies ist jedoch in einem nicht störenden Ausmaß.
        => Behalte Bwd-Single-LSTM und stelle auf MSE zurück.
    -> ab hier wurde die serialisierte Datei 'TrainingData_64.npz' genutzt
- [2017-03-15-17-35-49]
        Bwd-Single-LSTM mit 400 Zellen auf 10 Epochen mit 64 Szenen trainiert mit reinem MSE loss. Die Real-Resultate sind nicht so gut, da die Oberfläche nicht mehr so definiert ist wie bei einem Training mit MAE.
        Es folgt immer eine "Berg-Bildung". Dies  ähnelt einer Fluid-Quelle.
        => 75-25 MAE zu MSE mit Deep LSTM testen
        => danach Rückbau auf Functional
- [2017-03-15-17-54-04]
        Bwd-Single-LSTM (400 Zellen) und 100 Time Distributed Dense Neuronen pro Zelle auf 20 Epochen mit 64 Szenen trainiert. [Konkateniert mit sum lambda, 50-50 MAE zu MSE]
        Führt zu Flut-artigem Verhalten. Nicht sinnvoll.
        => Rückbau auf Functional als Bwd-Single-LSTM mit 400 Zellen
- [2017-03-15-18-33-38]
        Bwd-Single-LSTM mit 400 Zellen als Functional auf 20 Epochen mit 64 Szenen trainiert (75-25 MAE zu MSE). Sehr gute Resultate in der Pressure Prediction.
        [!] Bestes bisher
        => 1. Testen der Bidirectional Wrapper Function in gleicher Restkonfiguration
        => 2. Testen der GRU Zellen in gleicher Konfiguration.
- [2017-03-15-19-08-20]
        BiDir-Bwd-Single-LSTM mit 400 Zellen (x2) auf 20 Epochen mit 64 Szenen trainiert (75-25 MAE zu MSE). Schlechtes Resultat, nicht nutzbar.
        Für sehr kurze Zeit gibt es eine valide Bewegung, anschließend oszilliert die Szene und ruckelt sehr stark.
        => 2. Testen der GRU Zellen in gleicher Konfiguration.
- [2017-03-15-19-33-57]
        Bwd-Single-GRU mit 400 Zellen auf 20 Epochen mit 64 Szenen trainiert (75-25 MAE zu MSE). Abfluss nach rechts unten. Schlechteres Ergebnis als gleich aufgebautes LSTM.
        => Test mit Fwd
- [2017-03-15-19-54-27]
        Fwd-Single-GRU mit 400 Zellen auf 20 Epochen mit 64 Szenen trainiert (75-25 MAE zu MSE). Berg-Bildung, aber sehr "fluides" Verhalten. Real-Resultate sind nicht sehr gut. Meist explodiert die Oberfläche.
        => Wechsel zurück zu Bwd-Single-LSTM
- [2017-03-15-21-16-59]
        Bwd-Single-LSTM mit 800 Zellen auf 20 Epochen mit 64 Szenen trainiert (75-25 MAE zu MSE). Das Verhalten ist als "fluid" einzustufen, jedoch folgt es nicht dem simulierten Verlauf.
        Nicht nutzbar in realem Umfeld, da Abfluss geschaffen wird.
        => Testen von Fwd-Single-LSTM mit 800 Zellen
- [2017-03-15-21-34-46]
        Fwd-Single-LSTM mit 800 Zellen auf 20 Epochen mit 64 Szenen trainiert (75-25 MAE zu MSE). Führt zur Eskalationssimulation -> sehr instabile oszillierende Ergebnisse.
        [!] FWD ist nicht sinnvoll!
        => Bwd-Single-LSTM mit 400 Zellen (skipped)
- [2017-03-15-22-55-15]
        Fwd-Single-LSTM mit 800 Zellen kombiniert mit Attention-Network und Sum-Lambda Funktion. Gutes Fluid-Verhalten in den reinen Pressure Bildern.
        Im Real-Szenario verhält es sich okay. Das Netzwerk sucht nach ausgeglichenen Zustand.
        [!] FWD + ATT ist sinnvoll!
        => Bwd testen mit 400 Zellen (bestes bisher ohne Att)
- [2017-03-15-23-22-46]
        Bwd-Single-LSTM mit 400 Zellen kombiniert mit Attention-Network und Sum-Lambda Funktion. Zeitlich inkohärentes Verhalten. Nicht sinnvoll.
        => 1. Fwd-Single-LSTM mit 400 Zellen testen
        => 2. Reshape statt Lambda-Sum testen

## 16.03
- [2017-03-16-00-01-27]
        Fwd-Single-LSTM mit 400 Zellen kombiniert mit Attention-Network und Sum-Lambda Funktion. Besser als 800 Zellen FWD+ATT, da es wieder aus dem Ausgleichszustand herausfindet.
        => 1. Reshape statt Lambda-Sum testen
        => 2. Repeat Vector nutzen um Seq-2-Seq Model zu trainieren. Forciert die Prediction von x auf einander folgender Pressure-Felder. Dies könnte die zeitliche Kohärenz für die Prediction erhöhen.
- [2017-03-16-12-41-55]
        Fwd-Single-LSTM mit 400 Zellen kombiniert mit Attention-Network und Reshape statt Lambda Funktion. Besser als mit Sum-Lambda.
        => 1. Prediction im Loss und Vergleich der resultierenden Bilder -> im Loss nicht möglich -> Ausführen des Decoders nach der LSTM-Anwendung mit anschließender Backpropagation ohne Weights des Decoders zu ändern
        => 2. Repeat Vector nutzen um Seq-2-Seq Model zu trainieren. Forciert die Prediction von x auf einander folgender Pressure-Felder. Dies könnte die zeitliche Kohärenz für die Prediction erhöhen.

## 18.03
Großer Umbau des Netzwerkes durchgeführt. Nun besteht das Netzwerk aus der LSTM Schicht in Kombination mit einem Attention Layer. Zum Training wird das LSTM-ATT Ergebnis in den Decoder-Teil des Autoencoders gegeben und
der Loss mittels kombinierten MSE-MAE bestimmt. Der Vergleich findet auf dem dekodierten Bild des Zeitschritts und der zugehörigen Prediction statt. 

- [2017-03-18-13-47-14]
        Fwd-Single-LSTM mit 400 Zellen kombiniert mit Attention-Network und Reshape statt Lambda Funktion. Loss-Auswertung mit 1:1 Gewichtung von Code-Layer MAE-MSE (0.75) und dekodierten Bild (0.25).
        => 2. Repeat Vector nutzen um Seq-2-Seq Model zu trainieren. Forciert die Prediction von x auf einander folgender Pressure-Felder. Dies könnte die zeitliche Kohärenz für die Prediction erhöhen.
- [2017-03-18-18-45-27]
		Fwd-Single-LSTM mit 400 Zellen und Reshape ohne Attention-Network und Decoder. Repeat-Vector wurde auf 3 eingestellt. Die Predictions sind stark zusammenhängend. Es wird jedoch immer ein finaler Zustand angestrebt,
		bei dem das Pressure Feld annähernd komplett gefüllt ist. 
		=> Aktivieren des Decoders um diesen Zustand zu vermeiden.
- [2017-03-18-21-17-31]
		Fwd-Single-LSTM mit 400 Zellen und Reshape mit Attention-Network und Decoder. Repeat-Vector wurde auf 3 eingestellt. Das Verhalten ist zu träge und passt nicht zu einem Fluid.
		Artefakte bei der Ausgabe wurden beobachtet. Vermutlich gibt es Fehler in der Vorbereitung der Trainingsdaten. Diese sollten visuell überprüft werden.
		
		
## 23.03
Neuer Decoder -> 128 Code-Size

- [2017-03-23-21-49-38]
		Fwd-Single-LSTM mit 400 Zellen und Reshape mit Attention-Network. Ein Out-Timestep und 16 In-Timesteps. Training basiert rein auf der Loss-Auswertung des Decoders. Decoder-Loss ist MAE-MSE 1:1. Training für 10 Epochen.
		Netzwerk versucht komplette Zelle zu füllen. Findet oben ausgeglichenen Zustand.
		=> Training ohne Decoder und ohne Att mit 3 Out-Timesteps.
- [2017-03-23-22-24-55]
		Fwd-Single-LSTM mit 400 Zellen und Reshape ohne Attention-Network. Training ohne Decoder mit 3 Out-Timesteps und 16 In-Timesteps. Loss auf LSTM ist Variance. Training für 10 Epochen.
		Netzwerk Auswertung ruckelt stark -> liegt an Variance
		=> Training ohne Decoder und ohne Att mit 3 Out-Timesteps und MAE-MSE (0.75).
- [2017-03-23-22-35-20]
		Fwd-Single-LSTM mit 400 Zellen und Reshape ohne Attention-Network. Training ohne Decoder mit 3 Out-Timesteps und MAE-MSE (0.75). Training für 10 Epochen.
		Deutlich stabilerer Output. Resultate verlieren auf der linken Seite meist Pressure. Netzwerk versucht immer in Ausgangslage mit Berg nach rechts oben zu kommen.
		=> Training ohne Decoder und ohne Att mit 1 Out-Timesteps und MAE-MSE (0.75).
		=> Erhöhen der Anzahl der LSTM Zellen (x2 => 800)
- [2017-03-23-22-43-55]
		Fwd-Single-LSTM mit 800 Zellen und Reshape ohne Attention-Network. Training ohne Decoder mit 1 Out-Timestep und MAE-MSE (0.75). Training für 10 Epochen.
		Deutlich stabilerer Output. Resultate verlieren auf der linken Seite meist Pressure. Netzwerk versucht immer in Ausgangslage mit Berg nach rechts oben zu kommen.
		=> Versuche Bi-Dir

## 24.03
- [2017-03-24-10-59-33]
		BiDir-LSTM mit 800 Zellen (2x400) ohne Attention-Network. Training ohne Decoder mit 1 Out-Timestep und MAE-MSE (0.75). Training für 10 Epochen.
		Deutlich stabilerer Output. Resultate verlieren auf der linken Seite meist Pressure. Netzwerk versucht immer in Ausgangslage mit Berg nach rechts oben zu kommen.
		Merkwürdig, dass das LSTM sich immer ähnlich verhält. Diesmal obwohl es ein BiDir Netzwerk ist.
		=> Wechsel auf MAE-RMSE (0.5) Loss Funktion
- [2017-03-24-11-10-49]
		BiDir-LSTM mit 800 Zellen (2x400) ohne Attention-Network. Training ohne Decoder mit 1 Out-Timestep und MAE-RMSE (0.5). Training für 10 Epochen.
		Identisches Verhalten zu vorher. Es wird ein Berg nach oben rechts aufgebaut.
		=> Bwd-Single-LSTM
- [2017-03-24-11-20-34]
		Bwd-LSTM mit 400 Zellen ohne Attention-Network. Training ohne Decoder mit 1 Out-Timestep und MAE-RMSE (0.5). Training für 10 Epochen.
		Besseres Verhalten als zuvor. Kommt jedoch nicht an erwartetes Ergebnis heran. Wirkt nicht wie ein Fluid.
		=> Weniger In-Timesteps => z.B. 4
- [2017-03-24-11-29-32]
		Bwd-LSTM mit 400 Zellen ohne Attention-Network. Training ohne Decoder mit 1 Out-Timestep und 4 In-Timesteps sowie MAE-RMSE (0.5). Training für 10 Epochen.
		Bergbildung nach oben rechts (manchmal) und unrealistisches Verhalten.
		=> Fwd
- [2017-03-24-11-35-31]
		Fwd-LSTM mit 400 Zellen ohne Attention-Network. Training ohne Decoder mit 1 Out-Timestep und 4 In-Timesteps sowie MAE-RMSE (0.5). Training für 10 Epochen.
		Talbildung und unrealistisches Verhalten.
- [2017-03-24-19-18-01]
		[!] Fwd-LSTM mit 200 Zellen 
			activation='relu', 
			inner_activation='hard_sigmoid',
			dropout_U=0.1,
			dropout_W=0.1
		
		LSTM MODEL
		____________________________________________________________________________________________________
		Layer (type)                     Output Shape          Param #     Connected to
		====================================================================================================
		main_input (InputLayer)          (None, 10, 128)       0
		____________________________________________________________________________________________________
		lstm_1 (LSTM)                    (None, 200)           263200      main_input[0][0]
		____________________________________________________________________________________________________
		dropout_8 (Dropout)              (None, 200)           0           lstm_1[0][0]
		____________________________________________________________________________________________________
		dense_7 (Dense)                  (None, 128)           25728       dropout_8[0][0]
		====================================================================================================
		Total params: 288,928
		Trainable params: 288,928
		Non-trainable params: 0
		82110/82080 [==============================] - 10s - loss: 0.3823 - mean_squared_error: 0.2657 - mean_absolute_error: 0.3823

		Mean-Absolute-Error mit Drop-Out und einer geringeren LSTM-Zellen Anzahl (200 statt 400) mit internem Relu als Acivation löst die Probleme der Ausgleichszustandssuche.
		=> Relu Activation als End-Activation zum Angleichen an den Encoder des Autoencoders
- [2017-03-24-19-37-43]
		Fwd-LSTM mit 200 Zellen, Relu als finale Activation-Function. (Bwd in gleicher Konstellation ist definitiv falsch.)
			activation='relu', 
			inner_activation='hard_sigmoid',
			dropout_U=0.1,
			dropout_W=0.1
		Ohne Relu als finale Activation sind die Resultate besser. Das Fluid-Verhalten entspricht eher der Realität.
		=> Test mit LeakyRelu und Alpha von 0.3 um mögliche null/negativ Werte nicht zu verlieren.
- [2017-03-24-19-53-17]
		Fwd-LSTM mit 200 Zellen, LeakyRelu als finale Activation-Function.
		Resultate sind schlechter als ohne Activation.
		=> Attention
- [2017-03-24-21-13-55]
		Fwd-LSTM mit 200 Zellen mit Att, ohne finale Activation-Function. Merge mode ist "dot".
		Resultate nicht sonderlich gut. Pressure Verlust.
		=> "mul" mode (macht keinen Sinn, passt nicht zusammmen)
		
		
## 26.03
Umbau auf Velocities.
- [2017-03-26-17-31-10]
        [!] Sehr gute Ergebnisse (Video 4 ist problematisch)
        LSTM MODEL
            ____________________________________________________________________________________________________
            Layer (type)                     Output Shape          Param #     Connected to
            ====================================================================================================
            main_input (InputLayer)          (None, 10, 128)       0
            ____________________________________________________________________________________________________
            bidirectional_1 (Bidirectional)  (None, 10, 1600)      5945600     main_input[0][0]
            ____________________________________________________________________________________________________
            timedistributed_1 (TimeDistribut (None, 10, 100)       160100      bidirectional_1[0][0]
            ____________________________________________________________________________________________________
            timedistributed_2 (TimeDistribut (None, 10, 1)         100         timedistributed_1[0][0]
            ____________________________________________________________________________________________________
            reshape_2 (Reshape)              (None, 10, 1)         0           timedistributed_2[0][0]
            ____________________________________________________________________________________________________
            activation_3 (Activation)        (None, 10, 1)         0           reshape_2[0][0]
            ____________________________________________________________________________________________________
            merge_1 (Merge)                  (None, 1, 1600)       0           activation_3[0][0]
                                                                               bidirectional_1[0][0]
            ____________________________________________________________________________________________________
            reshape_3 (Reshape)              (None, 1600)          0           merge_1[0][0]
            ____________________________________________________________________________________________________
            dropout_8 (Dropout)              (None, 1600)          0           reshape_3[0][0]
            ____________________________________________________________________________________________________
            dense_9 (Dense)                  (None, 128)           204928      dropout_8[0][0]
            ====================================================================================================
            Total params: 6,310,728
            Trainable params: 6,310,728
            Non-trainable params: 0
            ____________________________________________________________________________________________________
            Epoch 25/25
                17825/17784 [==============================] - 51s - loss: 37.4548 - mean_squared_error: 37.4548 - mean_absolute_error: 4.8360
                Training duration (s): 1345.9918649196625
                Saving model Z:\Projects\GIT\CC\DeepPredictiveFluidNets\tensorflow\steffen/Output/2017-03-26-17-31-10/
        => Versuche LSTM Zellen zu reduzieren -> halbieren
- [2017-03-26-18-23-46]
        Schlechtere aber dennoch gute Prediction (Video 4 ist immer noch problematisch)
        LSTM MODEL
            ____________________________________________________________________________________________________
            Layer (type)                     Output Shape          Param #     Connected to
            ====================================================================================================
            main_input (InputLayer)          (None, 10, 128)       0
            ____________________________________________________________________________________________________
            bidirectional_1 (Bidirectional)  (None, 10, 800)       1692800     main_input[0][0]
            ____________________________________________________________________________________________________
            timedistributed_1 (TimeDistribut (None, 10, 100)       80100       bidirectional_1[0][0]
            ____________________________________________________________________________________________________
            timedistributed_2 (TimeDistribut (None, 10, 1)         100         timedistributed_1[0][0]
            ____________________________________________________________________________________________________
            reshape_2 (Reshape)              (None, 10, 1)         0           timedistributed_2[0][0]
            ____________________________________________________________________________________________________
            activation_3 (Activation)        (None, 10, 1)         0           reshape_2[0][0]
            ____________________________________________________________________________________________________
            merge_1 (Merge)                  (None, 1, 800)        0           activation_3[0][0]
                                                                               bidirectional_1[0][0]
            ____________________________________________________________________________________________________
            reshape_3 (Reshape)              (None, 800)           0           merge_1[0][0]
            ____________________________________________________________________________________________________
            dropout_8 (Dropout)              (None, 800)           0           reshape_3[0][0]
            ____________________________________________________________________________________________________
            dense_9 (Dense)                  (None, 128)           102528      dropout_8[0][0]
            ====================================================================================================
            Total params: 1,875,528
            Trainable params: 1,875,528
            Non-trainable params: 0
            ____________________________________________________________________________________________________
            Epoch 25/25
                17825/17784 [==============================] - 26s - loss: 40.4590 - mean_squared_error: 40.4590 - mean_absolute_error: 5.0130
                Training duration (s): 669.656299829483
                Saving model Z:\Projects\GIT\CC\DeepPredictiveFluidNets\tensorflow\steffen/Output/2017-03-26-18-23-46/
        => Erhöhen der Attention Zellen (von 100 auf 200)
- [2017-03-26-18-41-55]
        Zu viel Dreaming. Nicht gut.
        => Teste mit Decoder back prop
- [2017-03-26-18-58-28]
        Decoder Backprop ist nicht sinnvoll. Sehr falsche Ergebnisse.
        => Gehe zurück zu Setup [2017-03-26-18-23-46]
            => 1. Mehrere out time steps (e.g. 3)
            => 2. MAE zum Training
- [2017-03-26-20-14-50]
        MAE Loss führt zu schlechteren Ergebnissen als MSE
        => Mehrere out time steps (e.g. 3)
- [2017-03-26-20-48-57]
        Mehrere out time steps (3) funktionieren gut. Es gibt visuelle Verschlechterungen zu nur einem out step, die man vermutlich aber durch längeres Training vermindern kann.
        LSTM MODEL
            ____________________________________________________________________________________________________
            Layer (type)                     Output Shape          Param #     Connected to
            ====================================================================================================
            main_input (InputLayer)          (None, 10, 128)       0
            ____________________________________________________________________________________________________
            bidirectional_1 (Bidirectional)  (None, 10, 800)       1692800     main_input[0][0]
            ____________________________________________________________________________________________________
            timedistributed_1 (TimeDistribut (None, 10, 100)       80100       bidirectional_1[0][0]
            ____________________________________________________________________________________________________
            timedistributed_2 (TimeDistribut (None, 10, 1)         100         timedistributed_1[0][0]
            ____________________________________________________________________________________________________
            reshape_2 (Reshape)              (None, 10, 1)         0           timedistributed_2[0][0]
            ____________________________________________________________________________________________________
            activation_3 (Activation)        (None, 10, 1)         0           reshape_2[0][0]
            ____________________________________________________________________________________________________
            merge_1 (Merge)                  (None, 1, 800)        0           activation_3[0][0]
                                                                               bidirectional_1[0][0]
            ____________________________________________________________________________________________________
            reshape_3 (Reshape)              (None, 800)           0           merge_1[0][0]
            ____________________________________________________________________________________________________
            dropout_8 (Dropout)              (None, 800)           0           reshape_3[0][0]
            ____________________________________________________________________________________________________
            dense_9 (Dense)                  (None, 128)           102528      dropout_8[0][0]
            ____________________________________________________________________________________________________
            repeatvector_1 (RepeatVector)    (None, 3, 128)        0           dense_9[0][0]
            ====================================================================================================
            Total params: 1,875,528
            Trainable params: 1,875,528
            Non-trainable params: 0
            ____________________________________________________________________________________________________
        => insgesamt 1200 LSTM Zellen und 25 Epochen
- [2017-03-26-21-12-58]
        Keine Verbesserung/Verschlechterung
        
## 27.03
Velocities sind in real Nutzung nicht sinnvoll. Der hybride Simulationsansatz liefert sehr falsche Ergebnisse. [2017-03-27-13-57-31] ist ein gutes Velocity-Model, jedoch sind die Resultate nicht nutzbar.
=> Rückbau auf Pressure
		
## Ideen
    - Deep LSTM: >= 3 Layer -> ~10 Mio. Parameter (niedriger Standard für LSTMs) -> (How to Construct Deep Recurrent Neural Networks PDF, arXiv:1312.6026v5)
                 -> Deep-Backward-Model: 3 Layer mit 400 Zellen
    - Stateful: das Netz erstellt einen Internen Zustand über den Trainingsverlauf einer Szene. reset_states wird nur aufgerufen wenn die Epoche durchlief.
                Die Trainingssamples dürfen nicht geshuffelt sein. Epochen müssen durch eine Loop selbst programmiert werden.
                [2017-03-14-21-26-24]
                => Stateful ist nicht rentabel, da nur mit der Batch-Size predicted werden kann mit der das Netzwerk trainiert wurde
    - Loss: Wechsel der Loss-Funktion beim Training. Abwechselnde Nutzung von MSE und MAE.
                MAE: Oberfläche passt besser zum Original
                MSE: Unterteilung der Wertebereiche ist näher am Original
				Variance: RMSE - MAE -> größerer Wert bedeutet größere Varianz zwischen einzelnen Fehlern
    - GRU: Nutzung von GRU Units. Diese sind haben keine explizite Memory Cell und 'verstecken' keine Information vor anderen Zellen. -> Liefert keine besseren Ergebnisse -> Sucht häufig nur nach ausgeglichenen Zustand.
    - Decoded Loss: Nutzung des korrekten und predicteten dekodierten Pressure-Feldes als Loss-Input
                    Ausführen des Decoders nach der LSTM-Anwendung mit anschließender Backpropagation ohne Weights des Decoders zu ändern
    
    
    
## TODO
	- Fix train_generator_scene_func:
		Dec Data Shape: (106, 64, 64, 1) > Start: 16 End: 122
		Dec Data Shape: (106, 64, 64, 1) > Start: 17 End: 123
		Dec Data Shape: (106, 64, 64, 1) > Start: 18 End: 124
		=> hier werden Schritte übersprungen :/
		Dec Data Shape: (106, 64, 64, 1) > Start: 141 End: 247
		Dec Data Shape: (106, 64, 64, 1) > Start: 142 End: 248
		Dec Data Shape: (106, 64, 64, 1) > Start: 143 End: 249
    
    