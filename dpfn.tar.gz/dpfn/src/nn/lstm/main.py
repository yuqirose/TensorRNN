# (c) copyright 2017 Steffen Wiewel
import os, sys, inspect, subprocess, glob
import matplotlib.pyplot as plt
import numpy as np
import random
from mpl_toolkits.axes_grid1 import make_axes_locatable
from mpl_toolkits.axes_grid1 import AxesGrid
from math import floor

# fileDir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
# tf_dir = os.path.dirname(fileDir)
# sys.path.insert(0, tf_dir)

working_dir = os.getcwd()

from .general import get_auto_encoder
from .general import get_sequence_predictor
from .general import SequencePredictorSettings
from .general import AutoencoderType
from .general import start_session
from .general import get_auto_encoder_checkpoint_date
from .general import get_code_layer_normalize_factor
from .general import get_cae_normalize_factor

from ...util.logger import MultiLogger
from ...util import path

from . import error_classification
from ..array import shuffle_in_unison, rotate_to_new

from .sequence_prediction import SequencePredictor
from .sequence_training_data import TrainingData

#--------------------------------------------
def display_decoded_multi_timestep(auto_encoder, data_dimension, time_step, out_time_steps, correct, predicted, show_plot = True, image_file_path = None):
    #correct[ts][out_time_steps]
    #predicted_in_row[ts][out_time_steps]
    #predicted_at_once[ts][out_time_steps]
    # Input for timestep:
    #   correct[out_time_steps]
    #   predicted_in_row[out_time_steps]
    #   predicted_at_once[out_time_steps]
    if out_time_steps <= 1:
        return

    correct = np.multiply(correct, get_code_layer_normalize_factor())
    predicted = np.multiply(predicted, get_code_layer_normalize_factor())

    figsize = (6.0,6.0)
    num_of_plots = out_time_steps

    #fig, axarr = plt.subplots(3, num_of_plots, figsize=figsize, sharex='col', sharey='row')
    #axes[0].set_title('Correct ({})'.format(time_step))
    #axes[1].set_title('Prediction ({})'.format(time_step))

    fig = plt.figure(1, figsize)
    fig.subplots_adjust(left=0.15, right=0.85)

    grid = AxesGrid(fig, 111,  # similar to subplot(141)
                    nrows_ncols=(3, 3),
                    axes_pad=0.05,
                    label_mode="L",
                    share_all=True,
                    cbar_location="bottom",
                    cbar_mode="single"
                    )
    for cax in grid.cbar_axes:
        cax.toggle_label(False)
    axarr = [grid[0:3], grid[3:6], grid[6:9]]

    for row in axarr:
        for axis in row:
            axis.get_xaxis().set_visible(False)
            axis.get_yaxis().set_visible(True)
            axis.get_yaxis().set_ticks([])
            axis.set_xlim(0, 64)
            axis.set_ylim(0, 64)

    grid[0].set_title("t0")
    grid[1].set_title("t1")
    grid[2].set_title("t2")
    grid[0].set_ylabel("Simulation", rotation=0, size='large', labelpad=50)
    grid[3].set_ylabel("Prediction", rotation=0, size='large', labelpad=50)
    if SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
        grid[6].set_ylabel("Weighted\nCosine Similarity",  multialignment='center', horizontalalignment='center',
              verticalalignment='center', rotation=0, size='large', labelpad=55)
    else:
        grid[6].set_ylabel("Squared Error", rotation=0, size='large', labelpad=55)

    def draw_quiver(axis, auto_encoder, code):
        scale = get_cae_normalize_factor()
        decoded = auto_encoder.decode(np.reshape(code, (-1,code.shape[0]))) * scale
        axis.quiver(decoded[0, :, :, 0], decoded[0, :, :, 1], pivot='tail', color='k', scale=scale)
        return decoded[0]

    def draw_plot(figure, axis, auto_encoder, code, legend=False, cmap="Vega20c"):
        vmax = 1.0
        if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
            norm_factors = get_cae_normalize_factor()
            vmax = norm_factors[0]
            decoded = auto_encoder.decode_combined(np.reshape(code, (-1,code.shape[0])), norm_factors[0], norm_factors[1])
        if SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
            vmax = get_cae_normalize_factor()
            decoded = auto_encoder.decode(np.reshape(code, (-1,code.shape[0]))) * vmax
        im1 = axis.imshow(decoded[0,:,:,0], cmap=cmap, interpolation='nearest', vmin=0.0, vmax=vmax)
        return decoded[0]
        # divider = make_axes_locatable(axis)
        # cax = divider.append_axes('right', size='5%', pad = 0.05)
        # figure.colorbar(im1, cax=cax, orientation='vertical')

    def draw_error(grid, axis, correct_image, predicted_image, quiver):
        image_dimension = (correct_image.shape[0],correct_image.shape[1])
        #print("Image shape: {}".format(image_dimension))
        if quiver:
            # cosine similarity
            ZError = (correct_image[:, :, 0] * predicted_image[:, :, 0])
            ZError += (correct_image[:, :, 1] * predicted_image[:, :, 1])
            ZError += (correct_image[:, :, 2] * predicted_image[:, :, 2])
            #print("ZError: {}\n{}".format(ZError.shape, ZError))

            ZCorrectLength = np.power(correct_image[:, :, 0], 2)
            ZCorrectLength += np.power(correct_image[:, :, 1], 2)
            ZCorrectLength += np.power(correct_image[:, :, 2], 2)
            ZCorrectLength = np.sqrt(ZCorrectLength)
            #print("ZCorrectLength: {}\n{}".format(ZCorrectLength.shape, ZCorrectLength))
            
            ZPredictionLength = np.power(predicted_image[:, :, 0], 2)
            ZPredictionLength += np.power(predicted_image[:, :, 1], 2)
            ZPredictionLength += np.power(predicted_image[:, :, 2], 2)
            ZPredictionLength = np.sqrt(ZPredictionLength)
            #print("ZPredictionLength: {}\n{}".format(ZPredictionLength.shape, ZPredictionLength))

            ZLengthDif = np.abs(ZCorrectLength - ZPredictionLength)
            #print("ZLengthDif: {}\n{}".format(ZLengthDif.shape, ZLengthDif))

            # cosine sim [-1,1]
            ZError = np.divide(ZError, ZCorrectLength * ZPredictionLength)
            #print("Cosine Sim: {}\n{}".format(ZError.shape, ZError))

            # rescale to [0,1]
            ZError += 1.0
            ZError *= 0.5

            # reverse metric
            ZError = 1.0 - ZError

            # scale with length dif
            ZErrorScaled = np.multiply(ZError, ZLengthDif)
            #print("Scaled Cos Sim: {}\n{}".format(ZErrorScaled.shape, ZErrorScaled))

            # weighted
            ZError = np.clip(ZErrorScaled * 10.0, 0.0, 1.0)
            #print("Scaled Weighted Cos Sim: {}\n{}".format(ZError.shape, ZError))

            # # Squared error
            # ZError = (np.abs(correct_image[:, :, 0] - predicted_image[:, :, 0]) +
            #           np.abs(correct_image[:, :, 1] - predicted_image[:, :, 1]) +
            #           np.abs(correct_image[:, :, 2] - predicted_image[:, :, 2])) ** 2
            # ZError = (np.reshape(ZError, image_dimension))

            im = axis.imshow(ZError, cmap='hot', vmin=0.0, vmax=np.max(ZError))
            plt.colorbar(im, cax = grid.cbar_axes[0], orientation='horizontal')
        else:
            # Squared error
            ZError = np.abs(correct_image[:, :, 0] - predicted_image[:, :, 0]) ** 2
            ZError = (np.reshape(ZError, image_dimension))
            im = axis.imshow(ZError, cmap='hot', vmin=0.0, vmax=np.max(ZError))
            plt.colorbar(im, cax = grid.cbar_axes[0], orientation='horizontal')

    correct_decoded = []
    predicted_decoded = []
    if(1 < data_dimension <= 3):
        for i, axis in enumerate(axarr[0]):
            correct_decoded.append(draw_quiver(axis, auto_encoder, correct[i]))
        for i, axis in enumerate(axarr[1]):
            predicted_decoded.append(draw_quiver(axis, auto_encoder, predicted[i]))
        for i, axis in enumerate(axarr[2]):
            draw_error(grid, axis, correct_decoded[i], predicted_decoded[i], True)
    else:
        for i, axis in enumerate(axarr[0]):
            correct_decoded.append(draw_plot(fig, axis, auto_encoder, correct[i], legend=False, cmap="viridis"))
        for i, axis in enumerate(axarr[1]):
            predicted_decoded.append(draw_plot(fig, axis, auto_encoder, predicted[i], legend=False, cmap="viridis"))
        for i, axis in enumerate(axarr[2]):
            draw_error(grid, axis, correct_decoded[i], predicted_decoded[i], False)

    fig.tight_layout()

    if show_plot:
        plt.show()

    if image_file_path is not None:
        fig.savefig(image_file_path)
        plt.close(fig)

#--------------------------------------------
def display_decoded(auto_encoder, data_dimension, time_step, correct, predicted, ground_truth = None, show_plot = True, image_file_path = None):
    correct = np.multiply(correct, get_code_layer_normalize_factor())
    predicted = np.multiply(predicted, get_code_layer_normalize_factor())

    vmin = 0.0
    vmax = 1.0
    vscale = 1.0

    if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
        norm_factors = get_cae_normalize_factor()
        vmax = norm_factors[0]
        decode_correct = auto_encoder.decode_combined(np.reshape(correct, (-1,correct.shape[0])), norm_factors[0], norm_factors[1])
        decode_predicted = auto_encoder.decode_combined(np.reshape(predicted, (-1,predicted.shape[0])), norm_factors[0], norm_factors[1])
    else:
        vmax = get_cae_normalize_factor()
        vscale = vmax
        decode_correct = auto_encoder.decode(np.reshape(correct, (-1,correct.shape[0]))) * vmax
        decode_predicted = auto_encoder.decode(np.reshape(predicted, (-1,predicted.shape[0]))) * vmax

    if SequencePredictorSettings.autoencoder_type == AutoencoderType.levelset:
        vmin = -2.0
        vmax = 2.0

    cmap = "Vega20c"
    figsize = (9,3)
    num_of_plots = 3
    if ground_truth is None:
        num_of_plots = 2

    axes = []
    fig, axes = plt.subplots(1, num_of_plots, figsize=figsize)

    axes[0].set_title('Correct ({})'.format(time_step))
    axes[1].set_title('Prediction ({})'.format(time_step))

    for axis in axes:
        axis.get_xaxis().set_visible(False)
        axis.get_yaxis().set_visible(False)
        axis.set_xlim(0, 64)
        axis.set_ylim(0, 64)

    if(1 < data_dimension <= 3):
        axes[0].quiver(decode_correct[0, :, :, 0], decode_correct[0, :, :, 1], pivot='tail', color='k', scale=vscale)
        axes[1].quiver(decode_predicted[0, :, :, 0], decode_predicted[0, :, :, 1], pivot='tail', color='k', scale=vscale)
    else:
        im1 = axes[0].imshow(decode_correct[0,:,:,0], cmap=cmap, interpolation='nearest', vmin=vmin, vmax=vmax)
        divider = make_axes_locatable(axes[0])
        cax = divider.append_axes('right', size='5%', pad = 0.05)
        fig.colorbar(im1, cax=cax, orientation='vertical')

        im2 = axes[1].imshow(decode_predicted[0,:,:,0], cmap=cmap, interpolation='nearest', vmin=vmin, vmax=vmax)
        divider = make_axes_locatable(axes[1])
        cax = divider.append_axes('right', size='5%', pad = 0.05)
        fig.colorbar(im2, cax=cax, orientation='vertical')

    if ground_truth is not None:
        if(1 < data_dimension <= 3):
            axes[2].quiver(ground_truth[:, :, 0], ground_truth[:, :, 1], pivot='tail', color='k', scale=vscale*4.0)
            axes[2].set_title('Ground Truth ({})'.format(time_step))
        else:
            axes[2].set_title('Ground Truth ({})'.format(time_step))
            im3 = axes[2].imshow(ground_truth[:,:,0], cmap=cmap, interpolation='nearest', vmin=vmin, vmax=vmax)
            divider = make_axes_locatable(axes[2])
            cax = divider.append_axes('right', size='5%', pad = 0.05)
            fig.colorbar(im3, cax=cax, orientation='vertical')

    if show_plot:
        plt.show()

    if image_file_path is not None:
        fig.savefig(image_file_path)
        plt.close(fig)

#--------------------------------------------
def get_training_generator_count_per_epoch(scene_count, samples_per_scene_count, batch_size, time_steps, out_time_steps):
    return (batch_size-time_steps-out_time_steps + 1) * floor(samples_per_scene_count / batch_size) * scene_count

#--------------------------------------------
def train_generator_scene_func(ts, out_ts, cae_code_size, batch_size, enc_scenes, use_decoder, shuffle=False):
    scene_count = len(enc_scenes)
    sample_count = enc_scenes[0].encoded_data().shape[0]
    in_scene_iteration = floor(sample_count / batch_size)
    print("Scene Count: {}  Sample Count: {} In-Scene Iteration: {}".format(scene_count, sample_count, in_scene_iteration))

    # for attr in dir(enc_scenes[0]):
    #     print("{}".format(attr))

    while 1:
        for i in range(scene_count):
            scene = enc_scenes[i]
            for j in range(in_scene_iteration):
                # X = np.array([]).reshape(0, ts, cae_code_size)
                # Y = np.array([]).reshape(0, cae_code_size)
                enc_data = scene.encoded_data()

                start = j * batch_size
                end = ((j+1) * batch_size) # - out_ts
                X, Y = error_classification.restructure_encoder_data(
                                    data = enc_data[start : end],
                                    time_steps = ts,
                                    out_time_steps = out_ts)

                #print("X shape: {} Y shape: {}".format(X.shape, Y.shape))

                if use_decoder:
                    dec_data = scene.decoded_data()
                    data_length = Y.shape[0]
                    Y = [Y]

                    if out_ts > 1:
                        for i in range(out_ts):
                            dec_start = start+ts+i
                            dec_end = end - out_ts + i + 1
                            data = dec_data[dec_start : dec_end]
                            #print("Dec Data Shape: {} > Start: {} End: {}".format(data.shape, dec_start, dec_end))
                            Y.append(data)
                    else:
                        Y.append(dec_data[start+ts : end])

                    if shuffle:
                        array.shuffle_in_unison(X, *Y)
                    assert Y[0].shape[0] == Y[1].shape[0], ("Shapes need to have same length!")
                else:
                    if shuffle:
                        array.shuffle_in_unison(X, Y)

                yield X, Y

#--------------------------------------------
def get_batch_size(data_length):
    maximal_batch_size = min(data_length, 128)  # should be between 32-128
    for i in reversed(range(maximal_batch_size)): 
        if (data_length % i == 0):
            print("Batch Size: {} - # Samples: {}".format(i, data_length))
            return i
    return 1  # should never be reached

#--------------------------------------------

if __name__ == "__main__":
    start_session(1.0)

    # # # Setup Directories
    output_path, output_folder = path.add_timestamp_folder(working_dir + "/output/")
    multi_log = MultiLogger()
    multi_log.open(output_path+"Log.txt")
    print("Output Path: {}".format(output_path))
    out_file = open (output_path+"Performance.txt", 'w')
    print("Date\n\t{}".format( output_folder ), file=out_file)

    # # # Setup Variables
    training_data_path = working_dir + "/datasets/"

    if SequencePredictorSettings.autoencoder_type == AutoencoderType.pressure:
        training_data_set_name = "pressure"
        data_dimension = 1
    elif SequencePredictorSettings.autoencoder_type == AutoencoderType.total_pressure:
        training_data_set_name = "total_pressure"
        data_dimension = 1
    elif SequencePredictorSettings.autoencoder_type == AutoencoderType.velocity:
        training_data_set_name = "velocities"
        data_dimension = 3
    elif SequencePredictorSettings.autoencoder_type == AutoencoderType.levelset:
        training_data_set_name = "levelset"
        data_dimension = 1

    lstm_data_file_name = None
    #lstm_data_file_name = "TrainingData_64.npz"
    #lstm_data_file_name = "TrainingData_400.npz"

    training_data_begin_scene = 0
    sample_count = -1

    lstm_model_path = ""
    #lstm_model_path = working_dir + "/output/"
    use_generator = True
    target_batch_size = 250
    epochs = 50

    forward_prediction_video = True
    video_start_scene = 0
    video_count = 2
    video_frames = 80
    comparison_screenshots = True
    comparison_screenshot_count = 10

######## TESTCODE - DELETE > 
    seq_pred = SequencePredictor(decoder_model=None)  

    seq_pred.model_path = lstm_model_path
    seq_pred.data_dimension = 512
    seq_pred.batch_size =  target_batch_size - SequencePredictorSettings.time_steps
    seq_pred.epochs = epochs

    seq_pred.stateful = False
    seq_pred.lstm_activation = SequencePredictorSettings.lstm_activation
    seq_pred.use_bidirectional = SequencePredictorSettings.use_bidirectional
    seq_pred.use_decoder = SequencePredictorSettings.use_decoder
    seq_pred.use_attention = SequencePredictorSettings.use_attention
    seq_pred.time_steps = SequencePredictorSettings.time_steps
    seq_pred.out_time_steps = SequencePredictorSettings.out_time_steps
    seq_pred.hidden_lstm_neurons = SequencePredictorSettings.hidden_lstm_neurons
    seq_pred.attention_neurons = SequencePredictorSettings.attention_neurons
    seq_pred.lstm_loss = SequencePredictorSettings.lstm_loss
    seq_pred.decoder_loss = SequencePredictorSettings.decoder_loss

    seq_pred.build_model()
    seq_pred.info(out_file)
######## < TESTCODE - DELETE



    # # # Setup Velocity Dreamer
    vel_dreamer = get_auto_encoder(working_dir)

    # # # Load datasets
    training_data = TrainingData(
        time_steps=SequencePredictorSettings.time_steps,
        out_time_steps=SequencePredictorSettings.out_time_steps,
        cae_code_size=vel_dreamer.code_layer_size,
        use_decoder = SequencePredictorSettings.use_decoder,
        highres_dimension=(64,64,data_dimension),
        lowres_resolution=None, #[32,32],
        scene_length=250,
        train_percentage=90.0)

    print("\nLOAD DATA\n")
    if lstm_data_file_name is None:
        training_data.load_encoder_data(path = training_data_path + "vus_dataset/", sample_count = sample_count, autoencoder = vel_dreamer, begin_scene=training_data_begin_scene, file=out_file)
        training_data.serialize(out_path = training_data_path + "LSTM_Data/" + training_data_set_name +"/", lzma=False)
    else:
        training_data.load_from_file(file_path = training_data_path + "LSTM_Data/" + training_data_set_name + "/" + lstm_data_file_name, autoencoder = vel_dreamer)

    # # # Setup Sequence Predictor
    seq_pred, loaded_predictor = get_sequence_predictor(
        autoencoder = vel_dreamer,
        lstm_model_path = lstm_model_path,
        epochs = epochs,
        batch_size = target_batch_size - SequencePredictorSettings.time_steps)

    # # # Load test data
    X_test, Y_test, GT_test = training_data.generate_test_samples(data_name="encoded_data")
    data_len = Y_test.shape[0]
    new_data_len = int(floor(data_len / seq_pred.batch_size) * seq_pred.batch_size)
    X_test = X_test[0:new_data_len]
    Y_test = Y_test[0:new_data_len]
    GT_test = GT_test[0:new_data_len]
    print("Old to new data len: {} -> {}".format(data_len, new_data_len))
    print("Test Samples: {} {} {}".format(X_test.shape, Y_test.shape, GT_test.shape))

    # fig, ax = plt.subplots( nrows=1, ncols=1 )  # create figure & 1 axis
    # ax.hist(Y_test.flatten(), bins='auto')  # plt.hist passes it's arguments to np.histogram
    # ax.set_title("Code Layer Domain")
    # fig.savefig(output_path + "TrainingDataHistogram_" + get_auto_encoder_checkpoint_date() + ".png" )   # save the figure to file
    # plt.close(fig)
    # # plt.hist(Y_test.flatten(), bins='auto')  # plt.hist passes it's arguments to np.histogram
    # # plt.title("Code Layer Domain")
    # # plt.show()

    # display_decoded(vel_dreamer,
    #                 1 if (training_data_set_name == "pressure") else 3,
    #                 0, 
    #                 Y_test[0][0],
    #                 Y_test[0][0],
    #                 None, 
    #                 True, 
    #                 output_path + str("Test_PreTrain_{}.png".format(0)))

    # # # Load or Train model
    if loaded_predictor:
        seq_pred.info(out_file)
    else:
        seq_pred.build_model()
        seq_pred.info(out_file)
        # train
        if(use_generator):
            gen_nb_samples = get_training_generator_count_per_epoch(training_data.encoded_scene_list.train_count, training_data.scene_length, target_batch_size, seq_pred.time_steps, seq_pred.out_time_steps)
            print ("Number of samples per epoch: {}".format(gen_nb_samples))
            train_generator = train_generator_scene_func(
                ts = seq_pred.time_steps,
                out_ts = seq_pred.out_time_steps,
                cae_code_size = seq_pred.data_dimension,
                batch_size = target_batch_size,
                use_decoder = SequencePredictorSettings.use_decoder,
                enc_scenes = training_data.encoded_scene_list.train_scenes,
                shuffle = (seq_pred.stateful is False) )
            seq_pred.train(
                generator=train_generator,
                generator_nb_samples=gen_nb_samples
            )
        else:
            seq_pred.train(X=training_data.X_train, Y=training_data.Y_train)
        seq_pred.save_model(output_path + seq_pred.model_name)

    # display_decoded(vel_dreamer,
    #                 1 if (training_data_set_name == "pressure") else 3,
    #                 0, 
    #                 Y_test[0][0],
    #                 Y_test[0][0],
    #                 None, 
    #                 True, 
    #                 output_path + str("Test_PostTrain_{}.png".format(0)))

    # forward prediction
    if forward_prediction_video:
        test_scene_size = int(training_data.scene_length - seq_pred.time_steps)
        begin_timestep = int(video_start_scene * test_scene_size)

        for video_count in range(video_count):
            # initial dataset for prediction
            curX = X_test[begin_timestep]
            curX = np.reshape(curX, (1, seq_pred.time_steps, seq_pred.data_dimension))  # => (1, 16, 256)

            for i in range(begin_timestep, begin_timestep+video_frames, 1):
                #print("\n############ Prediction {}".format(i))
                prediction = seq_pred.predict(curX, 1)  # => (1, 256)
                display_decoded(vel_dreamer.autoencoder,
                                data_dimension,
                                i,
                                Y_test[i][0] if seq_pred.out_time_steps > 1 else Y_test[i],
                                prediction[0][0] if seq_pred.out_time_steps > 1 else prediction[0],
                                None, #GT_test[i][0] if seq_pred.out_time_steps > 1 else GT_test[i],
                                False,  # show_plot
                                output_path + str("Validation{}.png".format(i)))
                curX = array.rotate_to_new(curX, prediction, seq_pred.time_steps)

            os.chdir(output_path)
            subprocess.call(['ffmpeg',
            '-r', '15',
            '-f', 'image2',
            '-start_number', '{}'.format(begin_timestep),
            '-i', 'Validation%d.png',
            '-vcodec', 'libx264',
            '-crf', '18',
            '-pix_fmt', 'yuv444p',
            '{}-{}_{}.mp4'.format(begin_timestep, begin_timestep + video_frames, training_data_set_name.title())])

            os.chdir(output_path)
            filelist = glob.glob("Validation*.png")
            for f in filelist:
                os.remove(f)

            begin_timestep += test_scene_size

    # # # Prediction and Error Classification
    prediction = seq_pred.predict(X=X_test, batch_size=seq_pred.batch_size) # get_batch_size(X_test.shape[0]))
    #if seq_pred.out_time_steps <= 1:
    #    error_classification.error_classification(correct=Y_test, prediction=prediction, rescale=True, file=out_file)
    if comparison_screenshots:
        for i in range(comparison_screenshot_count):
            rand = random.randint(1, X_test.shape[0]-2)
            #print("Random Test Data:\n\tCorrect:\t{}\n\tPredicted:\t{}".format( Y_test[rand], prediction[rand] ), file=out_file)
            for j in range(seq_pred.out_time_steps):
                display_decoded(vel_dreamer.autoencoder,
                                data_dimension,
                                rand, 
                                Y_test[rand][j] if seq_pred.out_time_steps > 1 else Y_test[rand],
                                prediction[rand][j] if seq_pred.out_time_steps > 1 else prediction[rand],
                                None, # GT_test[rand][j] if seq_pred.out_time_steps > 1 else GT_test[rand],
                                False, 
                                output_path + str("Validation{}_{}.png".format(rand, j)))
            if seq_pred.out_time_steps > 1:
                display_decoded_multi_timestep(
                    vel_dreamer.autoencoder,
                    data_dimension,
                    rand,
                    seq_pred.out_time_steps,
                    Y_test[rand],
                    prediction[rand],
                    False,
                    output_path + str("Multi_TS_Validation{}.png".format(rand)))

    # # # Close file handles
    if out_file != None:
        out_file.close()

    multi_log.close()
