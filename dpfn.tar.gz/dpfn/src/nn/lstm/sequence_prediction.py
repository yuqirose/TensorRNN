# (c) copyright 2017 Steffen Wiewel
import keras.backend as K
from keras.models import Model, load_model
from keras.layers import Input, Merge, RepeatVector, LSTM, GRU, TimeDistributed, Dense, Reshape, Activation, Dropout, merge, Lambda, Bidirectional
from keras.optimizers import RMSprop

import argparse
import time

from ..helpers import print_weight_summary, make_layers_trainable
from ..callbacks import StatefulResetCallback
from ..losses import Loss, LossType

#=================================================
# Classes
#=================================================
class SequencePredictor(object):
    def __init__(self, decoder_model):
        # IO
        self.model_path = ""
        self.model_name = ""

        # Training Settings
        self.epochs = 1
        self.batch_size = 1
        self.time_steps = 4
        self.data_dimension = 1
        self.stateful = False
        self.use_attention = False
        self.use_decoder = False
        self.use_bidirectional = False
        self.hidden_lstm_neurons = 500
        self.attention_neurons = 400
        self.out_time_steps = 3
        self.lstm_activation = 'tanh'

        self.network_layout = []

        # Model
        self.model = None
        self.lstm_model = None
        self.decoder_model = decoder_model

        # Loss
        self.lstm_optimizer = RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)
        self.lstm_loss = Loss(loss_type=LossType.mae, loss_ratio=1.0, loss_weight=1.0)

        self.decoder_optimizer = self.lstm_optimizer
        self.decoder_loss = self.lstm_loss

    #=================================================
    # Preparation
    #=================================================
    # parse the command line arguments
    #-------------------------------------------------
    def parse_arguments(self):
        parser = argparse.ArgumentParser()
        parser.add_argument("-e","--epochs", help="number of epochs to train")
        parser.add_argument("-b","--batch_size", help="number of simultaneously trained datasets")
        parser.add_argument("-ts","--time_steps", help="number of following elements in the sequence")
        parser.add_argument("-s","--stateful", help="stateful LSTM training")
        parser.add_argument("-m","--model_path", help="path of a model (.h5) file")
        args = parser.parse_args()
        if(args.epochs):
            self.epochs = int(args.epochs)
        if(args.batch_size):
            self.batch_size = int(args.batch_size)
        if(args.time_steps):
            self.time_steps = int(args.time_steps)
        if(args.stateful):
            self.stateful = bool(args.stateful)
        if(args.model_path):
            self.model_path = args.model_path

    def info(self, file = None):
        # Network Setup
        # --------------------------------------------
        print("Network Setup", file=file)
        print("\tEpochs: {}".format(self.epochs), file=file)
        print("\tBatch Size: {}".format(self.batch_size), file=file)
        print("\tTime Steps: {}".format(self.time_steps), file=file)
        print("\tStateful: {}".format(self.stateful), file=file)
        print("\tNetwork Layout:", file=file)
        for (layer_name, content) in self.network_layout:
            print("\t\t"+layer_name, file=file)
            for k, v in content.items():
                print("\t\t\t{}: {}".format(k, v), file=file)
        # print("\tHidden Neurons: {}".format(self.attention_neurons), file=file)
        print("Model Summary", file=file)
        #print(str(self.model.to_yaml()), file=file)

    #============================================
    # Definition
    #============================================
    def _bidirectional_wrapper(self, use_bidirectional, inner_layer, merge_mode='concat'):
        if use_bidirectional:
            return Bidirectional(layer=inner_layer, merge_mode=merge_mode)
        else:
            return inner_layer

    #--------------------------------------------
    def _inner_RNN_layer(self, use_gru, output_dim, go_backwards, return_sequences):
        activation=self.lstm_activation #def: tanh
        recurrent_activation='hard_sigmoid' #def: hard_sigmoid
        dropout=0.0 #def: 0.
        recurrent_dropout=0.0 #def: 0.

        if use_gru:
            return GRU( units=output_dim,
                        stateful=self.stateful,
                        go_backwards=go_backwards,
                        return_sequences=return_sequences,
                        activation=activation, #def: tanh
                        recurrent_activation=recurrent_activation, #def: hard_sigmoid
                        dropout=dropout, #def: 0.
                        recurrent_dropout=recurrent_dropout,  #def: 0.
                        )
        else:
            return LSTM(units=output_dim,
                        stateful=self.stateful,
                        go_backwards=go_backwards,
                        return_sequences=return_sequences,
                        #return_state=True,
                        activation=activation, #def: tanh
                        recurrent_activation=recurrent_activation, #def: hard_sigmoid
                        dropout=dropout, #def: 0.
                        recurrent_dropout=recurrent_dropout,  #def: 0.
                        #use_bias=False
                        )

    #--------------------------------------------
    def _add_RNN_layer_func(self, previous_layer, output_dim, go_backwards, return_sequences, bidirectional=False, use_gru=False):
        x = self._bidirectional_wrapper(
                use_bidirectional = bidirectional,
                merge_mode = 'sum',  #'concat',
                inner_layer = self._inner_RNN_layer(
                                    use_gru=use_gru,
                                    output_dim=output_dim,
                                    go_backwards=go_backwards,
                                    return_sequences=return_sequences))(previous_layer)
        self.network_layout.extend(
            [("GRU_Layer" if use_gru else "LSTM_Layer",
                {
                    'Activation': self.lstm_activation,
                    'Output Dimension': output_dim,
                    'Backwards': go_backwards
                }
            )]
        )
        return x
    #--------------------------------------------
    def _add_merge_tensor(self, prev_tensor):
        self.network_layout.extend(
            [("Merge Tensor",
                {
                    'Input duplicate': True
                }
            )]
        )
        return merge([prev_tensor, prev_tensor], mode='concat', concat_axis=1)

    #--------------------------------------------
    def _build_lstm_model(self, input_layer):
        # add loss information to network layout
        self.network_layout.extend(self.lstm_loss.info_struct())

        lstm = input_layer
        #lstm = self._add_merge_tensor(lstm)

        lstm = self._add_RNN_layer_func(    previous_layer=lstm,
                                            output_dim=self.hidden_lstm_neurons,
                                            go_backwards=True,
                                            return_sequences=self.use_attention,
                                            bidirectional=self.use_bidirectional,
                                            use_gru=False)
        #lstm = TimeDistributed(Dense(self.attention_neurons))(lstm)

        if self.use_attention:
            # # ATTENTION MODEL -> https://groups.google.com/forum/#!topic/keras-users/IWK9opMFavQ
            att = TimeDistributed(Dense(self.attention_neurons, activation='tanh'))(lstm) # [n_samples, n_steps, rnn_dim]
            att = TimeDistributed(Dense(1, bias=False))(att)                            # [n_samples, n_steps, 1]
            att = Reshape((self.time_steps, 1))(att)                                  # [n_samples, n_steps]
            att = Activation('softmax')(att)                                            # [n_samples, n_steps]

            x = merge([att, lstm], mode='dot', dot_axes=(1,1))                       # [n_samples, rnn_dim]

            input_size = self.hidden_lstm_neurons if self.use_bidirectional else self.hidden_lstm_neurons
            #x = Lambda(lambda x: K.sum(x, axis=-2), output_shape=(self.hidden_lstm_neurons,))(x)
            x = Reshape((input_size, ))(x)                                  # [n_samples, n_steps]
        else:
            x = lstm
            #x = Lambda(lambda x: K.sum(x, axis=-2), output_shape=(int(self.attention_neurons/2),))(lstm)

        #x = Lambda(lambda x: K.sum(x, axis=-2), output_shape=(self.hidden_lstm_neurons,))(lstm)
        #x = lstm
        #x = Dense(self.attention_neurons, activation='sigmoid')(lstm)
        x = Dropout(0.2)(x)

        if self.out_time_steps > 1:
            lstm_output = RepeatVector(self.out_time_steps)(x)
            #lstm_output = TimeDistributed(Dense(self.hidden_lstm_neurons))(lstm_output)
            lstm_output = self._add_RNN_layer_func(previous_layer=lstm_output,
                                            output_dim=self.hidden_lstm_neurons,
                                            go_backwards=False,
                                            return_sequences=True,
                                            bidirectional=self.use_bidirectional,
                                            use_gru=False)
            lstm_output = self._add_RNN_layer_func(previous_layer=lstm_output,
                                            output_dim=self.data_dimension,
                                            go_backwards=False,
                                            return_sequences=True,
                                            bidirectional=False,
                                            use_gru=False)
        else:
            x = Dense(self.data_dimension)(x)
            lstm_output = x # Activation("linear")(x)

        self.lstm_model = Model(inputs=input_layer, outputs=lstm_output)

        print("\nLSTM MODEL")
        self.lstm_model.summary()

        compilationStartTime = time.time()
        self.lstm_model.compile(loss=self.lstm_loss,
                                optimizer=self.lstm_optimizer,
                                metrics=['mean_squared_error', 'mean_absolute_error'])
        print("Compilation Time: {}".format(time.time() - compilationStartTime))

    #--------------------------------------------
    def _build_lstm_decoder_model(self):
        # Lock the decoder's parameters in training
        make_layers_trainable(self.decoder_model, False, True)

        outputs = [self.lstm_model.output]
        loss = [self.lstm_loss]
        loss_weights = [self.lstm_loss.loss_weight] # no optimization of LSTM directly when 0.0 is applied

        if self.out_time_steps > 1:
            for i in range(self.out_time_steps):
                decoder_input = Lambda(lambda x: x[:,i,:])(self.lstm_model.output)
                outputs.append(self.decoder_model(decoder_input))
                loss.append(self.decoder_loss)
                loss_weights.append(self.decoder_loss.loss_weight)
        else:
            outputs.append(self.decoder_model(self.lstm_model.output))
            loss.append(self.decoder_loss)
            loss_weights.append(self.decoder_loss.loss_weight)

        # # # Build Merged Model
        self.model = Model(input=self.lstm_model.input, output=outputs)

        print("\nLSTM DECODER MODEL")
        self.model.summary()

        compilationStartTime = time.time()
        self.decoder_model.compile( loss=self.decoder_loss,
                                    optimizer=self.decoder_optimizer,
                                    metrics=['mean_squared_error', 'mean_absolute_error'])
        #print_weight_summary("Decoder Model", self.decoder_model)
        self.model.compile( loss=loss,
                            loss_weights=loss_weights,
                            optimizer= self.lstm_optimizer,
                            metrics=['mean_squared_error', 'mean_absolute_error'])
        print("Compilation Time: {}".format(time.time() - compilationStartTime))

    #--------------------------------------------
    def build_model(self):
        # # # Functional
        main_input = Input(shape=(self.time_steps, self.data_dimension), dtype="float32", name='main_input')

        self._build_lstm_model(input_layer=main_input)

        if self.use_decoder:
            self._build_lstm_decoder_model()

    # --------------------------------------------
    ''''
    # Load the model from file
    '''
    def load_model(self, model_path):
        print("Loading model: " + model_path)
        try:
            self.lstm_model = load_model(
                filepath = model_path+"lstm_autoencoder_model.h5",
                custom_objects= {'LOSS_RATIO_MAE_MSE': self.lstm_loss })
        except Exception as e:
            print("EXCEPTION: {}".format(str(e)))
    # --------------------------------------------
    ''''
    # Save the model to file
    '''
    def save_model(self, model_path):
        # save model with weights and optimzier settings
        print("Saving model {}".format(model_path))
        self.lstm_model.save(filepath = model_path)

    # ============================================
    # Execution
    # ============================================
    # --------------------------------------------
    '''
    # Train
    Train the model with the specified training data
    '''
    def train(self, X=None, Y=None, generator = None, generator_nb_samples = 0):
        model = self.model if self.use_decoder else self.lstm_model
        try:
            trainingDuration = 0.0
            trainStartTime = time.time()
            if (self.stateful is True):
                if (generator is None):
                    assert X is not None and Y is not None, ("X or Y is None!")
                    for i in range(self.epochs):
                        model.fit(
                            X,
                            Y,
                            nb_epoch=1,
                            batch_size=self.batch_size,
                            shuffle=False)
                        model.reset_states()
                else:
                    reset_callback = StatefulResetCallback(model)
                    for i in range(self.epochs):
                        model.fit_generator(
                            generator,
                            samples_per_epoch = generator_nb_samples,
                            nb_epoch = 1,
                            verbose=1,
                            callbacks=[reset_callback],
                            validation_data=None,
                            class_weight=None,
                            nb_worker=1)
                        model.reset_states()
            else:
                if (generator is None):
                    assert X is not None and Y is not None, ("X or Y is None!")
                    model.fit(
                        X,
                        Y,
                        nb_epoch=self.epochs,
                        batch_size=self.batch_size,
                        shuffle=True)
                else:
                    model.fit_generator(
                        generator,
                        samples_per_epoch = generator_nb_samples,
                        nb_epoch = self.epochs,
                        verbose=1,
                        callbacks=[],
                        validation_data=None,
                        class_weight=None,
                        nb_worker=1)
            trainingDuration = time.time() - trainStartTime
        except KeyboardInterrupt:
            print("Training duration (s): {}\nInterrupted by user!".format(trainingDuration))
        print("Training duration (s): {}".format(trainingDuration))

    #--------------------------------------------
    '''
    # Test
    Use the test data to show a predicted image of the next time step
    '''
    def predict(self, X, batch_size=1):
        predictionDuration = 0
        prediction = None
        try:
            predictionStartTime = time.time()
            if self.stateful is True:
                prediction = self.lstm_model.predict(x=X, batch_size=batch_size)
            else:
                prediction = self.lstm_model.predict(x=X, batch_size=batch_size)
            predictionDuration = time.time() - predictionStartTime
            #print("Prediction Shape: {}".format(prediction.shape))
        except Exception as e:
            print(str(e))
        #print("Prediction duration (s): {}".format(predictionDuration))
        return prediction