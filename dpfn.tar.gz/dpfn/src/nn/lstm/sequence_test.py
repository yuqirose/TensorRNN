# (c) copyright 2017 Steffen Wiewel

#import os, sys, inspect
# fileDir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
# tf_dir = os.path.dirname(fileDir)
# sys.path.insert(0, tf_dir)

import unittest
import numpy as np

from ..array import rotate_to_new
from ..array import shuffle_in_unison

class SequenceTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        #np.set_printoptions(threshold=np.nan)
        cls.code_layer_size = 288
        cls.time_steps = 16
        cls.steps_into_future = 3
        cls.out_ts = 3

    # @classmethod
    # def tearDownClass(cls):

    #--------------------------------------------
    def _build_sequence(self, code_layer_size, start, stop):
        sequence = []
        for i in range(start, stop):
            sequence.append(np.ones(code_layer_size) * i)
        sequence = np.array(np.asarray(sequence))
        sequence = sequence.reshape( (1,stop-start,code_layer_size) )
        self.assertEqual(sequence.ndim, 3)
        return sequence

    #--------------------------------------------
    '''
        Test the rotate_to_new function used in sequence prediction
    '''
    def test_step_forward_1_out_ts(self):
        # initial values [0 -> time steps]
        X = self._build_sequence(
            code_layer_size=self.code_layer_size,
            start=0,
            stop=self.time_steps)

        new_X = X

        for i in range(self.steps_into_future):
            current_ts = self.time_steps + i
            Y = np.array(np.ones(self.code_layer_size) * current_ts)
            Y = Y.reshape( (1,self.code_layer_size) )
            self.assertEqual(Y.ndim, 2)

            old_X = new_X
            new_X = rotate_to_new(new_X, Y, self.time_steps)

            self.assertEqual(new_X.ndim, 3)

            for i in range(1, self.time_steps):
                self.assertTrue( np.all( (new_X[0, i-1], old_X[0, i]) ))
            self.assertTrue( np.all( (new_X[0, self.time_steps-1], Y[0]) ))

        return new_X, Y

    #--------------------------------------------
    def test_step_forward_X_out_ts(self):
        # initial values [0 -> time steps]
        X = self._build_sequence(
            code_layer_size=self.code_layer_size,
            start=0,
            stop=self.time_steps)

        new_X = X

        for i in range(self.steps_into_future):
            current_ts = self.time_steps + i

            Y = self._build_sequence(
                code_layer_size=self.code_layer_size,
                start=current_ts,
                stop=current_ts + self.out_ts)

            old_X = new_X
            new_X = rotate_to_new(new_X, Y, self.time_steps)

            self.assertEqual(new_X.ndim, 3)

            for i in range(1, self.time_steps):
                self.assertTrue( np.all( (new_X[0, i-1], old_X[0, i]) ))
            self.assertTrue( np.all( (new_X[0, self.time_steps-1], Y[0][0]) ))

        return new_X, Y

    #--------------------------------------------
    def test_shuffle(self):
        a = np.random.randint(1000, size=300)
        b = np.array(a, copy=True)
        self.assertTrue( np.all( (a,b) ))
        shuffle_in_unison(a,b)
        self.assertTrue( np.all( (a,b) ))

if __name__ == "__main__": 
    unittest.main()