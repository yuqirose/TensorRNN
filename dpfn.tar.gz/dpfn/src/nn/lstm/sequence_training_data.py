# (c) copyright 2017 Steffen Wiewel
import numpy as np
import matplotlib.pyplot as plt
import os #, sys, inspect
from pathlib import Path

# fileDir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
# parentdir = os.path.dirname(fileDir)
# sys.path.insert(0, parentdir)

from .error_classification import restructure_encoder_data
from .general import SequencePredictorSettings
from .general import get_auto_encoder_checkpoint_date
from .general import get_code_layer_normalize_factor
from .general import get_cae_normalize_factor

from dataset import datasets
from util import settings

import time

from functools import reduce
from enum import Enum

#---------------------------------------------------------------------------------
class TrainingDataType(Enum):
    SplitPressure = 0
    TotalPressure = 1
    SplitPressureVAE = 2
    SplitPressureDynamic = 3
    Velocity = 4
    TotalPressureGas = 5
    PressureDensityGas = 6

#---------------------------------------------------------------------------------
class TrainingData(object):
    #--------------------------------------------
    def __init__(self, test_split = 0.1):
        settings.load("settings.json")
        self.test_split = test_split

    #--------------------------------------------
    def printData(self, file=None):
        print("Dataset dimensions:", file=file)
        print("\tScene count: {}".format(self.encoded_scene_list.num_scenes), file=file)
        print("\tTrain count: {}".format(self.encoded_scene_list.train_length), file=file)
        print("\tTest count: {}".format(self.encoded_scene_list.test_length), file=file)

    #--------------------------------------------
    def data_shape(self, flat=False):
        """ data shape of the CAE encoded frames """
        data_shape = self.encoded_scene_list.data.shape[2:]
        if flat:
            data_shape = reduce(lambda x,y: x*y, data_shape)
        return data_shape

    #--------------------------------------------
    @property
    def normalization_factor(self):
        """ the factor used to normalize the data block """
        return 1.0 if self.encoded_scene_list is None else self.encoded_scene_list.norm_factor

    #--------------------------------------------
    def get_encoded_file_name(self, training_data_type):
        if training_data_type is TrainingDataType.SplitPressure:
            out_file_name="encoded_split_pressure"
        elif training_data_type is TrainingDataType.TotalPressure:
            out_file_name="encoded_total_pressure"
        elif training_data_type is TrainingDataType.SplitPressureVAE:
            out_file_name="encoded_split_pressure_vae"
        elif training_data_type is TrainingDataType.SplitPressureDynamic:
            out_file_name="encoded_split_pressure_dynamic"
        elif training_data_type is TrainingDataType.Velocity:
            out_file_name="encoded_velocity"
        elif training_data_type is TrainingDataType.TotalPressureGas:
            out_file_name="encoded_total_pressure_gas"
        elif training_data_type is TrainingDataType.PressureDensityGas:
            out_file_name="encoded_pressure_density_gas"
        else:
            assert False, ("training_data_type '{}' is unkown".format(training_data_type))
        return out_file_name


    #--------------------------------------------
    def normalize_scene_list(self, training_data_type):
        norm_factor = settings.dataset.pressure_encoded_normalization_factor
        if training_data_type is TrainingDataType.TotalPressure:
            norm_factor = settings.dataset.pressure_encoded_total_normalization_factor
        if training_data_type is TrainingDataType.SplitPressureDynamic:
            norm_factor = settings.dataset.pressure_encoded_dynamic_normalization_factor
        if training_data_type is TrainingDataType.SplitPressureVAE:
            norm_factor = settings.dataset.pressure_encoded_vae_normalization_factor
        if training_data_type is TrainingDataType.Velocity:
            norm_factor = settings.dataset.velocity_encoded_normalization_factor
        if training_data_type is TrainingDataType.TotalPressureGas:
            norm_factor = settings.dataset.pressure_encoded_total_gas_normalization_factor
        if training_data_type is TrainingDataType.PressureDensityGas:
            norm_factor = settings.dataset.pressure_density_encoded_gas_normalization_factor
        #print("Percentile 99.5: {}".format(np.percentile(self.encoded_scene_list.data, 99.5)))
        #print("Percentile 99.9: {}".format(np.percentile(self.encoded_scene_list.data, 99.9)))
        #print("Min: {}".format(np.amin(self.encoded_scene_list.data)))
        #print("Max: {}".format(np.amax(self.encoded_scene_list.data)))
        #print("Mean: {}".format(np.mean(self.encoded_scene_list.data)))
        assert self.normalization_factor == 1.0, ("SceneList already normalized!")
        self.encoded_scene_list.normalize(factor=norm_factor)

    #--------------------------------------------
    def load_from_file(self, training_data_type, dataset_name="", dataset_path=""):
        histogram_path = dataset_path if dataset_path else "."

        load_start_time = time.time()
        self.encoded_scene_list = datasets.SceneList.load(file_name=self.get_encoded_file_name(training_data_type)+".npz", dataset_name=dataset_name, dataset_path=dataset_path, test_split=self.test_split)
        self.encoded_scene_list.save_histogram(histogram_path + "/enc_scene_list_{}.png".format(self.encoded_scene_list.name))
        self.normalize_scene_list(training_data_type)
        self.encoded_scene_list.save_histogram(histogram_path + "/enc_scene_list_{}_normalized.png".format(self.encoded_scene_list.name))
        load_duration = time.time() - load_start_time
        print("Load Duration: {}".format(load_duration))
        self.printData()

    #--------------------------------------------
    def load_from_folder(self, autoencoder, autoencoder_desc, training_data_type, chunk_size, dataset_path, mirror_data = True):
        assert chunk_size>0, ("LSTM dataset creation only possible with chunk_size > 0")
        load_start_time = time.time()

        print("Loading LSTM training data from '{}'".format(dataset_path))

        # Variable Setup
        if training_data_type is TrainingDataType.SplitPressure or training_data_type is TrainingDataType.SplitPressureVAE or training_data_type is TrainingDataType.SplitPressureDynamic:
            blocks = ["pressure_static", "pressure_dynamic"]
            norm_factors = {
                "pressure_static": autoencoder_desc["dataset"]["pressure_static_normalization_factor"], #settings.dataset.pressure_static_normalization_factor,
                "pressure_dynamic": autoencoder_desc["dataset"]["pressure_dynamic_normalization_factor"] #settings.dataset.pressure_dynamic_normalization_factor
            }
            out_file_name = self.get_encoded_file_name(training_data_type)
        elif training_data_type is TrainingDataType.TotalPressure:
            blocks = ["pressure"]
            norm_factors= {
                "pressure": autoencoder_desc["dataset"]["pressure_normalization_factor"] #settings.dataset.pressure_normalization_factor
            }
            out_file_name = self.get_encoded_file_name(training_data_type)
        elif training_data_type is TrainingDataType.Velocity:
            blocks = ["vel"]
            norm_factors= {
                "vel": autoencoder_desc["dataset"]["velocity_normalization_factor"] #settings.dataset.velocity_normalization_factor
            }
            out_file_name = self.get_encoded_file_name(training_data_type)
        elif training_data_type is TrainingDataType.TotalPressureGas:
            blocks = ["pressure"]
            norm_factors= {
                "pressure": autoencoder_desc["dataset"]["pressure_normalization_factor"] #settings.dataset.pressure_normalization_factor
            }
            out_file_name = self.get_encoded_file_name(training_data_type)
        elif training_data_type is TrainingDataType.PressureDensityGas:
            blocks = ["pressure", "density"]
            norm_factors= {
                "pressure": autoencoder_desc["dataset"]["pressure_normalization_factor"] # TODO: check if density is missing here...
            }
            out_file_name = self.get_encoded_file_name(training_data_type)

        # Load Logic
        encoded_data = None
        dataset = datasets.DataSet()
        dataset.load(
            path=dataset_path,
            blocks=blocks, 
            norm_factors=norm_factors,
            files_per_batch=chunk_size,
            validation_split=0.0,
            test_split=0.0)

        while dataset.train.next_chunk(stop_on_overflow=True):
            if training_data_type is TrainingDataType.SplitPressure or training_data_type is TrainingDataType.SplitPressureVAE or training_data_type is TrainingDataType.SplitPressureDynamic:
                scene_size = dataset.train.pressure_dynamic.scene_size
                version = dataset.train.pressure_dynamic.version
                seed = dataset.train.pressure_dynamic.seed
                temp_enc_data = self.prepare_encoder_data(dataset.train.pressure_static, dataset.train.pressure_dynamic, autoencoder, mirror_data=mirror_data)
            elif training_data_type is TrainingDataType.TotalPressure or training_data_type is TrainingDataType.TotalPressureGas:
                scene_size = dataset.train.pressure.scene_size
                version = dataset.train.pressure.version
                seed = dataset.train.pressure.seed
                temp_enc_data = self.prepare_encoder_data_total(dataset.train.pressure, autoencoder, mirror_data=mirror_data)
            elif training_data_type is TrainingDataType.Velocity:
                scene_size = dataset.train.vel.scene_size
                version = dataset.train.vel.version
                seed = dataset.train.vel.seed
                temp_enc_data = self.prepare_encoder_data_total(dataset.train.vel, autoencoder, mirror_data=mirror_data)
            elif training_data_type is TrainingDataType.PressureDensityGas:
                scene_size = dataset.train.pressure.scene_size
                version = dataset.train.pressure.version
                seed = dataset.train.pressure.seed
                temp_enc_data = self.prepare_encoder_data(dataset.train.pressure, dataset.train.density, autoencoder, mirror_data=mirror_data)
            encoded_data = temp_enc_data if encoded_data is None else np.append(encoded_data, temp_enc_data, axis=0)

        assert len(encoded_data) % scene_size == 0, ("The provided data is not perfectly divisible by scene size. Something is wrong with the dataset.")
        num_scenes = dataset.description["num_scenes"]
        if mirror_data:
            num_scenes *= 4
        encoded_data = np.array(np.split(encoded_data, num_scenes, axis=0))
        self.create_encoded_scene(training_data_type, encoded_data, scene_size, version, seed, out_file_name)
        self.serialize(dataset_path=dataset_path)

        load_duration = time.time() - load_start_time
        print("Load Duration: {}".format(load_duration))
        self.printData()

    #--------------------------------------------
    def serialize(self, dataset_name="", dataset_path=""):
        self.encoded_scene_list.serialize(dataset_name=dataset_name, dataset_path=dataset_path)
        histogram_path = dataset_path if dataset_path else "."
        self.encoded_scene_list.save_histogram(histogram_path + "/enc_scene_list_{}_normalized.png".format(self.encoded_scene_list.name))

    #--------------------------------------------
    def prepare_encoder_data(self, static_datablock, dynamic_datablock, autoencoder, mirror_data=False):
        data_to_encode = [static_datablock.data, dynamic_datablock.data] # [(batch_size, 64, 64, 64, 1), (batch_size, 64, 64, 64, 1)]
        encoded_data = autoencoder.encode(data_to_encode, batch_size=settings.ae.batch_size)

        if mirror_data:
            # mirror on X
            data_to_encode_X = [static_datablock.data[:,::-1,:,:,:], dynamic_datablock.data[:,::-1,:,:,:]] # (array_dim, batch_size, 64, 64, 64, 1)
            encoded_data_mirror = autoencoder.encode(data_to_encode_X, batch_size=settings.ae.batch_size)
            encoded_data = np.append(encoded_data, encoded_data_mirror, axis=0)
            # mirror on Z
            data_to_encode_Z = [static_datablock.data[:,:,:,::-1,:], dynamic_datablock.data[:,:,:,::-1,:]] # (array_dim, batch_size, 64, 64, 64, 1)
            encoded_data_mirror = autoencoder.encode(data_to_encode_Z, batch_size=settings.ae.batch_size)
            encoded_data = np.append(encoded_data, encoded_data_mirror, axis=0)
            # mirror on XZ
            data_to_encode_XZ = [static_datablock.data[:,::-1,:,::-1,:], dynamic_datablock.data[:,::-1,:,::-1,:]] # (array_dim, batch_size, 64, 64, 64, 1)
            encoded_data_mirror = autoencoder.encode(data_to_encode_XZ, batch_size=settings.ae.batch_size)
            encoded_data = np.append(encoded_data, encoded_data_mirror, axis=0)

        print("Encoding of {} data blocks successful!".format(encoded_data.shape))
        return encoded_data

    #--------------------------------------------
    def prepare_encoder_data_total(self, datablock, autoencoder, mirror_data=False):
        data_to_encode = datablock.data
        encoded_data = autoencoder.encode(data_to_encode, batch_size=settings.ae.batch_size)

        if mirror_data:
            # mirror on X
            data_to_encode_X = data_to_encode[:,::-1,:,:,:] # (batch_size, 64, 64, 64, 1)
            encoded_data_mirror = autoencoder.encode(data_to_encode_X, batch_size=settings.ae.batch_size)
            encoded_data = np.append(encoded_data, encoded_data_mirror, axis=0)
            # mirror on Z
            data_to_encode_Z = data_to_encode[:,:,:,::-1,:] # (batch_size, 64, 64, 64, 1)
            encoded_data_mirror = autoencoder.encode(data_to_encode_Z, batch_size=settings.ae.batch_size)
            encoded_data = np.append(encoded_data, encoded_data_mirror, axis=0)
            # mirror on XZ
            data_to_encode_XZ = data_to_encode[:,::-1,:,::-1,:] # (batch_size, 64, 64, 64, 1)
            encoded_data_mirror = autoencoder.encode(data_to_encode_XZ, batch_size=settings.ae.batch_size)
            encoded_data = np.append(encoded_data, encoded_data_mirror, axis=0)

        print("Encoding of {} data blocks successful!".format(encoded_data.shape))
        return encoded_data

    #--------------------------------------------
    # static_datablock.scene_size, static_datablock.version, static_datablock.seed
    def create_encoded_scene(self, training_data_type, encoded_data, scene_size, version, seed, name):
        import datetime
        self.encoded_scene_list = datasets.SceneList(encoded_data, scene_size, version, str(datetime.datetime.now()), name, seed, self.test_split)
        self.normalize_scene_list(training_data_type)

    # #--------------------------------------------
    # # data_name = "lowres_data"
    # def generate_test_samples(self, data_name):
    #     X = np.array([]).reshape(0, self.time_steps, self.cae_code_size)
    #     if self.out_time_steps > 1:
    #         Y = np.array([]).reshape(0, self.out_time_steps, self.cae_code_size)
    #         GT = np.array([]).reshape( (0, self.out_time_steps) + self.highres_dimension )
    #     else:
    #         Y = np.array([]).reshape(0, self.cae_code_size)
    #         GT = np.array([]).reshape( (0,) + self.highres_dimension )

    #     for index, scene in enumerate(self.encoded_scene_list.test_scenes, start=0):
    #         sample_count = scene.scene_length
    #         sample = getattr(scene, data_name)()
    #         # if self.use_decoder:
    #         #     ground_truth = scene.decoded_data()
    #         X_test_temp, Y_test_temp = restructure_encoder_data(
    #                                    data = sample[0 : sample_count],
    #                                    time_steps = self.time_steps,
    #                                    out_time_steps = self.out_time_steps)
    #         X = np.append(X, X_test_temp).reshape(-1, self.time_steps, self.cae_code_size)
    #         if self.out_time_steps > 1:
    #             Y = np.append(Y, Y_test_temp).reshape(-1, self.out_time_steps, self.cae_code_size)
    #         else:
    #             Y = np.append(Y, Y_test_temp).reshape(-1, self.cae_code_size)

    #         # if self.use_decoder:
    #         #     if self.out_time_steps > 1:
    #         #         gt_list = []
    #         #         for i in range(self.time_steps, sample_count-self.out_time_steps):
    #         #             gt_list.append(np.asarray(ground_truth[i : i + self.out_time_steps]).reshape( (-1,) + self.highres_dimension ) )
    #         #         GT = np.append(GT, np.asarray(gt_list).reshape( (-1, self.out_time_steps) + self.highres_dimension ) ).reshape( (-1, self.out_time_steps) + self.highres_dimension ) 
    #         #     else:
    #         #         GT = np.append(GT, ground_truth[self.time_steps:sample_count]).reshape( (-1, ) + self.highres_dimension )

    #     return X, Y, GT
