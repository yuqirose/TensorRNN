import keras
from keras.regularizers import Regularizer
import keras.backend as K
import tensorflow as tf

class KLDivergence(Regularizer):
    def __init__(self, z_mean, z_log_var, kl_beta = 1.0, ):
        self.z_mean = z_mean
        self.z_log_var = z_log_var
        self._kl_beta = kl_beta

    def __call__(self, x):
        kld = K.cast(self._kl_beta, dtype=K.floatx()) * -0.5 * K.sum(1.0 + self.z_log_var - K.square(self.z_mean) - K.exp(self.z_log_var), axis=1)
        kld = tf.expand_dims(kld, 1)
        kld = tf.expand_dims(kld, 2)
        kld = tf.expand_dims(kld, 3)
        return kld

    def get_config(self):
        return {'kl_beta':self._kl_beta}

# #=====================================================================================
# class MutableWeightRegularizer(WeightRegularizer):
#     """ A WeightRegularizer of which parameters can be modified in training """

#     #---------------------------------------------------------------------------------
#     def __init__(self, l1=0.0, l2=0.0):
#         self._l1 = K.variable(l1)
#         self._l2 = K.variable(l2)
#         self.uses_learning_phase = True
#         self.p = None

#     #---------------------------------------------------------------------------------
#     @property
#     def l1(self):
#         return self._l1.get_value()

#     #---------------------------------------------------------------------------------
#     @l1.setter
#     def l1(self, value):
#         self._l1.set_value(value)

#     #---------------------------------------------------------------------------------
#     @property
#     def l2(self):
#         return self._l2.get_value()

#     #---------------------------------------------------------------------------------
#     @l2.setter
#     def l2(self, value):
#         self._l2.set_value(value)
