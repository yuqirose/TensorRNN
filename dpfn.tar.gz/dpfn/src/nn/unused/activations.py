import keras
from keras.layers.advanced_activations import SReLU
from keras.initializers import Constant

#--------------------------------------------
def SReLUConst(t_left=-1.0, a_left=0.2, t_right=1.0, a_right=0.2):
    """  A 'S' shaped Rectified Linear Unit with constant initialisation of the parameters """
    return SReLU(t_left_init=Constant(t_left), a_left_init=Constant(a_left), t_right_init=Constant(t_right), a_right_init=Constant(a_right))