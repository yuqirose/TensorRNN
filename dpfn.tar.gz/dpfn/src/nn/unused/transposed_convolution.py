from keras.layers import Convolution2D
from keras import backend as K
from keras.layers import Layer
from keras import activations, regularizers, constraints, initializations
from keras.engine.topology import InputSpec
import tensorflow as tf

#---------------------------------------------------------------------------------
def deconv_output_length(input_length, filter_size, border_mode, stride):
    # print("input_lenght: {}, filter_size: {}, border_mode: {}, stride: {}".format(
    #     input_length, filter_size, border_mode, stride
    # ))
    if input_length is None:
        return None
    assert border_mode in {'same', 'valid'}
    if border_mode == 'same':
        output_length = input_length * stride
    elif border_mode == 'valid':
        # output_length = input_length * stride - filter_size + 1
        output_length = (input_length - 1) * stride + filter_size
    return output_length
    

#=================================================================================
class TransposedConvolution2D(Layer):
    """
        Creates a 2D Convolution Transpose layer (sometimes called "Deconvolution").
        Only works with tensorflow backend.
    """

    input_ndim = 4

    #---------------------------------------------------------------------------------
    def __init__(self, nb_filter, nb_kernel_x, nb_kernel_y,
                 init='glorot_uniform', activation='linear', weights=None,
                 border_mode='valid', strides=(1,1),
                 W_regularizer=None, b_regularizer=None, activity_regularizer=None,
                 W_constraint=None, b_constraint=None, input_dim=None, input_length=None, **kwargs):

        if border_mode not in {'valid','same'}:
            raise Exception('Invalid border mode for Convolution1D:', border_mode)

        self.nb_filter = nb_filter
        self.nb_kernel_x = nb_kernel_x
        self.nb_kernel_y = nb_kernel_y
        self.init = initializations.get(init)
        self.activation = activations.get(activation)
        assert border_mode in {'valid', 'same'}, 'border_mode must be in {valid, same}'
        self.padding = border_mode
        self.strides = [1, strides[0], strides[1], 1]

        self.W_regularizer = regularizers.get(W_regularizer)
        self.b_regularizer = regularizers.get(b_regularizer)
        self.activity_regularizer = regularizers.get(activity_regularizer)

        self.W_constraint = constraints.get(W_constraint)
        self.b_constraint = constraints.get(b_constraint)
        self.constraints = [self.W_constraint, self.b_constraint]

        self.initial_weights = weights

        self.input_spec = [InputSpec(ndim=4)]
        self.initial_weights = weights
        self.input_dim = input_dim
        self.input_length = input_length
        if self.input_dim:
            kwargs['input_shape'] = (self.input_length, self.input_dim)
        super(TransposedConvolution2D, self).__init__(**kwargs)

    #---------------------------------------------------------------------------------
    def build(self, input_shape):
        input_nb_filter = input_shape[3]
        self.dim_x = input_shape[1] * self.strides[1]
        self.dim_y = input_shape[2] * self.strides[2]
        self.W_shape = (self.nb_kernel_x, self.nb_kernel_y, self.nb_filter, input_nb_filter)
        self.b_shape = (self.nb_filter)
        #print("Weights shape (nb_row, nb_col, nb_filter, input_nb_filter): ", self.W_shape)
        self.W = self.init(self.W_shape, name='{}_W'.format(self.name))
        self.b = K.zeros((self.nb_filter,), name='{}_b'.format(self.name))
        self.trainable_weights = [self.W, self.b]
        
        self.regularizers = []
        if self.W_regularizer:
            self.W_regularizer.set_param(self.W)
            self.regularizers.append(self.W_regularizer)
        if self.b_regularizer:
            self.b_regularizer.set_param(self.b)
            self.regularizers.append(self.b_regularizer)
        if self.activity_regularizer:
            self.activity_regularizer.set_layer(self)
            self.regularizers.append(self.activity_regularizer)

        self.constraints = {}
        if self.W_constraint:
            self.constraints[self.W] = self.W_constraint
        if self.b_constraint:
            self.constraints[self.b] = self.b_constraint

        if self.initial_weights is not None:
            self.set_weights(self.initial_weights)
            del self.initial_weights

    #---------------------------------------------------------------------------------
    def get_output_shape_for(self, input_shape):
        shape = (input_shape[0], input_shape[1] * self.strides[1], input_shape[2] * self.strides[2], self.nb_filter)
        #print("Get output shape for: {}".format(shape))
        return shape

    #---------------------------------------------------------------------------------
    # the main fuction which will be called in construction of the tf session
    def call(self, X,  mask=None):
        # get the dynamic batch size
        self.batch_size = K.shape(X)[0]

        # construct the output shape 
        self.deconv_shape = [self.batch_size, self.dim_x, self.dim_y, self.nb_filter]
        #print(self.batch_size)
        # perform transposed convolution
        output = tf.nn.conv2d_transpose(X, self.W, strides=self.strides,
                                          padding=self.padding.upper(),
                                          output_shape=self.deconv_shape)

        # reshape the tensor to apply const dimensions
        output = K.reshape(output, self.deconv_shape)

        # add the bias to all filters
        output += K.reshape(self.b, (1, 1, 1, self.nb_filter))

        # finally compute output activation
        output = self.activation(output)
        return output

    #---------------------------------------------------------------------------------
    def get_config(self):
        config = {
                  'init': self.init.__name__,
                  'activation': self.activation.__name__,
                  'padding': self.padding,
                  'strides': self.strides,
                  'W_regularizer': self.W_regularizer.get_config() if self.W_regularizer else None,
                  'b_regularizer': self.b_regularizer.get_config() if self.b_regularizer else None,
                  'activity_regularizer': self.activity_regularizer.get_config() if self.activity_regularizer else None,
                  'W_constraint': self.W_constraint.get_config() if self.W_constraint else None,
                  'b_constraint': self.b_constraint.get_config() if self.b_constraint else None,
                  'W_shape': self.W_shape,
                  'b_shape': self.b_shape,
                  'deconv_shape': self.deconv_shape }
        base_config = super(TransposedConvolution2D, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))

    #---------------------------------------------------------------------------------
    @property
    def get_output_shape(self, input_shape):
        #return (self.deconv_shape[0],self.deconv_shape[1],self.deconv_shape[2],self.deconv_shape[3])
        return self.get_output_shape_for(input_shape=input_shape)