 2D blur im static pressure oder levelset schrumpfen und wieder extrapolieren
 cgMaxIterFac = --1.5-- zu 10
 64 zu 32 runtersamplen ist besser als 32 sim
 nils.thuerey@tum.de bei github
 
 31.08.17
 ========
 Done:
 - Settings.py
 - Requirements.py
 - Split Autoencoder
 - LSTM refactor
 - Autoencoder + LSTM training
 - split_pressure_scene class
 - static pressure 3D
 - gaussian blur on static pressure
 - clear nonfluid cells
 - ERR: shrink + extrapolate (extrapolate does not change surface location) extrapolateLsSimple(ls, 10, false)
 
 Notes:
 - Velocity and other models for comparison?
 - Extrapolate -> (Phi+distance) -> Extrapolate -> (Phi-distance)
 - Better than extrapolLsSimple: ReinitMarching
 - Gravity issue extforces addGRavity
 - cgSolve maxiterfac & acc increase for testingg
 - Different height testcase, basin with no motion --> use this to compute gravity factor
 - FLIP

 07.09.2017
 ==========
 Done:
 - Levelset smoothing with shrink and grow
 - ReinitMarching
 - Blur Static Pressure after levelset smoothing to remove remaining artefacts
 - Gravity issue fix (code copied from extforces)
 - Project output with history.json, arguments.json, predictions.npz and settings.json
 - Smaller KL Divergence 1024 code layer
 - Training in progress with 10000 samples (300s per epoch)

 Notes:
 - Blur only in fluid cells
 - Scene Drops: initial velocity down & side
 - Autonencoder only simulation vs with LSTM
 - Limits to generalization (breaking dam, obstacles, in outflow, empty scene with drops)
 - Rendering of the liquid with simulation with blender

 20.09.2017
 ==========
 Done:
 - Scenes with random velocity: More turbulent fluid
 - Dataset header for meta information
 - Plotter for loss during training
 - 512 code layer
 
 Current Issues:
 - LSTM probably too small --> gradually increase size until overfitting
 - Autoencoder training for 200 epochs good in standard situations bad in exceptional situations --> larger code layer?

25.09.2017
==========


13.12.2017
==========

Done:
- Generator for autoencoder with shuffled chunkwise loading and in-chunk shuffling
- Network class adaption for autoencoder to enable __parameter search__ + parametrization of autoencoder model
- Variable input size for autoencoder
- LSTM encoded dataset moved to its own class
- Test with 25 epochs & pretraining (3*6=18 epochs) on full dataset --> new record in both train and validation loss (0.0056 train & 0.0073 val)
- Test with 25 epochs & no pretraining on full dataset --> results still good, (0.0072 train, 0.0086 val), probably even better after amount of epochs as with pretraining (3*6 = 18 more epochs) => verify this, then probably switch off pretraining or limit to upper layers

Todo:
- highest priority: test 128 data with 64 autoencoder
- Alternative autoencoders are in the works (combined, VAE, velocity, smoke in this order of priority)
- Dataset correct pressure static and set bound neumann for boundary
- Parameter Search on best
- Final training on some of the promising AEs
- metrics on the error in simulation --> use this with encoder decode scene to determine the best autoencoder
- gradually reduce sizes of AE and LSTM to a quick realtime execution without too much loss in quality

18.12.2017
==========
### Done:
- Dataset correction static pressure, boundaries
- Autoencoder hyperparameter search impl
- Total pressure & velocity autoencoder

### Todo:
- Hausdorff distance on levelset: search for surface in LS1 --> use values from LS1 as interpolants in LS2 to get local distance
- Use randomized scene and warmup steps to measure simulation/prediction 
- To make datasets public: Publish parameters of the dataset
- Use big number of predictions and store metrics (MSE pres, ls, etc, HD ls) for after each step
- metrics.cpp: MSE/L2Norm, MAE and Hausdorff Distance, (Cosine Similarity?)
- Explicit Hyperparameter search, linear hyperparameter search
- Variational AE
- 128 Training

### Paper:
- ACM template. Specialities: \shortcite 
- Use macros for names of Figure, Equation, etc.
- Max 10 - 12 pages
- Start with Method soon (Model, Physical Computations, Focus on central aspects)
- Nils will help with intro
- Discussion & Limitations ... (Generality, Performance GPU & stuff, )
- Results can be done later, when experiments complete, but training data could be written now
- Metrics (such as Hausdorff) on Appendix if at all
- Performance is important for Siggraph
- Emphasize difficulties as well

22.12.2017
==========

### Done
- Kernel Size tests
- Feature Multiplier tests
- 11M param model
- 25 Epochs training with optimal vals
- in progress: LR and Decay

### Order of training
1. Total
2. 128
3. Vel 64
4. Variational 64

### Paper
- Comparison to static pressure simulation, no pressure solve at all, repeat velocity, compute static and repeat dynamic
- Save resulting LS to replay error metrics in final tests
- Problem: Related Work. Maybe thompson, maybe Intuitive Physics, Deep Mind, evtl auch websites. Comparison will be requested by reviewer

03.01.17
========
### Notes
- Gas sim: Timestep too high, reduce until in last sim frame velocities reach 5.0
- Use same amount of samples as in liquid simulation to avoid questions why more
- Reference renderings
- Renderings of resolution 64 results

### Paper Notes
- Explain AE a bit
- Add numbers to model size statements
- 

08.01.2018
==========

### Notes Paper
- Convolution overlap website cite
- Render diffuse png for everything that should be shown in video