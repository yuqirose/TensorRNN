# check and install requirements
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 

import util.requirements
util.requirements.fulfill()
util.requirements.init_packages()

import logging, datetime, time, math, json
import numpy as np
import tensorflow as tf

from nn.arch.autoencoder import Autoencoder, SplitPressureAutoencoder
from nn.arch.lstm import Lstm
from nn.lstm.error_classification import restructure_encoder_data
from nn.lstm.sequence_training_data import TrainingData, TrainingDataType
from nn.hyperparameter.hyper_parameter import HyperParameter, ValueType, SearchType
from nn.hyperparameter.hyper_search import HyperSearch

import dataset.datasets as ds
import util.plot
from util import settings
from util.filesystem import Filesystem
from util import filesystem
from util import arguments

# Arguments
#----------------------------------------------------------------------------
args = arguments.parse_parameter_search()

# Settings & Files
#----------------------------------------------------------------------------
settings.load("settings.json")
timestamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
fs = Filesystem(settings.project.path + "history/" + timestamp + "/")
datasets_root = "."
if args.datasets_root:
    datasets_root = args.datasets_root
else:
    datasets_root = filesystem.find_directory("datasets")
data_fs = Filesystem(filesystem.find_directory("datasets") + "/" + args.dataset+ "/")
settings.save(fs["search/description"])
with open(fs["search/arguments.json"], 'w') as f:
    json.dump(vars(args), f, indent=4)



def main():
    # Dataset
    #----------------------------------------------------------------------------
    dataset = ds.DataSet()

    # Autoencoder
    #----------------------------------------------------------------------------
    autoencoder = SplitPressureAutoencoder()
    autoencoder.pretrain_epochs = 0
    autoencoder.variational_ae = args.ae_vae

    # Loading from checkpoint
    if args.ae_load:
        autoencoder.load_model(settings.project.path + args.name + "/autoencoder.h5")

    # Define Hyperparameters
    if args.ae_epochs != 0:
        dataset.load(path=data_fs[""], 
            blocks=["pressure_static", "pressure_dynamic"], 
            norm_factors={"pressure_static": settings.dataset.pressure_static_normalization_factor,
                "pressure_dynamic": settings.dataset.pressure_dynamic_normalization_factor},
            files_per_batch=args.chunk_size,
            shuffle=True,
            validation_split=0.05,
            test_split=0.5)

        # parse input search parameters
        param_team = generate_parameter_team(args.ae_parameter)

        # start hypersearch
        ae_search = HyperSearch(autoencoder, param_team, fs["search/"])
        search_hist = ae_search.search(dataset=dataset, epochs=args.ae_epochs, batch_size=settings.ae.batch_size)

        # if search_hist is not None:
        #     # evaluate search history, do plots etc
        #     title = "AE Loss (" + ", ".join([i.name for i in param_team]) + ")"
        #     selected_params = '-'.join([i.name for i in param_team])
        #     # plot the history
        #     ae_history_plotter = util.plot.Plotter()
        #     ae_history_plotter.plot_multi_loss_history(search_hist, title=title)
        #     ae_history_plotter.save_figures(fs["search/"], "AE_Multi_History_"+selected_params)

    # LSTM
    #----------------------------------------------------------------------------
    if args.lstm_epochs != 0:
        # parse input search parameters
        param_team = generate_parameter_team(args.lstm_parameter)
        # generate search name
        search_name = '-'.join([i.name for i in param_team])
        search_path = "search/{}/".format(search_name)

        # Load datasets
        training_data = load_lstm_training_data(dataset, autoencoder)
        # loading of scene list finished
        encoded_scene_list = training_data.encoded_scene_list
        # Create LSTM model
        data_dim = training_data.data_shape(True) 
        lstm = Lstm(settings=settings, data_dimension=data_dim)

        # start hypersearch
        lstm_search = HyperSearch(lstm, param_team, fs[search_path])
        search_hist = lstm_search.search(
            epochs=args.lstm_epochs,
            train_scenes=encoded_scene_list.train,
            validation_split=0.1
        )
        if search_hist is not None:
            # evaluate search history, do plots etc
            title = "LSTM Loss (" + ", ".join([i.name for i in param_team]) + ")"
            # plot the history
            lstm_history_plotter = util.plot.Plotter()
            lstm_history_plotter.plot_multi_loss_history(search_hist, title=title)
            lstm_history_plotter.save_figures(fs[search_path], "LSTM_Multi_History_"+search_name, filetype="svg")
            # dump description
            settings.save(fs[search_path+"description"])
            with open(fs[search_path+"arguments.json"], 'w') as f:
                json.dump(vars(args), f, indent=4)

    fs.copy(settings.project.path + args.name + "/")

#----------------------------------------------------------------------------
def generate_parameter_team(args_param):
    param_team = []
    for param in args_param:
        search_type = param[1]
        if search_type == 0 or search_type == 1:
            hyper_param = HyperParameter(parameter_name=param[0], search_type=SearchType(param[1]), value_type=ValueType(param[2]), value_range=param[3], iterations=param[4])
        else:
            hyper_param = HyperParameter(parameter_name=param[0], search_type=SearchType(param[1]), value_type=ValueType(param[2]), values=param[3])
        param_team.append(hyper_param)
    assert len(param_team) > 0, ("No hyperparameters given, aborting")
    # param_team = [
    #     HyperParameter("learning_rate", [0.00005, 0.0005], iterations=3),
    #     HyperParameter("dropout", [0.0, 0.5], iterations=2)
    # ]
    return param_team

#----------------------------------------------------------------------------
def load_lstm_training_data(dataset, autoencoder):
    training_data = TrainingData(test_split=0.05)
    training_data_type = TrainingDataType.SplitPressureVAE if args.ae_vae else TrainingDataType.SplitPressure

    # Should be dependent on whether the autoencoder was changed or just loaded 
    if args.lstm_load_dataset:
        training_data.load_from_file(training_data_type=training_data_type, dataset_path=data_fs[""])
    else:
        training_data.load_from_folder(
            training_data_type = training_data_type,
            autoencoder=autoencoder,
            dataset_path=data_fs[""],
            chunk_size = args.chunk_size,
            mirror_data = True
        )

    return training_data

#----------------------------------------------------------------------------
def evaluate_lstm():
    print("\n\nLSTM Evaluation")

    #avg_grad_norm, min_grad_norm, max_grad_norm = lstm.find_average_gradient_norm(encoded_scene_list.test_scenes)
    #print("\tAverage Gradient Norm: {} Min Gradient Norm: {} Max Gradient Norm: {}".format(avg_grad_norm, min_grad_norm, max_grad_norm))

    # Evaluation & Plot
    plotter = util.plot.Plotter3D()

    scn_enc_data = encoded_scene_list.test_scenes[0].encoded_data()
    X, Y = restructure_encoder_data(
                data = scn_enc_data,  # [0 : lstm.time_steps + lstm.out_time_steps],
                time_steps = lstm.time_steps,
                out_time_steps = lstm.out_time_steps)

    X = X[0:len(X):len(X)//4]
    Y = Y[0:len(Y):len(Y)//4]

    ae_code_pred = lstm.predict(X, batch_size=1)

    # denormalize
    ae_code_pred *= training_data.normalization_factor
    Y *= training_data.normalization_factor
    #print("LSTM code prediction:\n{}".format(ae_code_pred))
    #print("Autoencoder code true:\n{}".format(Y))

    print("\n\nCode Layer Eval:")
    code_layer_eval = 0
    for x, y in zip(Y,ae_code_pred):
        x = np.squeeze(x)
        y = np.squeeze(y)
        print("\tOutput Shapes: True {} Predicted {}".format(x.shape, y.shape))
        mse_metric = ((x - y) ** 2).mean(axis=None)
        print("\tMean Squared Error: {}".format(mse_metric))
        print("\tRoot Mean Squared Error: {}".format(math.sqrt(mse_metric)))
        
        abs_dif = np.abs(np.abs(x)-np.abs(y))
        print("\tAbsDif Shape: {}".format(abs_dif.shape))
        out_list = np.array([x, y, abs_dif])
        print("\tout_list Shape: {}".format(out_list.shape))
        
        np.savetxt(fs["eval"]+"/CodeLayer_True_Pred_AbsDif_{}.txt".format(code_layer_eval), out_list, fmt='%+7.3f')
        code_layer_eval += 1
        print("\t----------------------------------------------------------------------------------")

    # decode
    [pred_y_stat, pred_y_dyn] = autoencoder.decode(z=ae_code_pred)
    [true_y_stat, true_y_dyn] = autoencoder.decode(z=Y)

    pred_y_stat *= dataset.pressure_static.normalization_factor
    true_y_stat *= dataset.pressure_static.normalization_factor
    pred_y_dyn *= dataset.pressure_dynamic.normalization_factor
    true_y_dyn *= dataset.pressure_dynamic.normalization_factor

    for true_static, true_dynamic, pred_static, pred_dynamic in zip(true_y_stat, true_y_dyn, pred_y_stat, pred_y_dyn):
        x = true_static + true_dynamic
        y = pred_static + pred_dynamic
        x = np.squeeze(x)
        y = np.squeeze(y)
        plotter.plot_pressure_widgets(fields={'True':x, 'Pred':y}, title="AE true and LSTM pred")

    plotter.show(block=True)
    plotter.save_figures(fs["eval"]+"/", "LSTM_Prediction")

# Start application
#----------------------------------------------------------------------------
if __name__=="__main__":
    main()
