import matplotlib.pyplot as plt
import json
import argparse
from util import filesystem
import os
from pathlib import Path
from util.plot import Plotter
from nn.hyperparameter.hyper_parameter import HyperParameter, ValueType, SearchType
from ast import literal_eval as make_tuple
from collections import namedtuple

parser = argparse.ArgumentParser()
parser.add_argument("-p", "--project", type=str, required=True, help="Name of the project directory for which to plot results")
args = parser.parse_args()

project_root = Path(filesystem.find_dir(args.project, 2))
search_path = project_root / "search"

plotter = Plotter()


if search_path.is_dir():
    # load arguments
    arguments = None
    argument_file = search_path / "arguments.json"
    with open(argument_file) as f:
        arguments = json.load(f, object_hook=lambda d: namedtuple('args', d.keys())(*d.values()))

    # load hyperparameters from args
    param_team = []
    for param in arguments.ae_parameter:
        search_type = param[1]
        if search_type == 0 or search_type == 1:
            hyper_param = HyperParameter(parameter_name=param[0], search_type=SearchType(param[1]), value_type=ValueType(param[2]), value_range=param[3], iterations=param[4])
        else:
            hyper_param = HyperParameter(parameter_name=param[0], search_type=SearchType(param[1]), value_type=ValueType(param[2]), values=param[3])
        param_team.append(hyper_param)

    with open(search_path / "search_hist.json", "r") as f:
        search_hist = json.load(f)
        keys = search_hist.keys()
        # get all validation losses
        values = [search_hist[k]["val_loss"][-1] for k in keys]
        # convert key strings to tuples
        keys = list(map(make_tuple, keys))
        print("The optimal value is at {}".format(keys[values.index(min(values))]))
        plotter.plot_scatter(pos=keys, value=values, title="Learning Rate & Weight Decay")
        plotter.show(block=True)
