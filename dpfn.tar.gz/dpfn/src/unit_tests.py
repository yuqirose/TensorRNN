# check and install requirements
import util.requirements
util.requirements.fulfill()
util.requirements.init_packages()

import numpy as np
import unittest
import argparse
import os
import glob
import random

from nn.arch.autoencoder import Autoencoder, SplitPressureAutoencoder
import dataset.datasets as ds

class TestVelocityAutoencoder(unittest.TestCase):
    dataset_name = "test"
    dataset = ds.DataSet()
    dataset.load(name=dataset_name, blocks=["vel"])

    def test_predict(self):
        autoencoder = Autoencoder(input_shape=(None, None, None, 3))
        autoencoder._init_optimizer()
        autoencoder._build_model()
        autoencoder._compile_model()
        predict_output = autoencoder.predict(self.dataset.test.vel(), batch_size=8)
        encoded_output = autoencoder.encode(self.dataset.test.vel(), batch_size=8)
        decoder_output = autoencoder.decode(encoded_output, batch_size=8)
        autoencoder.print_summary()
        self.assertTrue(np.allclose(predict_output, decoder_output))

    def test_train(self):
        autoencoder = Autoencoder(input_shape=(None, None, None, 3))
        autoencoder.pretrain_epochs = 2
        autoencoder.train(dataset=self.dataset, epochs=2, batch_size=4)

class TestTotalAutoencoder(unittest.TestCase):
    dataset_name = "test"
    dataset = ds.DataSet()
    dataset.load(name=dataset_name, blocks=["pressure"])

    def test_predict(self):
        autoencoder = Autoencoder()
        autoencoder._init_optimizer()
        autoencoder._build_model()
        autoencoder._compile_model()
        predict_output = autoencoder.predict(self.dataset.test.pressure(), batch_size=8)
        encoded_output = autoencoder.encode(self.dataset.test.pressure(), batch_size=8)
        decoder_output = autoencoder.decode(encoded_output, batch_size=8)
        autoencoder.print_summary()
        self.assertTrue(np.allclose(predict_output, decoder_output))

    def test_train(self):
        autoencoder = Autoencoder()
        autoencoder.pretrain_epochs = 1
        autoencoder.train(dataset=self.dataset, epochs=2, batch_size=4)

class TestSplitAutoencoder(unittest.TestCase):
    dataset_name = "test"
    dataset = ds.DataSet()
    dataset.load(name=dataset_name, blocks=["pressure_static", "pressure_dynamic"])

    def test_predict(self):
        autoencoder = SplitPressureAutoencoder()
        autoencoder._init_optimizer()
        autoencoder._build_model()
        autoencoder._compile_model()
        predict_output = autoencoder.predict([self.dataset.test.pressure_static(), self.dataset.test.pressure_dynamic()], batch_size=8)
        encoded_output = autoencoder.encode([self.dataset.test.pressure_static(), self.dataset.test.pressure_dynamic()], batch_size=8)
        decoder_output = autoencoder.decode(encoded_output, batch_size=8)
        autoencoder.print_summary()
        self.assertTrue(np.allclose(predict_output, decoder_output))


    def test_train(self):
        autoencoder = SplitPressureAutoencoder()
        autoencoder.pretrain_epochs = 2
        autoencoder.train(dataset=self.dataset, epochs = 2, batch_size=4)

class TestAutoencoder(unittest.TestCase):
    dataset_name = "test"
    dataset = ds.DataSet()
    dataset.load(name=dataset_name, blocks=["pressure"])

    def test_code_size(self):
        autoencoder = Autoencoder()
        autoencoder._init_optimizer()
        autoencoder._build_model()
        autoencoder._compile_model()
        predict_output = autoencoder.predict(self.dataset.test.pressure(), batch_size=8)
        encoded_output = autoencoder.encode(self.dataset.test.pressure(), batch_size=8)
        decoder_output = autoencoder.decode(encoded_output, batch_size=8)
        #code_shape = autoencoder.encoder_output_shape()
        #self.assertEqual(code_shape, encoded_output.shape())
        code_shape = autoencoder.encoder_output_shape(input_shape=self.dataset.train.pressure.shape)
        self.assertEqual(code_shape, encoded_output.shape[1:])


class TestDataset(unittest.TestCase):
    dataset_name = "test"

    def test_description(self):
        dataset = ds.DataSet()
        dataset.load(name=self.dataset_name, files_per_batch=0)
        # number of files
        num_frames = dataset.description["num_scenes"] * dataset.description["simulation_steps"]
        self.assertEqual(num_frames, dataset.train.length + dataset.val.length + dataset.test.length)
        # available grids
        dataset_root = dataset._get_dataset_root(name=self.dataset_name)
        dirs = [dir for dir in os.listdir(dataset_root) if os.path.isdir(dataset_root + "/" + dir)]
        print(set(dataset.description["grids"]))
        print(set(dirs))
        self.assertTrue(set(dataset.description["grids"]) <= set(dirs)) # is subset
        # resolution
        res = getattr(dataset.train, dataset.train.blocks[0]).shape[1]
        self.assertEqual(res, dataset.description["resolution"])

    def test_shuffle_all(self):
        """ check a few times if the dataset actually is different from the unshuffled """
        all_equal = True
        for i in range(1):
            ds1 = ds.DataSet()
            ds1.load(name=self.dataset_name, shuffle=False)
            ds2 = ds.DataSet()
            ds2.load(name=self.dataset_name, shuffle=True)
            if np.allclose(getattr(ds1.train, ds1.train.blocks[0]).data, getattr(ds2.train, ds2.train.blocks[0]).data) == False:
                all_equal = False
        self.assertFalse(all_equal)

    def test_num_frames(self):
        dataset = ds.DataSet()
        dataset.load(name=self.dataset_name, files_per_batch=0)
        self.assertEqual(dataset.train.length, dataset.train._active_block_length)

    def test_num_train_batches(self):
        ds1 = ds.DataSet()
        ds1.load(name=self.dataset_name, files_per_batch=0)
        ds2 = ds.DataSet()
        ds2.load(name=self.dataset_name, files_per_batch=1)
        self.assertEqual(ds1.train.num_frames, ds2.train.num_frames)
        self.assertEqual(ds1.train.steps_per_epoch(4), ds2.train.steps_per_epoch(4)) # if this fails, first check if dataset contains enough sim steps
        
    def test_generator(self):
        # ds1 = ds.DataSet()
        # ds1.load(name=self.dataset_name, files_per_batch=0)
        # ds2 = ds.DataSet()
        # ds2.load(name=self.dataset_name, files_per_batch=1)
        # train_batches = ds2.num_train_batches(4)
        pass

    def test_train_val_test_split(self):
        dataset = ds.DataSet()
        for i in range(50):
            num_files = random.randint(1, 2000)
            val_split = random.uniform(0.0, 0.3)
            test_split = random.uniform(0.0, 0.3)
            train_range, val_range, test_range = dataset._get_ranges(num_files, val_split, test_split)
            self.assertEqual(train_range[1], val_range[0])
            self.assertEqual(val_range[1], test_range[0])
            sum_of_ranges = train_range[1]- train_range[0] + val_range[1]- val_range[0] + test_range[1]- test_range[0]
            self.assertEqual(num_files, sum_of_ranges)
            #self.assertEqual(int(num_files * val_split), val_range[1] - val_range[0])
            #self.assertAlmostEqual(int(num_files * test_split), test_range[1] - test_range[0])
        dataset.load(name=self.dataset_name, files_per_batch=0, validation_split=0.1, test_split=0.1, augment=True)
        num_files = dataset.num_files
        train_range, val_range, test_range = dataset._get_ranges(num_files, 0.1, 0.1)
        self.assertEqual(train_range[1] - train_range[0], dataset.train.num_files)
        self.assertEqual(val_range[1] - val_range[0], dataset.val.num_files)
        self.assertEqual(test_range[1] - test_range[0], dataset.test.num_files)
        

    def test_data_augmentation(self):
        dataset = ds.DataSet()
        dataset.load(name=self.dataset_name, files_per_batch=0, augment=True)
        dataset.train
        dataset = ds.DataSet()
        dataset.load(name=self.dataset_name, files_per_batch=2, augment=True)
        dataset.train.next_chunk()

if __name__ == '__main__':

    unittest.main()