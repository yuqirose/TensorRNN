from util import plot
from util import settings
import json
import numpy as np

def evaluate_autoencoder(autoencoder, dataset, fs, pretrain_hist, train_hist):
    plotter = plot.Plotter3D()
    step = 10
    xs_static, xs_dynamic = (dataset.train.pressure_static.data, dataset.train.pressure_dynamic.data)
    print(xs_static.shape)
    ys_static, ys_dynamic = autoencoder.predict([xs_static, xs_dynamic], batch_size=settings.ae.batch_size)
    xs_static *= dataset.test.pressure_static.normalization_factor
    ys_static *= dataset.test.pressure_static.normalization_factor
    xs_dynamic *= dataset.test.pressure_dynamic.normalization_factor
    ys_dynamic *= dataset.test.pressure_dynamic.normalization_factor

    with open(fs["eval/predictions.npz"], 'wb') as f:
        np.savez_compressed(f, xs_static=xs_static, xs_dynamic=xs_dynamic, ys_static=ys_static, ys_dynamic=ys_dynamic)

    for x_static, x_dynamic, y_static, y_dynamic in zip(xs_static[::step], xs_dynamic[::step], ys_static[::step], ys_dynamic[::step]):
        x = x_static + x_dynamic
        y = y_static + y_dynamic
        x = np.squeeze(x)
        y = np.squeeze(y)
        plotter.plot_pressure_widgets(fields={'True':x, 'Pred':y}, title="autoencoder only")

    if pretrain_hist is not None:
        with open(fs["eval/ae_pretrain_hist.json"], 'w') as f:
            json.dump(pretrain_hist.history, f)

    if train_hist is not None:
        plotter.plot_history(train_hist.history)
        with open(fs["eval/ae_train_hist.json"], 'w') as f:
            json.dump(train_hist.history, f)

    #plotter.save_figures(output_path)
    plotter.show(block=True)