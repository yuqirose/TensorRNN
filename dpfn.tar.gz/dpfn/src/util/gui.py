import pyqtgraph.examples

pyqtgraph.examples.run()