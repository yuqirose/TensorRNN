import sys

class MultiStdOut(object):
    """ This hidden class should only be used in MultiLogger """
    def __init__(self, *file_handles):
        self.file_handles = file_handles

    def write(self, content):
        for f in self.file_handles:
            f.write(content)
            f.flush()

    def flush(self) :
        for f in self.file_handles:
            f.flush()


class MultiLogger(object):
    """ Redirect output to file and console simultaneously """
    def __init__(self):
        """
        The MultiLogger class enables the user to write simultaneously to file and std output.
        After opening the file all calls to >print< are automatically redirected to file and std out.
        """
        self.open_state = False

    def open(self, log_file_path):
        if self.open_state is False:
            self.log_file = open(log_file_path, 'w')

            self.original_std_out = sys.stdout
            self.original_std_err = sys.stderr
            
            sys.stdout = MultiStdOut(sys.stdout, self.log_file)
            sys.stderr = MultiStdOut(sys.stderr, self.log_file)
            
            self.open_state = True

    def close(self):
        if self.open_state:
            sys.stdout = self.original_std_out
            sys.stderr = self.original_std_err
            
            self.log_file.close()
            self.log_file = None
            self.open_state = False
