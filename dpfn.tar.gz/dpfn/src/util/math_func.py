# (c) copyright 2017 Steffen Wiewel and Moritz Becher

from math import log10, floor

# https://stackoverflow.com/a/3413529
def round_sig(x, sig=2):
    if x == 0.0:
        return round(x, sig)
    return round(x, sig-int(floor(log10(abs(x))))-1)

# https://stackoverflow.com/a/3928583
def round_tuple(tup, sig=2):
    if isinstance(tup, tuple):
        return tuple(map(lambda x: isinstance(x, float) and round_sig(x, sig) or x, tup))
    else:
        return tup